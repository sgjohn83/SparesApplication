package com.spares;

import java.awt.EventQueue;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       
        EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					 System.out.println( "Hello World!" );
					 AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
					 MobileSpares mobileSpares = ctx.getBean(MobileSpares.class);
					 mobileSpares.frame.setVisible(true);

					
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
			}
		});
    }
}
