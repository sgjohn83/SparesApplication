package com.spares.service;

import java.sql.SQLException;
import java.util.List;

import javax.swing.JOptionPane;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spares.dao.RepairPartsUsedDAO;
import com.spares.model.Part;
import com.spares.model.PartReceipt;
import com.spares.model.RepairPartsUsed;
import com.spares.model.RepairPartsUsedResult;
import com.spares.model.Supplier;

@Service
@Transactional
public class RepairPartsUsedService {

    @Autowired
    private RepairPartsUsedDAO dao;

   
    public RepairPartsUsed save(RepairPartsUsed repairPartUsed) {
        try {
			return dao.save(repairPartUsed);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			 JOptionPane.showMessageDialog(
		                null,
		                "Database error:\n" + e.getMessage(),
		                "SQL Error",
		                JOptionPane.ERROR_MESSAGE
		            );
		}
		return null;
    }

   
    public RepairPartsUsed findById(Long id) {
        return dao.findById(id);
    }

    
    public List<RepairPartsUsed> findAll() {
        return dao.findAll();
    }

   
    public void update(RepairPartsUsed repairPartUsed) {
        dao.update(repairPartUsed);
    }

   
    public void delete(Long id) {
        dao.delete(id);
    }

   
    public List<Part> findAllUsedParts() {
        return dao.findAllUsedParts();
    }

   
    public List<Supplier> findAllUsedSuppliers() {
        return dao.findAllUsedSuppliers();
    }

  
    public List<PartReceipt> findAllUsedReceipts() {
        return dao.findAllUsedReceipts();
    }
    public String getCommaSeparatedPartNamesByRepairId(Long repairId)
    {
    	return dao.getCommaSeparatedPartNamesByRepairId(repairId);
    }
    public List<RepairPartsUsed> getByReceiptId(Long receiptId)
    {
    	return dao.getByReceiptId(receiptId);
    }
    public List<RepairPartsUsedResult> getByReceiptId1(Long receiptId)
    {
    	return dao.getByReceiptId1(receiptId);
    }
}
