package com.spares.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spares.dao.ReturnedSparePartDao;
import com.spares.model.ReturnedSparePart;

@Service
@Transactional
public class ReturnedSparePartService {

    @Autowired
    private ReturnedSparePartDao returnedSparePartDao;

  
    public List<ReturnedSparePart> fetchReturnedParts() {
        return returnedSparePartDao.getAllReturnedParts();
    }
    public List<String> fetchSupplierNames() 
    {
    	 return returnedSparePartDao.fetchSupplierNames();
    }
}
