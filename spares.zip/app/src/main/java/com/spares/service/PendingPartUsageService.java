package com.spares.service;

import com.spares.dao.PendingPartUsageDAO;
import com.spares.model.PendingPartUsageView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PendingPartUsageService {

    @Autowired
    private PendingPartUsageDAO pendingPartUsageDAO;

    public List<PendingPartUsageView> getPendingPartUsage() {
        return pendingPartUsageDAO.getPendingPartUsage();
    }
}
