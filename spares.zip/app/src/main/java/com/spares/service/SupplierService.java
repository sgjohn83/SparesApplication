package com.spares.service;



import com.spares.dao.SupplierDAO;
import com.spares.model.Supplier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SupplierService {

    @Autowired
    private SupplierDAO supplierDAO;

    public Supplier save(Supplier supplier) {
        return supplierDAO.save(supplier);
    }

    public Supplier update(Supplier supplier) {
        return supplierDAO.update(supplier);
    }

    public void delete(Long id) {
        supplierDAO.delete(id);
    }

    public Supplier getById(Long id) {
        return supplierDAO.findById(id);
    }
    public Supplier getByName(String name) {
        return supplierDAO.findByName(name);
    }

    public List<Supplier> getAllSuppliers() {
        return supplierDAO.findAll();
    }
}
