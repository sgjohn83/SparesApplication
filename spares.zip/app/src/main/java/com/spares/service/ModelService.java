package com.spares.service;



import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spares.dao.ModelDao;
import com.spares.model.Model;


@Service
@Transactional
public class ModelService {

    @Autowired
    private ModelDao modelDao;

    public void saveModel(Model model) {
        modelDao.save(model);
    }

    public void updateModel(Model model) {
        modelDao.update(model);
    }

    public void deleteModel(Model model) {
        modelDao.delete(model);
    }

    public Model getModelById(Long id) {
        return modelDao.findById(id);
    }

    public List<Model> getAllModels() {
        return modelDao.findAll();
    }

    public List<Model> getModelsByBrandId(Long brandId) {
        return modelDao.findByBrandId(brandId);
    }
}

