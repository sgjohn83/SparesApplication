package com.spares.service;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spares.dao.BrandDAO;
import com.spares.model.Brand;

import java.util.List;

@Service
@Transactional
public class BrandService{

    @Autowired
    private BrandDAO brandDAO;

  
    public void saveBrand(Brand brand) {
        brandDAO.save(brand);
    }


    public void updateBrand(Brand brand) {
        brandDAO.update(brand);
    }


    public void deleteBrand(Brand brand) {
        brandDAO.delete(brand);
    }


    public Brand getBrandById(Long id) {
        return brandDAO.findById(id);
    }


    public List<Brand> getAllBrands() {
        return brandDAO.findAll();
    }
}
