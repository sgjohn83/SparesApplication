package com.spares.service;



import com.spares.dao.PartDAO;
import com.spares.model.Part;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PartService {

    @Autowired
    private PartDAO partDAO;

    public Part save(Part part) {
        return partDAO.save(part);
    }

    public Part update(Part part) {
        return partDAO.update(part);
    }

    public void delete(Long id) {
        partDAO.delete(id);
    }

    public Part getById(Long id) {
        return partDAO.findById(id);
    }
    public Part getByName(String name) {
        return partDAO.findByName(name);
    }

    public List<Part> getAllParts() {
        return partDAO.findAll();
    }
}

