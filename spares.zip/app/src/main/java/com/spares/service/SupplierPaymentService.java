package com.spares.service;



import com.spares.dao.SupplierPaymentDao;
import com.spares.model.RepairPartsUsed;
import com.spares.model.Supplier;
import com.spares.model.SupplierPayment;
import com.spares.service.SupplierPaymentService;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class SupplierPaymentService {

	  @Autowired
	private SupplierPaymentDao supplierPaymentDao;

    public void setSupplierPaymentDao(SupplierPaymentDao supplierPaymentDao) {
        this.supplierPaymentDao = supplierPaymentDao;
    }

   
    public SupplierPayment getById(Long id) {
        return supplierPaymentDao.getById(id);
    }

    public List<SupplierPayment> getAllSupplierPayments() {
     
        return supplierPaymentDao.getAllSupplierPayments();
    }
    public List<SupplierPayment> getBySupplier(Supplier supplier) {
        return supplierPaymentDao.getBySupplier(supplier);
    }

 
    public List<SupplierPayment> getByPartUsed(RepairPartsUsed partUsed) {
        return supplierPaymentDao.getByPartUsed(partUsed);
    }


    public void updatePaymentDateByIds(Long[] ids, Date newDate) {
        supplierPaymentDao.updatePaymentDateByIds(ids, newDate);
    }

  
    public void saveOrUpdate(SupplierPayment payment) {
        supplierPaymentDao.save(payment);
    }
    public List<SupplierPayment> getUnpaidSupplierPayments() {
      
        return supplierPaymentDao.getUnpaidSupplierPayments();
    }
}
