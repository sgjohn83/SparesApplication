package com.spares.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spares.dao.CompletedSupplierPaymentDAO;
import com.spares.model.CompletedSupplierPayment;

@Service
public class CompletedSupplierPaymentService{

    @Autowired
	private CompletedSupplierPaymentDAO completedSupplierPaymentDAO;

    public void setCompletedSupplierPaymentDAO(CompletedSupplierPaymentDAO dao) {
        this.completedSupplierPaymentDAO = dao;
    }

  
    public List<CompletedSupplierPayment> getAllPayments() {
        return completedSupplierPaymentDAO.findAll();
    }
}

