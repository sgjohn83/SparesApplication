package com.spares.service;



import com.spares.dao.AvailablePartStockDao;
import com.spares.model.AvailablePartStock;
import com.spares.service.AvailablePartStockService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class AvailablePartStockService {

    @Autowired
    private AvailablePartStockDao availablePartStockDao;


    @Transactional(readOnly = true)
    public List<AvailablePartStock> getAvailableParts() {
        return availablePartStockDao.findAllAvailableParts();
    }
}
