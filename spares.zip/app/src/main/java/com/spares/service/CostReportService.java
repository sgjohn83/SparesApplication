package com.spares.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spares.dao.CostReportDao;
import com.spares.model.CostReportModel;

import java.util.List;

@Service
public class CostReportService {

    @Autowired
	private final CostReportDao summaryDao;

    public CostReportService(CostReportDao summaryDao) {
        this.summaryDao = summaryDao;
    }

   
    public List<CostReportModel> getAllSummaries() {
        return summaryDao.findAll();
    }

   
    public List<CostReportModel> getSummariesBySupplier(String supplierName) {
        return summaryDao.findBySupplier(supplierName);
    }

  
    public List<CostReportModel> getSummariesByBrand(String brandName) {
        return summaryDao.findByBrand(brandName);
    }
}
