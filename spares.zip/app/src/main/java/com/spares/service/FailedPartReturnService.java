package com.spares.service;



import com.spares.dao.FailedPartReturnDAO;
import com.spares.model.FailedPartReturn;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FailedPartReturnService {

    @Autowired
    private FailedPartReturnDAO failedPartReturnDAO;

    public FailedPartReturn save(FailedPartReturn entity) {
        return failedPartReturnDAO.save(entity);
    }

    public FailedPartReturn update(FailedPartReturn entity) {
        return failedPartReturnDAO.update(entity);
    }

    public void delete(Long id) {
        failedPartReturnDAO.delete(id);
    }

    public FailedPartReturn getById(Long id) {
        return failedPartReturnDAO.findById(id);
    }

    public List<FailedPartReturn> getAll() {
        return failedPartReturnDAO.findAll();
    }
    public List<FailedPartReturn> getReturnItems() {
        return failedPartReturnDAO.getItemsWithNoReturnDate();
    }
    public void updateDates(Long[] id)
    {
    	 failedPartReturnDAO.updateReturnDatesByIds(id);
    }
}

