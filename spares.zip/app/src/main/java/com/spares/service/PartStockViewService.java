package com.spares.service;

import com.spares.dao.PartStockViewDAO;
import com.spares.model.PartStockView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PartStockViewService {

    @Autowired
    private PartStockViewDAO partStockViewDAO;

    public List<PartStockView> getCurrentStock() {
        return partStockViewDAO.getCurrentStock();
    }
}
