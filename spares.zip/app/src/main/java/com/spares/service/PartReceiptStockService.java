package com.spares.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spares.dao.PartReceiptStockDao;
import com.spares.model.PartReceiptStock;

@Service
@Transactional
public class PartReceiptStockService {

    @Autowired
    private PartReceiptStockDao partReceiptStockDao;

    
    public int getRemainingQuantity(Long receiptId) {
        return partReceiptStockDao.getRemainingQuantityByReceiptId(receiptId);
    }
    public List<PartReceiptStock> getAllPartReceiptStocks() 
    {
		return partReceiptStockDao.getAllPartReceiptStocks();
    	
    }
}
