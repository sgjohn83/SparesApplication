package com.spares.service;



import com.spares.dao.MobileRepairDAO;
import com.spares.model.MobileRepair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MobileRepairService {

    @Autowired
    private MobileRepairDAO mobileRepairDAO;

    public MobileRepair save(MobileRepair repair) {
        return mobileRepairDAO.save(repair);
    }

    public List<MobileRepair> getAllRepairs() {
        return mobileRepairDAO.findAll();
    }

    public MobileRepair getById(Long id) {
        return mobileRepairDAO.findById(id);
    }

    public void update(MobileRepair repair) {
        mobileRepairDAO.update(repair);
    }

    public void delete(Long id) {
        mobileRepairDAO.delete(id);
    }
}

