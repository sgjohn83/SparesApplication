package com.spares.service;

import com.spares.dao.PartReceiptDAO;
import com.spares.model.Brand;
import com.spares.model.Model;
import com.spares.model.Part;
import com.spares.model.PartReceipt;
import com.spares.model.Supplier;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PartReceiptService {

	@Autowired
	private PartReceiptDAO partReceiptDAO;

	public PartReceipt save(PartReceipt receipt) {
		return partReceiptDAO.save(receipt);
	}

	public List<PartReceipt> getAllReceipts() {
		return partReceiptDAO.findAll();
	}

	public PartReceipt getById(Long id) {
		return partReceiptDAO.findById(id);
	}

	public void delete(Long id) {
		partReceiptDAO.delete(id);
	}

	public void update(PartReceipt receipt) {
		partReceiptDAO.update(receipt);
	}

	public List<PartReceipt> getBySupplier(Supplier supplier) {
		return partReceiptDAO.findBySupplier(supplier);
	}

	// Service method to get parts by supplier (via DAO)
	public List<Part> getPartsBySupplier(Supplier supplier) {
		return partReceiptDAO.findPartsBySupplier(supplier);
	}

	// Find part receipts by supplier and part
	public List<PartReceipt> findBySupplierAndPart(Supplier supplier, Part part) {
		return partReceiptDAO.findBySupplierAndPart(supplier, part);
	}

	public List<Brand> getBrandsBySupplier(Supplier supplier) {

		return partReceiptDAO.getBrandsBySupplier(supplier);

	}

	public List<Model> getModelsByBrands(Brand brand) {

		return partReceiptDAO.getModelsByBrands(brand);

	}

	public List<Part> getPartsByModelsAndSupplier(Supplier supplier, Model model) {

		return partReceiptDAO.getPartsByModelsAndSupplier(supplier, model);

	}

	public List<PartReceipt> getPartReceiptsByPart(Part part,Supplier supplier, Model model) {

		return partReceiptDAO.getPartReceiptsByPart(part,supplier,model);

	}

}
