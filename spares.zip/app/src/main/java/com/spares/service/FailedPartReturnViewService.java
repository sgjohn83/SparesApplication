package com.spares.service;


import com.spares.dao.FailedPartReturnViewDAO;
import com.spares.model.FailedPartReturnView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FailedPartReturnViewService {

    @Autowired
    private FailedPartReturnViewDAO failedPartReturnDAO;

    public List<FailedPartReturnView> getFailedPartReturns() {
        return failedPartReturnDAO.getFailedPartReturns();
    }
}
