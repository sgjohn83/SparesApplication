package com.spares.service;

import com.spares.dao.SupplierPaymentSummaryDao;
import com.spares.model.SupplierPaymentSummaryView;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class SupplierPaymentSummaryService {

    private final SupplierPaymentSummaryDao dao;

    public SupplierPaymentSummaryService(SupplierPaymentSummaryDao dao) {
        this.dao = dao;
    }

    @Transactional(readOnly = true)
    public List<SupplierPaymentSummaryView> getAllSummaries() {
        return dao.getAll();
    }

    @Transactional(readOnly = true)
    public SupplierPaymentSummaryView getBySupplierId(Long id) {
        return dao.getById(id);
    }

    @Transactional(readOnly = true)
    public List<SupplierPaymentSummaryView> getFilteredByBalance(double minBalance) {
        return dao.getWithMinBalance(minBalance);
    }
}
