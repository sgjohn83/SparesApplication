package com.spares.dao;





import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spares.model.RepairPartsUsed;
import com.spares.model.Supplier;
import com.spares.model.SupplierPayment;

import java.util.Date;
import java.util.List;

@Repository
public class SupplierPaymentDao {

    @Autowired
	private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public SupplierPayment getById(Long id) {
        Session session = sessionFactory.openSession();
        SupplierPayment payment = (SupplierPayment) session.get(SupplierPayment.class, id);
        session.close();
        return payment;
    }
    @SuppressWarnings("unchecked")
    public List<SupplierPayment> getUnpaidSupplierPayments() {
        Session session = sessionFactory.getCurrentSession();
        String hql = "FROM SupplierPayment WHERE paymentDate IS NULL";
        return session.createQuery(hql).list();
    }


    @SuppressWarnings("unchecked")
    public List<SupplierPayment> getBySupplier(Supplier supplier) {
        Session session = sessionFactory.openSession();
        Query<SupplierPayment> query = session.createQuery(
            "from SupplierPayment sp where sp.supplier = :supplier"
        );
        query.setParameter("supplier", supplier);
        List<SupplierPayment> list = query.list();
        session.close();
        return list;
    }


    @SuppressWarnings("unchecked")
    public List<SupplierPayment> getByPartUsed(RepairPartsUsed partUsed) {
        Session session = sessionFactory.openSession();
        Query<SupplierPayment> query = session.createQuery(
            "from SupplierPayment sp where sp.partUsed = :partUsed"
        );
        query.setParameter("partUsed", partUsed);
        List<SupplierPayment> list = query.list();
        session.close();
        return list;
    }
    
    @SuppressWarnings("unchecked")
    public List<SupplierPayment> getAllSupplierPayments() {
        Session session = sessionFactory.openSession();
        List<SupplierPayment> list = session.createQuery("from SupplierPayment").list();
        session.close();
        return list;
    }



    public void updatePaymentDateByIds(Long[] ids, Date newDate) {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        Query query = session.createQuery("update SupplierPayment set paymentDate = :date where paymentId in (:ids)");
        query.setParameter("date", newDate);
        query.setParameterList("ids", ids);
        query.executeUpdate();
        tx.commit();
        session.close();
    }

    public void save(SupplierPayment payment) {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        session.saveOrUpdate(payment);
        tx.commit();
        session.close();
    }
}
