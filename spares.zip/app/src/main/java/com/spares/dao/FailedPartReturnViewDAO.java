package com.spares.dao;

import com.spares.model.FailedPartReturnView;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Repository
public class FailedPartReturnViewDAO {

    @Autowired
    private SessionFactory sessionFactory;

    public List<FailedPartReturnView> getFailedPartReturns() {
        Session session = sessionFactory.openSession();

        String sql = "SELECT s.name AS supplier_name, p.name AS part_name, " +
                     "rpu.quantity_used AS quantity_to_return, fpr.return_date " +
                     "FROM repair_parts_used rpu " +
                     "JOIN parts p ON rpu.part_id = p.part_id " +
                     "JOIN suppliers s ON rpu.supplier_id = s.supplier_id " +
                     "JOIN failed_parts_returns fpr ON rpu.id = fpr.repair_part_used_id";

        Query query = session.createNativeQuery(sql);
        List<Object[]> results = query.getResultList();
        List<FailedPartReturnView> failedReturns = new ArrayList<>();

        for (Object[] row : results) {
            String supplierName = (String) row[0];
            String partName = (String) row[1];
            Number qty = (Number) row[2];
            Date returnDate = (Date) row[3];

            failedReturns.add(new FailedPartReturnView(
                supplierName,
                partName,
                qty != null ? qty.intValue() : 0,
                returnDate
            ));
        }

        session.close();
        return failedReturns;
    }
}
