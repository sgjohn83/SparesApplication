package com.spares.dao;

import com.spares.model.SupplierPaymentSummaryView;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class SupplierPaymentSummaryDao {

    private final SessionFactory sessionFactory;

    public SupplierPaymentSummaryDao(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public List<SupplierPaymentSummaryView> getAll() {
        Session session = sessionFactory.getCurrentSession();
        Query<SupplierPaymentSummaryView> query = session.createQuery(
                "FROM SupplierPaymentSummaryView", SupplierPaymentSummaryView.class);
        return query.list();
    }

    public SupplierPaymentSummaryView getById(Long supplierId) {
        Session session = sessionFactory.getCurrentSession();
        return session.get(SupplierPaymentSummaryView.class, supplierId);
    }

    public List<SupplierPaymentSummaryView> getWithMinBalance(double minBalance) {
        Session session = sessionFactory.getCurrentSession();
        Query<SupplierPaymentSummaryView> query = session.createQuery(
                "FROM SupplierPaymentSummaryView WHERE balance >= :minBalance", SupplierPaymentSummaryView.class);
        query.setParameter("minBalance", minBalance);
        return query.list();
    }
}
