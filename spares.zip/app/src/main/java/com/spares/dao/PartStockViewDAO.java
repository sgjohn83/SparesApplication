package com.spares.dao;

import com.spares.model.PartStockView;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class PartStockViewDAO {

    @Autowired
    private SessionFactory sessionFactory;

    public List<PartStockView> getCurrentStock() {
        Session session = sessionFactory.openSession();
        List<PartStockView> list = session
            .createNamedQuery("from PartStockView", PartStockView.class)
            .getResultList();
        session.close();
        return list;
    }
}
