package com.spares.dao;



import com.spares.model.MobileRepair;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class MobileRepairDAO {

    @Autowired
    private SessionFactory sessionFactory;

    public MobileRepair save(MobileRepair repair) {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        session.save(repair);
        tx.commit();
        session.close();
        return repair;
    }

    public List<MobileRepair> findAll() {
        Session session = sessionFactory.openSession();
        List<MobileRepair> list = session
            .createQuery("from MobileRepair order by repairDate desc", MobileRepair.class)
            .list();
        session.close();
        return list;
    }


    public MobileRepair findById(Long id) {
        Session session = sessionFactory.openSession();
        MobileRepair repair = session.get(MobileRepair.class, id);
        session.close();
        return repair;
    }

    public void update(MobileRepair repair) {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        session.update(repair);
        tx.commit();
        session.close();
    }

    public void delete(Long id) {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        MobileRepair repair = session.get(MobileRepair.class, id);
        if (repair != null) {
            session.delete(repair);
        }
        tx.commit();
        session.close();
    }
}

