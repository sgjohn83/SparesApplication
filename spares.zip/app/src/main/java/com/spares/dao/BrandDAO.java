package com.spares.dao;




import org.hibernate.SessionFactory;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.spares.model.Brand;

import java.util.List;

@Repository
@Transactional
public class BrandDAO  {

    @Autowired
    private SessionFactory sessionFactory;

    protected Session getSession() {
        return sessionFactory.getCurrentSession();
    }


    public void save(Brand brand) {
        getSession().save(brand);
    }

   
    public void update(Brand brand) {
        getSession().update(brand);
    }


    public void delete(Brand brand) {
        getSession().delete(brand);
    }

 
    public Brand findById(Long id) {
        return (Brand) getSession().get(Brand.class, id);
    }

    @SuppressWarnings("unchecked")
  
    public List<Brand> findAll() {
        Query<Brand> query = getSession().createQuery("from Brand");
        return query.list();
    }
}
