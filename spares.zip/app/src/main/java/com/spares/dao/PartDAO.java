package com.spares.dao;



import com.spares.model.Part;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class PartDAO {

    @Autowired
    private SessionFactory sessionFactory;

    public Part save(Part part) {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        session.save(part);
        tx.commit();
        session.close();
        return part;
    }

    public Part update(Part part) {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        session.update(part);
        tx.commit();
        session.close();
        return part;
    }

    public void delete(Long id) {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        Part part = session.get(Part.class, id);
        if (part != null) {
            session.delete(part);
        }
        tx.commit();
        session.close();
    }

    public Part findById(Long id) {
        Session session = sessionFactory.openSession();
        Part part = session.get(Part.class, id);
        session.close();
        return part;
    }
    public Part findByName(String name) {
        Session session = sessionFactory.openSession();
        Part part = (Part) session.createQuery("FROM Part WHERE name = :name")
                                  .setParameter("name", name)
                                  .uniqueResult();
        session.close();
        return part;
    }


    public List<Part> findAll() {
        Session session = sessionFactory.openSession();
        List<Part> list = session.createQuery("from Part", Part.class).list();
        session.close();
        return list;
    }
}

