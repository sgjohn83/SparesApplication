package com.spares.dao;



import java.util.List;
import org.hibernate.SessionFactory;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.spares.model.Model;

@Repository
public class ModelDao {

    @Autowired
    private SessionFactory sessionFactory;

    private Session getSession() {
        return sessionFactory.getCurrentSession();
    }

    public void save(Model model) {
        getSession().save(model);
    }

    public void update(Model model) {
        getSession().update(model);
    }

    public void delete(Model model) {
        getSession().delete(model);
    }

    public Model findById(Long id) {
        return (Model) getSession().get(Model.class, id);
    }

    @SuppressWarnings("unchecked")
    public List<Model> findAll() {
        return getSession().createQuery("from Model").list();
    }

    @SuppressWarnings("unchecked")
    public List<Model> findByBrandId(Long brandId) {
        return getSession()
                .createQuery("from Model where brand.brandId = :brandId")
                .setParameter("brandId", brandId)
                .list();
    }
}
