package com.spares.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spares.model.PartReceiptStock;

@Repository
public class PartReceiptStockDao {

    @Autowired
    private SessionFactory sessionFactory;

    
    public int getRemainingQuantityByReceiptId(Long receiptId) {
        Session session = sessionFactory.getCurrentSession();
        String hql = "SELECT prs.quantityReceived - prs.quantityUsed FROM PartReceiptStock prs WHERE prs.receipt.receiptId = :receiptId";
        Integer remaining = (Integer) session.createQuery(hql)
                .setParameter("receiptId", receiptId)
                .uniqueResult();
        return remaining != null ? remaining : 0;
    }
    public List<PartReceiptStock> getAllPartReceiptStocks() {
        Session session = sessionFactory.getCurrentSession();
        String hql = "FROM PartReceiptStock";
        return session.createQuery(hql, PartReceiptStock.class).list();
    }
}
