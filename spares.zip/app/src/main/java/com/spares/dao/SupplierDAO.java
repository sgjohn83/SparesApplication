package com.spares.dao;



import com.spares.model.Supplier;
import org.hibernate.SessionFactory;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class SupplierDAO {

    @Autowired
    private SessionFactory sessionFactory;

    public Supplier save(Supplier supplier) {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        session.save(supplier);
        tx.commit();
        session.close();
        return supplier;
    }

    public Supplier update(Supplier supplier) {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        session.update(supplier);
        tx.commit();
        session.close();
        return supplier;
    }

    public void delete(Long id) {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        Supplier supplier = session.get(Supplier.class, id);
        if (supplier != null) {
            session.delete(supplier);
        }
        tx.commit();
        session.close();
    }

    public Supplier findById(Long id) {
        Session session = sessionFactory.openSession();
        Supplier supplier = session.get(Supplier.class, id);
        session.close();
        return supplier;
    }
    public Supplier findByName(String name) {
        Session session = sessionFactory.openSession();
        Supplier supplier = (Supplier) session.createQuery("FROM Supplier WHERE name = :name")
                                              .setParameter("name", name)
                                              .uniqueResult();
        session.close();
        return supplier;
    }


    public List<Supplier> findAll() {
        Session session = sessionFactory.openSession();
        List<Supplier> list = session.createQuery("from Supplier", Supplier.class).list();
        session.close();
        return list;
    }
}
