package com.spares.dao;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spares.model.CompletedSupplierPayment;

import java.util.List;
@Repository
public class CompletedSupplierPaymentDAO {

    @Autowired
	private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @SuppressWarnings("unchecked")
    public List<CompletedSupplierPayment> findAll() {
        Session session = sessionFactory.openSession();
        Transaction tx = null;
        List<CompletedSupplierPayment> results = null;

        try {
            tx = session.beginTransaction();
            results = session.createQuery("FROM CompletedSupplierPayment").list();
            tx.commit();
        } catch (RuntimeException e) {
            if (tx != null) tx.rollback();
            throw e;
        } finally {
            session.close();
        }

        return results;
    }
}

