package com.spares.dao;

import com.spares.model.AvailablePartStock;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class AvailablePartStockDao {

    @Autowired
    private SessionFactory sessionFactory;

    public List<AvailablePartStock> findAllAvailableParts() {
        Session session = sessionFactory.getCurrentSession();
        Query<AvailablePartStock> query = session.createQuery("FROM AvailablePartStock", AvailablePartStock.class);
        return query.getResultList();
    }
}
