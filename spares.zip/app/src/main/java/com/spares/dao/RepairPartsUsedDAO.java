package com.spares.dao;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.JOptionPane;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spares.model.Part;
import com.spares.model.PartReceipt;
import com.spares.model.RepairPartsUsed;
import com.spares.model.RepairPartsUsedResult;
import com.spares.model.Supplier;

@Repository
public class RepairPartsUsedDAO {

    @Autowired
    private SessionFactory sessionFactory;

    private Session getSession() {
        return sessionFactory.getCurrentSession();
    }

    public RepairPartsUsed save(RepairPartsUsed repairPartUsed) throws SQLException {
       
    	getSession().persist(repairPartUsed);
		return repairPartUsed;
		
    	
    }

    public RepairPartsUsed findById(Long id) {
        return getSession().get(RepairPartsUsed.class, id);
    }

    public List<RepairPartsUsed> findAll() {
        return getSession().createQuery("FROM RepairPartsUsed order by ID desc", RepairPartsUsed.class).getResultList();
   
    }

    public void update(RepairPartsUsed repairPartUsed) {
        getSession().merge(repairPartUsed);
    }

    public void delete(Long id) {
        RepairPartsUsed entity = getSession().get(RepairPartsUsed.class, id);
        System.out.println("before Removing "+id);
        if (entity != null) {
        	System.out.println("Removing "+id);
            getSession().remove(entity);
        }
    }

    public List<Part> findAllUsedParts() {
        return getSession().createQuery(
            "SELECT DISTINCT r.part FROM RepairPartsUsed r WHERE r.part IS NOT NULL", Part.class)
            .getResultList();
    }

    public List<Supplier> findAllUsedSuppliers() {
        return getSession().createQuery(
            "SELECT DISTINCT r.supplier FROM RepairPartsUsed r WHERE r.supplier IS NOT NULL", Supplier.class)
            .getResultList();
    }

    public List<PartReceipt> findAllUsedReceipts() {
        return getSession().createQuery(
            "SELECT DISTINCT r.receipt FROM RepairPartsUsed r WHERE r.receipt IS NOT NULL", PartReceipt.class)
            .getResultList();
    }
    public String getCommaSeparatedPartNamesByRepairId(Long repairId) {
        Session session = sessionFactory.getCurrentSession();

        String hql = "SELECT rpu.part.name FROM RepairPartsUsed rpu WHERE rpu.repair.id = :repairId";
        Query<String> query = session.createQuery(hql, String.class);
        query.setParameter("repairId", repairId);

        List<String> partNames = query.getResultList();

        if (partNames == null || partNames.isEmpty()) {
            return "None";
        }

        return String.join(", ", partNames);
    }
    public List<RepairPartsUsed> getByReceiptId(Long receiptId) {
        try (Session session = sessionFactory.openSession()) {
            String hql = "FROM RepairPartsUsed r WHERE r.receipt.id = :receiptId";
            Query<RepairPartsUsed> query = session.createQuery(hql, RepairPartsUsed.class);
            query.setParameter("receiptId", receiptId);
            return query.list();
        }
    }
    public List<RepairPartsUsedResult> getByReceiptId1(Long receiptId) {
        try (Session session = sessionFactory.openSession()) {
            String hql =
                "SELECT r, " +
                "CASE WHEN r.status = 'USED' THEN sp.paymentDate " +
                "     WHEN r.status = 'FAILED' THEN fr.returnDate " +
                "     ELSE NULL END " +
                "FROM RepairPartsUsed r " +
                "LEFT JOIN SupplierPayment sp ON r.id = sp.partUsed.id " +
                "LEFT JOIN FailedPartReturn fr ON r.id = fr.repairPartUsed.id " +
                "WHERE r.receipt.id = :receiptId";

            Query<Object[]> query = session.createQuery(hql, Object[].class);
            query.setParameter("receiptId", receiptId);

            List<Object[]> rawResults = query.list();
            List<RepairPartsUsedResult> results = new ArrayList<>();

            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy HH:mm");

            for (Object[] row : rawResults) {
                RepairPartsUsed partUsed = (RepairPartsUsed) row[0];
                Date date = (Date) row[1];

                String displayDateStr = (date != null) ? formatter.format(date) : "N/A";
                results.add(new RepairPartsUsedResult(partUsed, displayDateStr));
            }

            return results;
        }
    }



}
