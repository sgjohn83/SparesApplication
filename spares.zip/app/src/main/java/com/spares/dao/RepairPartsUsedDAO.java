package com.spares.dao;

import java.sql.SQLException;
import java.util.List;

import javax.swing.JOptionPane;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spares.model.Part;
import com.spares.model.PartReceipt;
import com.spares.model.RepairPartsUsed;
import com.spares.model.Supplier;

@Repository
public class RepairPartsUsedDAO {

    @Autowired
    private SessionFactory sessionFactory;

    private Session getSession() {
        return sessionFactory.getCurrentSession();
    }

    public RepairPartsUsed save(RepairPartsUsed repairPartUsed) throws SQLException {
       
    	getSession().persist(repairPartUsed);
		return repairPartUsed;
		
    	
    }

    public RepairPartsUsed findById(Long id) {
        return getSession().get(RepairPartsUsed.class, id);
    }

    public List<RepairPartsUsed> findAll() {
        return getSession().createQuery("FROM RepairPartsUsed order by ID desc", RepairPartsUsed.class).getResultList();
   
    }

    public void update(RepairPartsUsed repairPartUsed) {
        getSession().merge(repairPartUsed);
    }

    public void delete(Long id) {
        RepairPartsUsed entity = getSession().get(RepairPartsUsed.class, id);
        System.out.println("before Removing "+id);
        if (entity != null) {
        	System.out.println("Removing "+id);
            getSession().remove(entity);
        }
    }

    public List<Part> findAllUsedParts() {
        return getSession().createQuery(
            "SELECT DISTINCT r.part FROM RepairPartsUsed r WHERE r.part IS NOT NULL", Part.class)
            .getResultList();
    }

    public List<Supplier> findAllUsedSuppliers() {
        return getSession().createQuery(
            "SELECT DISTINCT r.supplier FROM RepairPartsUsed r WHERE r.supplier IS NOT NULL", Supplier.class)
            .getResultList();
    }

    public List<PartReceipt> findAllUsedReceipts() {
        return getSession().createQuery(
            "SELECT DISTINCT r.receipt FROM RepairPartsUsed r WHERE r.receipt IS NOT NULL", PartReceipt.class)
            .getResultList();
    }
    public String getCommaSeparatedPartNamesByRepairId(Long repairId) {
        Session session = sessionFactory.getCurrentSession();

        String hql = "SELECT rpu.part.name FROM RepairPartsUsed rpu WHERE rpu.repair.id = :repairId";
        Query<String> query = session.createQuery(hql, String.class);
        query.setParameter("repairId", repairId);

        List<String> partNames = query.getResultList();

        if (partNames == null || partNames.isEmpty()) {
            return "None";
        }

        return String.join(", ", partNames);
    }
    public List<RepairPartsUsed> getByReceiptId(Long receiptId) {
        try (Session session = sessionFactory.openSession()) {
            String hql = "FROM RepairPartsUsed r WHERE r.receipt.id = :receiptId";
            Query<RepairPartsUsed> query = session.createQuery(hql, RepairPartsUsed.class);
            query.setParameter("receiptId", receiptId);
            return query.list();
        }
    }

}
