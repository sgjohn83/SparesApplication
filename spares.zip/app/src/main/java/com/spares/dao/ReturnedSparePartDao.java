package com.spares.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spares.model.ReturnedSparePart;

@Repository
public class ReturnedSparePartDao {

	@Autowired
	private SessionFactory sessionFactory;

	public List<ReturnedSparePart> getAllReturnedParts() {
		Session session = sessionFactory.getCurrentSession();
		String hql = "FROM ReturnedSparePart";
		return session.createQuery(hql, ReturnedSparePart.class).getResultList();
	}

	public List<String> fetchSupplierNames() {
		Session session = sessionFactory.getCurrentSession();
		return session.createQuery("SELECT DISTINCT r.supplier FROM ReturnedSparePart r", String.class).getResultList();

	}
}
