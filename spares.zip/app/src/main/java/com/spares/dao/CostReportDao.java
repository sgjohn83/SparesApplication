package com.spares.dao;


import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spares.model.CostReportModel;

import javax.transaction.Transactional;
import java.util.List;

@Repository
@Transactional
public class CostReportDao {

    @Autowired
	private final SessionFactory sessionFactory;

    public CostReportDao(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    
    public List<CostReportModel> findAll() {
        return sessionFactory.getCurrentSession()
                .createQuery("FROM CostReportModel", CostReportModel.class)
                .getResultList();
    }

    
    public List<CostReportModel> findBySupplier(String supplierName) {
        Query<CostReportModel> query = sessionFactory.getCurrentSession()
                .createQuery("FROM CostReportModel WHERE supplierName = :supplier", CostReportModel.class);
        query.setParameter("supplier", supplierName);
        return query.getResultList();
    }

    
    public List<CostReportModel> findByBrand(String brandName) {
        Query<CostReportModel> query = sessionFactory.getCurrentSession()
                .createQuery("FROM CostReportModel WHERE brandName = :brand", CostReportModel.class);
        query.setParameter("brand", brandName);
        return query.getResultList();
    }
}
