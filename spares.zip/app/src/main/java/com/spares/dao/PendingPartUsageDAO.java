package com.spares.dao;

import com.spares.model.PendingPartUsageView;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;

@Repository
public class PendingPartUsageDAO {

    @Autowired
    private SessionFactory sessionFactory;

    public List<PendingPartUsageView> getPendingPartUsage() {
        Session session = sessionFactory.openSession();

        String sql = "SELECT p.name AS part_name, SUM(rpu.quantity_used) AS pending_quantity " +
                     "FROM repair_parts_used rpu " +
                     "JOIN mobile_repairs mr ON rpu.repair_id = mr.repair_id " +
                     "JOIN parts p ON rpu.part_id = p.part_id " +
                     "WHERE mr.status = 'PENDING' AND rpu.status = 'USED' " +
                     "GROUP BY p.name";

        Query query = session.createNativeQuery(sql);

        List<Object[]> results = query.getResultList();
        List<PendingPartUsageView> pendingParts = new ArrayList<>();

        for (Object[] row : results) {
            String partName = (String) row[0];
            Number quantity = (Number) row[1];
            pendingParts.add(new PendingPartUsageView(partName, quantity != null ? quantity.longValue() : 0L));
        }

        session.close();
        return pendingParts;
    }
}

