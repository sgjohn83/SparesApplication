package com.spares.dao;



import com.spares.model.FailedPartReturn;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@Repository
public class FailedPartReturnDAO {

    @Autowired
    private SessionFactory sessionFactory;

    public FailedPartReturn save(FailedPartReturn failedReturn) {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        session.save(failedReturn);
        tx.commit();
        session.close();
        return failedReturn;
    }

    public FailedPartReturn update(FailedPartReturn failedReturn) {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        session.update(failedReturn);
        tx.commit();
        session.close();
        return failedReturn;
    }

    public void delete(Long id) {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        FailedPartReturn entity = session.get(FailedPartReturn.class, id);
        if (entity != null) {
            session.delete(entity);
        }
        tx.commit();
        session.close();
    }

    public FailedPartReturn findById(Long id) {
        Session session = sessionFactory.openSession();
        FailedPartReturn entity = session.get(FailedPartReturn.class, id);
        session.close();
        return entity;
    }

    public List<FailedPartReturn> findAll() {
        Session session = sessionFactory.openSession();
        List<FailedPartReturn> list = session.createQuery("from FailedPartReturn", FailedPartReturn.class).list();
        session.close();
        return list;
    }

    @SuppressWarnings("unchecked")
    public List<FailedPartReturn> getItemsWithNoReturnDate() {
        Session session = null;
        Transaction tx = null;
        List<FailedPartReturn> resultList = new ArrayList<FailedPartReturn>();

        try {
            session = sessionFactory.openSession();
            tx = session.beginTransaction();

            @SuppressWarnings("deprecation")
			Query<FailedPartReturn> query = session.createQuery("FROM FailedPartReturn WHERE returnDate IS NULL");
            resultList = query.list();

            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        } finally {
            if (session != null) session.close();
        }

        return resultList;
    }
    public void updateReturnDatesByIds(Long[] returnIds) {
        if (returnIds == null || returnIds.length == 0) {
            return;
        }

        Session session = null;
        Transaction tx = null;

        try {
            session = sessionFactory.openSession();  // manually open session
            tx = session.beginTransaction();         // start transaction

            Query query = session.createQuery(
                "update FailedPartReturn set returnDate = :currentDate where returnId in (:ids)"
            );
            query.setParameter("currentDate", new Date());
            query.setParameterList("ids", Arrays.asList(returnIds));  // convert array to list
            query.executeUpdate();

            tx.commit();  // commit transaction
        } catch (Exception e) {
            if (tx != null) tx.rollback();  // rollback if error
            throw new RuntimeException("Failed to update return dates", e);
        } finally {
            if (session != null) session.close();  // always close session
        }
        
    }

}

