package com.spares.dao;

import com.spares.model.Brand;
import com.spares.model.Model;
import com.spares.model.Part;
import com.spares.model.PartReceipt;
import com.spares.model.Supplier;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public class PartReceiptDAO {

    @Autowired
    private SessionFactory sessionFactory;

    private Session getSession() {
        return sessionFactory.getCurrentSession();
    }

    @Transactional
    public PartReceipt save(PartReceipt receipt) {
        getSession().persist(receipt);
        return receipt;
    }

    @Transactional(readOnly = true)
    public List<PartReceipt> findAll() {
        Query<PartReceipt> query = getSession().createQuery("FROM PartReceipt order by receiptId desc", PartReceipt.class);
        return query.getResultList();
    }

    @Transactional(readOnly = true)
    public PartReceipt findById(Long id) {
        return getSession().get(PartReceipt.class, id);
    }

    @Transactional(readOnly = true)
    public List<PartReceipt> findBySupplier(Supplier supplier) {
        Query<PartReceipt> query = getSession().createQuery(
                "FROM PartReceipt WHERE supplier = :supplier", PartReceipt.class);
        query.setParameter("supplier", supplier);
        return query.getResultList();
    }

    @Transactional(readOnly = true)
    public List<PartReceipt> findBySupplierId(Long supplierId) {
        Query<PartReceipt> query = getSession().createQuery(
                "FROM PartReceipt WHERE supplier.id = :supplierId", PartReceipt.class);
        query.setParameter("supplierId", supplierId);
        return query.getResultList();
    }

    @Transactional
    public void delete(Long id) {
        PartReceipt receipt = getSession().get(PartReceipt.class, id);
        if (receipt != null) {
            getSession().remove(receipt);
        }
    }
    @Transactional
    public void update(PartReceipt receipt) {
        getSession().merge(receipt);
    }
    @Transactional(readOnly = true)
    public List<Part> findPartsBySupplier(Supplier supplier) {
        String hql = "SELECT DISTINCT pr.part FROM PartReceipt pr WHERE pr.supplier = :supplier";
        return getSession().createQuery(hql, Part.class)
                           .setParameter("supplier", supplier)
                           .getResultList();
    }

    @Transactional(readOnly = true)
    public List<PartReceipt> findBySupplierAndPart(Supplier supplier, Part part) {
        String hql = "FROM PartReceipt pr WHERE pr.supplier = :supplier AND pr.part = :part";
        return getSession().createQuery(hql, PartReceipt.class)
                           .setParameter("supplier", supplier)
                           .setParameter("part", part)
                           .getResultList();
    }
   
    public List<Brand> getBrandsBySupplier(Supplier supplier) {
        try (Session session = sessionFactory.openSession()) {
            String hql = " SELECT DISTINCT pr.model.brand FROM PartReceipt pr WHERE pr.supplier = :supplier";
            return session.createQuery(hql, Brand.class)
                          .setParameter("supplier", supplier)
                          .getResultList();
        }
    }
    public List<Model> getModelsByBrands(Brand brand) {
        try (Session session = sessionFactory.openSession()) {
            String hql = " SELECT DISTINCT pr.model FROM PartReceipt pr WHERE pr.model.brand = :brand";
            return session.createQuery(hql, Model.class)
                          .setParameter("brand", brand)
                          .getResultList();
        }
    }
    public List<Part> getPartsByModelsAndSupplier(Supplier supplier,Model model) {
        try (Session session = sessionFactory.openSession()) {
            String hql = " SELECT DISTINCT pr.part FROM PartReceipt pr WHERE pr.model = :model and pr.supplier=:supplier";
            return session.createQuery(hql, Part.class)
                          .setParameter("model", model)
                          .setParameter("supplier", supplier)
                          .getResultList();
        }
    }
    public List<PartReceipt> getPartReceiptsByPart(Part part,Supplier supplier,Model model) {
        try (Session session = sessionFactory.openSession()) {
            String hql = "FROM PartReceipt pr  WHERE pr.model = :model and pr.supplier=:supplier and pr.part = :part";
            return session.createQuery(hql, PartReceipt.class)
                          .setParameter("part", part)
                          .setParameter("model", model)
                          .setParameter("supplier", supplier)
                          .getResultList();
        }
    }
    
 



}
