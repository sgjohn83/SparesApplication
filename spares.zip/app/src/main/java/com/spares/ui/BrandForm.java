package com.spares.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spares.AppConfig;
import com.spares.model.Brand;
import com.spares.service.BrandService;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JDialog;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class BrandForm extends JDialog {

	private JPanel contentPane;
	private JTextField brandTxt;
	private BrandService brandService;
	private BrandView brandView;
	private AnnotationConfigApplicationContext context;
	


	/**
	 * Create the frame.
	 * @param brandView 
	 * @param brandService 
	 */
	public BrandForm(BrandService brandService, BrandView brandView) {
		
		this.brandService = brandService;
		this.brandView = brandView;
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 594, 361);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblBrandName = new JLabel("Brand Name");
		lblBrandName.setBounds(136, 92, 88, 14);
		contentPane.add(lblBrandName);
		
		brandTxt = new JTextField();
		brandTxt.setBounds(234, 89, 151, 20);
		contentPane.add(brandTxt);
		brandTxt.setColumns(10);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addBrand();
			}

			
		});
		btnAdd.setBounds(248, 139, 89, 23);
		contentPane.add(btnAdd);
		
		JLabel lblBrands = new JLabel("Brands");
		lblBrands.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblBrands.setBounds(256, 27, 94, 14);
		contentPane.add(lblBrands);
	}
	public BrandForm() {
		context = new AnnotationConfigApplicationContext(AppConfig.class);
		this.brandService = context.getBean(BrandService.class);
		this.brandView = null;
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 594, 361);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblBrandName = new JLabel("Brand Name");
		lblBrandName.setBounds(136, 92, 88, 14);
		contentPane.add(lblBrandName);
		
		brandTxt = new JTextField();
		brandTxt.setBounds(234, 89, 151, 20);
		contentPane.add(brandTxt);
		brandTxt.setColumns(10);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addBrand();
			}

			
		});
		btnAdd.setBounds(248, 139, 89, 23);
		contentPane.add(btnAdd);
		
		JLabel lblBrands = new JLabel("Brands");
		lblBrands.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblBrands.setBounds(256, 27, 94, 14);
		contentPane.add(lblBrands);

	}
	private void addBrand() {
	    
		Brand brand = new Brand();
		brand.setName(brandTxt.getText());
		brandService.saveBrand(brand);
		if(brandView!=null)
		brandView.loadBrandTable();
		JOptionPane.showMessageDialog(null, "Brand Added Sucessfully");
		this.dispose();
		
	}

}
