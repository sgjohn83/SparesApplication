package com.spares.ui;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import javax.swing.*;
import javax.swing.table.*;

public class JTableStyler {

    public static void styleTable(final JTable table, int... numericColumns) {
        table.setRowHeight(30);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 16));
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 1));
        table.getTableHeader().setReorderingAllowed(false);
        table.setAutoCreateRowSorter(true);

        // 1. Default zebra striping for non-numeric columns (and as a base for numeric)
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable tbl, Object value,
                                                           boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(tbl, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground((row % 2 == 0) ? new Color(245, 245, 255) : Color.WHITE);
                    c.setForeground(Color.BLACK); // Ensure default foreground for non-selected rows
                } else {
                    // Ensure selection colors are applied by super
                    c.setBackground(tbl.getSelectionBackground());
                    c.setForeground(tbl.getSelectionForeground());
                }
                // Reset border if any was set by a previous renderer for this component instance
                if (c instanceof JComponent) {
                    ((JComponent)c).setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5)); // Default padding
                }
                return c;
            }
        });

        // 2. Custom renderer for "start center align right" numeric columns
        for (int colIndex : numericColumns) {
            if (colIndex >= 0 && colIndex < table.getColumnCount()) {
                TableCellRenderer centerRightNumericRenderer = new TableCellRenderer() {
                    private final JPanel panel; // Main panel for the cell, uses GridBagLayout
                    private final JLabel label; // Label to display the number
                    private final JPanel contentPanel; // Panel to hold the label, this will be centered

                    // Instance initializer block for the renderer
                    {
                        panel = new JPanel(new GridBagLayout());
                        panel.setOpaque(true); // Main panel needs to be opaque for backgrounds

                        label = new JLabel();
                        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
                        label.setHorizontalAlignment(SwingConstants.RIGHT); // Number text is right-aligned within the label
                        label.setOpaque(true); // Label itself is opaque to show its own background

                        // contentPanel holds the label and defines the "block" for the number
                        contentPanel = new JPanel(new BorderLayout());
                        contentPanel.setOpaque(false); // Transparent, as label inside has the color
                        contentPanel.add(label, BorderLayout.CENTER);
                    }

                    @Override
                    public Component getTableCellRendererComponent(JTable tbl, Object value,
                                                                   boolean isSelected, boolean hasFocus,
                                                                   int row, int column) {

                        label.setText(value == null ? "" : value.toString());

                        // Set background and foreground colors for the label
                        if (isSelected) {
                            label.setBackground(tbl.getSelectionBackground());
                            label.setForeground(tbl.getSelectionForeground());
                            panel.setBackground(tbl.getSelectionBackground()); // Also set panel bg for uncovered areas
                        } else {
                            Color bgColor = (row % 2 == 0) ? new Color(245, 245, 255) : Color.WHITE;
                            label.setBackground(bgColor);
                            label.setForeground(Color.BLACK);
                            panel.setBackground(bgColor); // Also set panel bg for uncovered areas
                        }

                        // Define the width of the content block (e.g., 70% of column width)
                        // This block will be centered, and the number right-aligned within it.
                        int colWidth = tbl.getColumnModel().getColumn(column).getWidth();
                        int contentBlockWidth = (int) (colWidth * 0.70); // 70% of cell width for the number block
                        
                        // Ensure minimum width for very small columns, but allow shrinking
                        contentBlockWidth = Math.max(contentBlockWidth, Math.min(colWidth, label.getPreferredSize().width + 10)); // Add some padding
                        contentBlockWidth = Math.min(contentBlockWidth, colWidth); // Cannot exceed column width


                        // Set preferred size for the contentPanel that holds the label
                        // Height can be based on row height or label's preferred height
                        int rowHeight = tbl.getRowHeight(row);
                        contentPanel.setPreferredSize(new Dimension(contentBlockWidth, rowHeight > 0 ? rowHeight : label.getPreferredSize().height));

                        // Configure GridBagConstraints to center the contentPanel in the main panel
                        GridBagConstraints gbc = new GridBagConstraints();
                        gbc.anchor = GridBagConstraints.CENTER; // Center the contentPanel
                        gbc.weightx = 1.0; // Allow distribution of space if panel is larger
                        gbc.fill = GridBagConstraints.NONE; // Don't expand contentPanel, use its preferred size

                        // Remove previous components from panel before adding (important for renderer reuse)
                        panel.removeAll();
                        panel.add(contentPanel, gbc);

                        return panel;
                    }
                };
                table.getColumnModel().getColumn(colIndex).setCellRenderer(centerRightNumericRenderer);
            }
        }

        // 3. Tooltip for truncated text (remains unchanged)
        table.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                int rowIndex = table.rowAtPoint(e.getPoint());
                int colIndex = table.columnAtPoint(e.getPoint());
                if (rowIndex > -1 && colIndex > -1) {
                    Component rendererComponent = table.getCellRenderer(rowIndex, colIndex)
                                                       .getTableCellRendererComponent(table, 
                                                                                      table.getValueAt(rowIndex, colIndex), 
                                                                                      false, false, rowIndex, colIndex);
                    String text = "";
                    if (rendererComponent instanceof JLabel) {
                        text = ((JLabel)rendererComponent).getText();
                    } else if (table.getValueAt(rowIndex, colIndex) != null) {
                        text = table.getValueAt(rowIndex, colIndex).toString();
                    }

                    if (text == null) text = "";
                    
                    FontMetrics fm = table.getFontMetrics(rendererComponent.getFont());
                    int textWidth = fm.stringWidth(text);
                    
                    // Get cell rectangle, excluding insets if any (though default is none)
                    Rectangle cellRect = table.getCellRect(rowIndex, colIndex, true);
                    int availableWidth = cellRect.width;

                    // For the custom numeric renderer, the actual text is in a nested label.
                    // We need to estimate the width available to *that* label.
                    // If it's a numeric column using our custom renderer:
                    boolean isCustomNumericColumn = false;
                    for(int numColIdx : numericColumns) {
                        if (numColIdx == table.convertColumnIndexToModel(colIndex)) { // Use model index for numericColumns array
                             isCustomNumericColumn = true;
                             break;
                        }
                    }

                    if(isCustomNumericColumn && rendererComponent instanceof JPanel) {
                        // The text is in the inner JLabel, within a contentPanel of 70% width (approx)
                        // So, compare textWidth to roughly 70% of cellRect.width
                        // Or, more accurately, get the label's actual width if possible, but that's complex here.
                        // Let's use a pragmatic estimate for tooltip trigger.
                        availableWidth = (int)(cellRect.width * 0.70) - 10; // Subtract a bit for internal padding/borders
                    } else if (rendererComponent instanceof JComponent) {
                        Insets insets = ((JComponent)rendererComponent).getInsets();
                        availableWidth = cellRect.width - (insets.left + insets.right);
                    }


                    if (textWidth > availableWidth && availableWidth > 0) {
                        table.setToolTipText(text);
                    } else {
                        table.setToolTipText(null);
                    }
                } else {
                    table.setToolTipText(null);
                }
            }
        });
    }
}
