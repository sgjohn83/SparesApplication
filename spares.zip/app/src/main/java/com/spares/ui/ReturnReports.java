package com.spares.ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import com.spares.AppConfig;
import com.spares.model.ReturnedSparePart;
import com.spares.service.ReturnedSparePartService;
import com.toedter.calendar.JDateChooser;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

public class ReturnReports extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JComboBox<String> comboBox;
	private JDateChooser dateChooserFrom;
	private JDateChooser dateChooserTo;
	private JLabel lblSummary;
	private ReturnedSparePartService returnedSparePartService;

	public ReturnReports() {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		returnedSparePartService = context.getBean(ReturnedSparePartService.class);

		setTitle("Returned Spare Parts Report");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(850, 600);
		setLocationRelativeTo(null);

		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(15, 15, 15, 15));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(10, 10));

		// Filter Panel
		JPanel filterPanel = new JPanel();
		filterPanel.setLayout(new FlowLayout(FlowLayout.LEFT));

		dateChooserFrom = new JDateChooser();
		dateChooserTo = new JDateChooser();
		comboBox = new JComboBox<>();
		JButton btnLoad = new JButton("Load");

		filterPanel.add(new JLabel("From:"));
		filterPanel.add(dateChooserFrom);
		filterPanel.add(new JLabel("To:"));
		filterPanel.add(dateChooserTo);
		filterPanel.add(new JLabel("Supplier:"));
		filterPanel.add(comboBox);
		filterPanel.add(btnLoad);

		contentPane.add(filterPanel, BorderLayout.NORTH);

		// Table Panel
		table = new JTable();
		styleTableHeader(table);   
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setPreferredSize(new Dimension(800, 400));
		contentPane.add(scrollPane, BorderLayout.CENTER);

		// Summary Panel
		JPanel summaryPanel = new JPanel();
		summaryPanel.setLayout(new BorderLayout());
		lblSummary = new JLabel("Summary: ", SwingConstants.CENTER);
		lblSummary.setFont(new Font("Segoe UI", Font.BOLD, 14));
		lblSummary.setOpaque(true);
		lblSummary.setBackground(new Color(30, 30, 30));
		lblSummary.setForeground(Color.WHITE);
		lblSummary.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		summaryPanel.add(lblSummary, BorderLayout.CENTER);

		contentPane.add(summaryPanel, BorderLayout.SOUTH);

		btnLoad.addActionListener(this::loadData);
		loadSuppliers();
		loadData(null);
	}

	private void loadData(ActionEvent e) {
		Date from = dateChooserFrom.getDate();
		Date to = dateChooserTo.getDate();
		String supplier = comboBox.getSelectedItem().toString();

		List<ReturnedSparePart> parts = returnedSparePartService.fetchReturnedParts();

		// Filter by date
		if (from != null) {
			parts = parts.stream().filter(p -> !p.getReturnDate().before(from)).collect(Collectors.toList());
		}
		if (to != null) {
			parts = parts.stream().filter(p -> !p.getReturnDate().after(to)).collect(Collectors.toList());
		}

		// Filter by supplier
		if (!"All".equalsIgnoreCase(supplier)) {
			parts = parts.stream().filter(p -> supplier.equals(p.getSupplier())).collect(Collectors.toList());
		}

		updateTable(parts);
		updateSummary(parts);
	}

	private void updateTable(List<ReturnedSparePart> parts) {
		String[] columns = { "ID", "Supplier", "Brand", "Model", "Part Name", "Quantity", "Cost", "Return Date" };
		DefaultTableModel model = new DefaultTableModel(columns, 0);

		for (ReturnedSparePart part : parts) {
			model.addRow(new Object[] { part.getId(), part.getSupplier(), part.getBrand(), part.getModel(),
					part.getPartName(), part.getQuantity(), part.getCost(), part.getReturnDate() });
		}

		table.setModel(model);
		table.setRowHeight(25);
		table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
		table.getTableHeader().setBackground(new Color(60, 63, 65));
		table.getTableHeader().setForeground(Color.WHITE);

		DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
		renderer.setHorizontalAlignment(JLabel.CENTER);
		for (int i = 0; i < table.getColumnCount(); i++) {
			table.getColumnModel().getColumn(i).setCellRenderer(renderer);
		}

		table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
			private final Color even = new Color(245, 245, 245);
			private final Color odd = Color.WHITE;

			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {
				Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
				c.setBackground(row % 2 == 0 ? even : odd);
				return c;
			}
		});
	}

	

	private void updateSummary(List<ReturnedSparePart> parts) {
	    int totalParts = parts.size();
	    int totalQty = 0;
	    BigDecimal totalCost = BigDecimal.ZERO;

	    for (ReturnedSparePart part : parts) {
	        int qty = part.getQuantity();
	        BigDecimal cost =part.getCost();
	        totalQty += qty;
	        totalCost = totalCost.add(cost.multiply(BigDecimal.valueOf(qty)));
	    }

	    lblSummary.setText("Summary: Total Items = " + totalParts +
	            ", Total Quantity = " + totalQty +
	            ", Total Cost = ₹" + totalCost.setScale(2, BigDecimal.ROUND_HALF_UP).toPlainString());
	}


	private void loadSuppliers() {
		comboBox.removeAllItems();
		comboBox.addItem("All");
		List<String> supplierList = returnedSparePartService.fetchSupplierNames();
		for (String name : supplierList) {
			comboBox.addItem(name);
		}
	}
	private void styleTableHeader(JTable table) {
	    final Color headerBg = new Color(60, 63, 65);   // dark gray
	    final Color headerFg = Color.WHITE;
	    final Font  headerFt = new Font("Segoe UI", Font.BOLD, 14);

	    JTableHeader header = table.getTableHeader();
	    header.setDefaultRenderer(new DefaultTableCellRenderer() {

	        {   // constructor block – runs once
	            setOpaque(true);
	            setHorizontalAlignment(CENTER);
	            setBackground(headerBg);
	            setForeground(headerFg);
	            setFont(headerFt);
	        }

	        @Override                       // make sure per-cell calls still work
	        public Component getTableCellRendererComponent(
	                JTable tbl, Object value, boolean sel,
	                boolean foc, int row, int col) {
	            super.getTableCellRendererComponent(
	                    tbl, value, sel, foc, row, col);
	            return this;
	        }
	    });
	}

}
