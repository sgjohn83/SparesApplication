package com.spares.ui;

//Add these imports at the top
import ca.odell.glazedlists.swing.AutoCompleteSupport;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.matchers.TextMatcherEditor;
import ca.odell.glazedlists.BasicEventList;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spares.AppConfig;
import com.spares.model.*;
import com.spares.service.*;

import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class PartRecieptForm extends JDialog {
	private JComboBox<Supplier> supplierCombo;
	private JComboBox<Brand> brandCombo;
	private JComboBox<Model> modelCombo;
	private JComboBox<Part> partCombo;
	private JSpinner quantitySpinner;
	private JTextField costField;
	private PartRecieptView partRecieptView;
	private EventList<Model> modelEventList;
	private EventList<Part> partEventList;

	private PartReceiptService partReceiptService;
	private SupplierService supplierService;
	private BrandService brandService;
	private ModelService modelService;
	private PartService partService;
	private JPanel contentPane;
	private JButton addmodelBtn;

	public PartRecieptForm(PartReceiptService partReceiptService, PartRecieptView partRecieptView) {
		setUIFont(new Font("Segoe UI", Font.PLAIN, 20)); // Apply readable UI font globally

		this.partReceiptService = partReceiptService;
		this.partRecieptView = partRecieptView;
		this.setResizable(false);
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		supplierService = context.getBean(SupplierService.class);
		partService = context.getBean(PartService.class);
		brandService = context.getBean(BrandService.class);
		modelService = context.getBean(ModelService.class);

		setTitle("Add Part Receipt");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(550, 400);
		setLocationRelativeTo(null);

		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(20, 20, 20, 20));
		setContentPane(contentPane);

		JLabel lblSupplier = new JLabel("Supplier:");
		JLabel lblBrand = new JLabel("Brand:");
		JLabel lblModel = new JLabel("Model:");
		JLabel lblPart = new JLabel("Part:");
		JLabel lblQuantity = new JLabel("Quantity:");
		JLabel lblCost = new JLabel("Cost:");
		addmodelBtn = new JButton("Add Model");
		supplierCombo = new JComboBox<>();
		brandCombo = new JComboBox<>();
		modelCombo = new JComboBox<>();
		modelEventList = new BasicEventList<Model>();
		AutoCompleteSupport.install(modelCombo, modelEventList);

		addmodelBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				ModelForm m = new ModelForm(modelService, brandService, PartRecieptForm.this);
				m.setModal(true);
				m.setVisible(true);

			}
		});

		partCombo = new JComboBox<>();

		partEventList = new BasicEventList<Part>();
		AutoCompleteSupport.install(partCombo, partEventList);

		quantitySpinner = new JSpinner(new SpinnerNumberModel(1, 1, 10000, 1));
		costField = new JTextField();

		JButton btnAdd = new JButton("Add Receipt");
		btnAdd.setPreferredSize(new Dimension(140, 35));
		btnAdd.addActionListener(e -> addReceipt());
		// add button beside model combo named add model
		// make model auto complete using glazed list
		// Layout using GroupLayout for responsive, professional UI
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		contentPane.setLayout(gl_contentPane);
		gl_contentPane.setAutoCreateGaps(true);
		gl_contentPane.setAutoCreateContainerGaps(true);

		// horizontal group
		gl_contentPane.setHorizontalGroup(gl_contentPane.createParallelGroup()
				.addGroup(gl_contentPane.createSequentialGroup().addGroup(gl_contentPane
						.createParallelGroup(GroupLayout.Alignment.TRAILING).addComponent(lblSupplier)
						.addComponent(lblBrand).addComponent(lblModel).addComponent(lblPart).addComponent(lblQuantity)
						.addComponent(lblCost))
						.addGroup(gl_contentPane.createParallelGroup(GroupLayout.Alignment.LEADING)
								.addComponent(supplierCombo).addComponent(brandCombo)
								// Model row with button
								.addGroup(gl_contentPane.createSequentialGroup().addComponent(modelCombo)
										.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(addmodelBtn))
								.addComponent(partCombo).addComponent(quantitySpinner).addComponent(costField)))
				.addGroup(GroupLayout.Alignment.CENTER, gl_contentPane.createSequentialGroup().addComponent(btnAdd)));

		// vertical group
		gl_contentPane.setVerticalGroup(gl_contentPane.createSequentialGroup()
				.addGroup(gl_contentPane.createParallelGroup().addComponent(lblSupplier).addComponent(supplierCombo))
				.addGroup(gl_contentPane.createParallelGroup().addComponent(lblBrand).addComponent(brandCombo))
				.addGroup(gl_contentPane.createParallelGroup(GroupLayout.Alignment.CENTER).addComponent(lblModel)
						.addComponent(modelCombo).addComponent(addmodelBtn))
				.addGroup(gl_contentPane.createParallelGroup().addComponent(lblPart).addComponent(partCombo))
				.addGroup(gl_contentPane.createParallelGroup().addComponent(lblQuantity).addComponent(quantitySpinner))
				.addGroup(gl_contentPane.createParallelGroup().addComponent(lblCost).addComponent(costField)).addGap(20)
				.addComponent(btnAdd));
		loadSuppliers();
		loadBrands();
		loadParts();
		brandCombo.addActionListener(e -> loadModels());
		loadModels();
	}

	private void loadSuppliers() {
		supplierCombo.removeAllItems();

		for (Supplier s : supplierService.getAllSuppliers()) {
			supplierCombo.addItem(s);
		}
	}

	private void loadBrands() {
		brandCombo.removeAllItems();
		for (Brand b : brandService.getAllBrands()) {
			brandCombo.addItem(b);
		}

	}

	public void loadModels() {
		Brand brand = (Brand) brandCombo.getSelectedItem();
		modelEventList.clear(); // Instead of removeAllItems()
		if (brand != null) {
			List<Model> models = modelService.getModelsByBrandId(brand.getBrandId());
			modelEventList.addAll(models);
		}
	}

	private void loadParts() {
	    partEventList.clear();
	    partEventList.addAll(partService.getAllParts());
	}


	private void addReceipt() {
		try {
			Supplier supplier = (Supplier) supplierCombo.getSelectedItem();
			Brand brand = (Brand) brandCombo.getSelectedItem();
			Model model = (Model) modelCombo.getSelectedItem();
			Part part = (Part) partCombo.getSelectedItem();
			int quantity = (int) quantitySpinner.getValue();
			String costText = costField.getText().trim();

			if (supplier == null || part == null || model == null || costText.isEmpty()) {
				JOptionPane.showMessageDialog(this, "Please fill all fields correctly.", "Validation Error",
						JOptionPane.WARNING_MESSAGE);
				return;
			}

			double cost = Double.parseDouble(costText);

			PartReceipt receipt = new PartReceipt();
			receipt.setSupplier(supplier);
			receipt.setModel(model);
			receipt.setPart(part);
			receipt.setQuantity(quantity);
			receipt.setUnitCost(BigDecimal.valueOf(cost));
			receipt.setReceiptDate(new Date());

			partReceiptService.save(receipt);
			JOptionPane.showMessageDialog(this, "Receipt added successfully!", "Success",
					JOptionPane.INFORMATION_MESSAGE);
			partRecieptView.loadInitialData();
			dispose();

		} catch (NumberFormatException ex) {
			JOptionPane.showMessageDialog(this, "Invalid cost value. Enter a valid number.", "Input Error",
					JOptionPane.ERROR_MESSAGE);
		} catch (Exception ex) {
			ex.printStackTrace();
			JOptionPane.showMessageDialog(this, "Error saving receipt: " + ex.getMessage(), "Error",
					JOptionPane.ERROR_MESSAGE);
		}
	}
	private static void setUIFont(Font font) {
	    java.util.Enumeration<Object> keys = UIManager.getDefaults().keys();
	    while (keys.hasMoreElements()) {
	        Object key = keys.nextElement();
	        Object value = UIManager.get(key);
	        if (value instanceof Font) {
	            UIManager.put(key, font);
	        }
	    }
	}



}
