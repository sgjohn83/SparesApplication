package com.spares.ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import com.spares.model.Supplier;
import com.spares.service.SupplierService;

public class SupplierForm extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField sname;
	private SupplierService supplierService;
	private SupplerView supplerView;

	public SupplierForm(SupplierService supplierService, SupplerView supplerView) {
		setTitle("Add Supplier");
		setModal(true);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setSize(400, 250);
		setLocationRelativeTo(null); // Center the dialog
		getContentPane().setLayout(new BorderLayout());

		// Content Panel Setup
		contentPanel.setBackground(Color.WHITE);
		contentPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
		contentPanel.setLayout(null);
		getContentPane().add(contentPanel, BorderLayout.CENTER);

		JLabel lblName = new JLabel("Supplier Name:");
		lblName.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblName.setBounds(40, 40, 120, 25);
		contentPanel.add(lblName);

		sname = new JTextField();
		sname.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		sname.setBounds(160, 40, 180, 28);
		contentPanel.add(sname);
		sname.setColumns(10);

		JButton btnSubmit = new JButton("Submit");
		btnSubmit.setFont(new Font("Segoe UI", Font.BOLD, 14));
		btnSubmit.setBackground(new Color(66, 133, 244));
		btnSubmit.setForeground(Color.WHITE);
		btnSubmit.setFocusPainted(false);
		btnSubmit.setBounds(140, 110, 120, 35);
		contentPanel.add(btnSubmit);

		this.supplierService = supplierService;
		this.supplerView = supplerView;

		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				saveSupplier();
			}
		});
	}

	private void saveSupplier() {
		String name = sname.getText().trim();
		if (name.isEmpty()) {
			JOptionPane.showMessageDialog(this, "Supplier name cannot be empty.", "Validation Error", JOptionPane.WARNING_MESSAGE);
			return;
		}

		Supplier s = new Supplier();
		s.setName(name);
		supplierService.save(s);
		supplerView.loadTable();
		dispose();
	}
}
