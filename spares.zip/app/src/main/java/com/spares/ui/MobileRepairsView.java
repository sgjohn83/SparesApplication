package com.spares.ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.regex.Pattern;
import java.util.Date;
import java.util.stream.Collectors;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spares.AppConfig;
import com.spares.model.MobileRepair;
import com.spares.service.MobileRepairService;
import com.spares.service.RepairPartsUsedService;

public class MobileRepairsView extends JFrame {

    private JPanel contentPane;
    private JTable table;
    private JTextField searchField;
    private DefaultTableModel model;
    private TableRowSorter<DefaultTableModel> sorter;

    private MobileRepairService mobileRepairService;
	private RepairPartsUsedService repairPartsUsedService;

    public MobileRepairsView() {
        // Optional modern look-and-feel (FlatLaf)
        // FlatLightLaf.install();

        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        mobileRepairService = context.getBean(MobileRepairService.class);
        repairPartsUsedService =  context.getBean(RepairPartsUsedService.class);

        setTitle("Mobile Repairs");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        contentPane = new JPanel(new BorderLayout(10, 10));
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);

        JPanel topPanel = new JPanel(new BorderLayout(5, 5));
        JLabel lblSearch = new JLabel("Search:");
        searchField = new JTextField();
        topPanel.add(lblSearch, BorderLayout.WEST);
        topPanel.add(searchField, BorderLayout.CENTER);
        contentPane.add(topPanel, BorderLayout.NORTH);

        // Table
        model = new DefaultTableModel(new String[]{"Service ID", "Model", "Customer Name", "Status", "Date","Spares Added"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Allow editing
            }
        };

        table = new JTable(model);
        table.setRowHeight(36);
        
        
        table.setFillsViewportHeight(true);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 14));
        table.setFont(new Font("SansSerif", Font.BOLD, 18));

        // Sorting
        sorter = new TableRowSorter<>(model);
        table.setRowSorter(sorter);

        // Status ComboBox Editor
        
        JComboBox<String> statusCombo = new JComboBox<>(new String[]{"New", "Pending","Completed","Cancelled","Failed","Delivered"});
        table.getColumnModel().getColumn(3).setCellEditor(new DefaultCellEditor(statusCombo));

        // Custom row renderer
        
        //colors are not working when exported to jar
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable tbl, Object val, boolean isSelected, boolean hasFocus, int row, int col) {
                Component c = super.getTableCellRendererComponent(tbl, val, isSelected, hasFocus, row, col);

                if (!(c instanceof JComponent)) {
                    return c;
                }
                JComponent jc = (JComponent) c;
                jc.setOpaque(true);

                if (isSelected) {
                    jc.setBackground(tbl.getSelectionBackground());
                    jc.setForeground(tbl.getSelectionForeground());
                } else {
                    jc.setBackground(tbl.getBackground());
                    jc.setForeground(tbl.getForeground());

                    int modelRow = tbl.convertRowIndexToModel(row);
                    TableModel model = tbl.getModel();

                    try {
                        // Handle status-based coloring (from status column index 3)
                        Object statusObj = model.getValueAt(modelRow, 3);
                        if (statusObj != null) {
                            String status = statusObj.toString().trim();
                            switch (status.toLowerCase()) {
                                case "new":
                                    jc.setBackground(Color.WHITE);
                                    break;
                                case "pending":
                                    jc.setBackground(Color.YELLOW);
                                    break;
                                case "completed":
                                    jc.setBackground(Color.GREEN);
                                    break;
                                case "failed":
                                case "cancelled":
                                    jc.setBackground(Color.RED);
                                    break;
                                case "delivered":
                                    jc.setBackground(Color.BLUE);
                                    break;
                                default:
                                    jc.setBackground(Color.BLUE); // fallback
                            }
                        }

                        // Special logic for last column
                        int lastCol = tbl.getColumnCount() - 1;
                        if (col == lastCol) {
                            String cellValue = val != null ? val.toString().trim() : "";

                            if (cellValue.equalsIgnoreCase("None")) {
                                jc.setBackground(Color.RED);
                                jc.setForeground(Color.WHITE);
                            } else {
                                jc.setBackground(Color.YELLOW);
                                jc.setForeground(Color.BLACK);
                            }
                        }

                    } catch (Exception ex) {
                        System.err.println("Renderer error at row " + row + ", col " + col + ": " + ex.getMessage());
                    }
                }

                return jc;
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);
        contentPane.add(scrollPane, BorderLayout.CENTER);

        // Bottom Button Panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT, 10, 5));

        JButton btnAdd = new JButton("Add");
        JButton btnUpdate = new JButton("Update");
        JButton btnDelete = new JButton("Delete");

        btnAdd.addActionListener(e -> addRepair());
        btnUpdate.addActionListener(e -> updateRepair());
        btnDelete.addActionListener(e -> deleteRepair());

        buttonPanel.add(btnAdd);
        buttonPanel.add(btnUpdate);
        buttonPanel.add(btnDelete);

        contentPane.add(buttonPanel, BorderLayout.SOUTH);

        // Load Data
        loadTable();

        // Search
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { filterTable(); }
            public void removeUpdate(DocumentEvent e) { filterTable(); }
            public void changedUpdate(DocumentEvent e) { filterTable(); }
        });
        
        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Check for double-click
                if (e.getClickCount() == 2 && !e.isConsumed()) {
                    e.consume(); // mark event as handled

                    JTable target = (JTable) e.getSource();
                    int viewRow = target.getSelectedRow();
                    if (viewRow >= 0) {
                    	 int modelRow = target.convertRowIndexToModel(viewRow);
                    	 Long idValue = (Long) target.getModel().getValueAt(modelRow, 0);

                        // Call your method with the model row index
                        openAddSparesForm(idValue);
                    }
                }
            }

		
        });

    }
	private void openAddSparesForm(Long idValue) {
		new PartsUsedForm(idValue, MobileRepairsView.this).setVisible(true);
		
	}
   //table filter is not working properly
    private void filterTable() {
        String text = searchField.getText().trim();
        if (text.isEmpty()) { // Changed from text.length() == 0 for slight conciseness
            sorter.setRowFilter(null);
        } else {
            try {
                // Quote the text to treat special characters literally, then apply case-insensitivity
                String regex = "(?i)" + Pattern.quote(text);
                sorter.setRowFilter(RowFilter.regexFilter(regex));
            } catch (java.util.regex.PatternSyntaxException e) {
                // This is unlikely with Pattern.quote, but good to have for raw regex
                System.err.println("Invalid pattern in search: " + text + " Error: " + e.getMessage());
                // Optionally, provide user feedback e.g. searchField.setBackground(Color.PINK);
            }
        }
    }

    public void loadTable() {
        model.setRowCount(0);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        List<MobileRepair> list = mobileRepairService.getAllRepairs();
      
        for (MobileRepair r : list) {
      String spares = repairPartsUsedService.getCommaSeparatedPartNamesByRepairId( r.getRepairId());
            model.addRow(new Object[]{
                    r.getRepairId(),
                    r.getDeviceModel(),
                    r.getCustomerName(),
                    r.getStatus(),
                    sdf.format(r.getRepairDate()),
                    spares
            });
        }
    }

    private void addRepair() {
        new MobileRepairForm(mobileRepairService, this).setVisible(true);
    }

    private void updateRepair() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            try {
                int modelRow = table.convertRowIndexToModel(selectedRow);
                Long id = Long.parseLong(model.getValueAt(modelRow, 0).toString());
                String modelText = model.getValueAt(modelRow, 1).toString();
                String name = model.getValueAt(modelRow, 2).toString();
                String status = model.getValueAt(modelRow, 3).toString();
                String dateStr = model.getValueAt(modelRow, 4).toString();

                Date date = new SimpleDateFormat("yyyy-MM-dd").parse(dateStr);

                MobileRepair mobileRepair = new MobileRepair();
                mobileRepair.setRepairId(id);
                mobileRepair.setDeviceModel(modelText);
                mobileRepair.setCustomerName(name);
                mobileRepair.setStatus(status);
                mobileRepair.setRepairDate(date);

                mobileRepairService.update(mobileRepair);
                loadTable();

                JOptionPane.showMessageDialog(this, "Record updated successfully.", "Update", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error updating record: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row to update.", "Warning", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void deleteRepair() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this repair?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                Long id = Long.parseLong(table.getValueAt(selectedRow, 0).toString());
                mobileRepairService.delete(id);
                loadTable();
                JOptionPane.showMessageDialog(this, "Record deleted successfully.", "Delete", JOptionPane.INFORMATION_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row to delete.", "Warning", JOptionPane.WARNING_MESSAGE);
        }
    }
}
