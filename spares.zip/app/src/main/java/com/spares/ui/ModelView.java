package com.spares.ui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;

import javax.swing.DefaultCellEditor;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumn;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spares.AppConfig;
import com.spares.model.Brand;
import com.spares.model.Model;
import com.spares.service.BrandService;
import com.spares.service.ModelService;

public class ModelView extends JFrame {

    private JPanel contentPane;
    private JTextField textField;
    private JTable table;
    private ModelService modelService;
    private BrandService brandService;
    private AnnotationConfigApplicationContext context;

    public ModelView() {
        context = new AnnotationConfigApplicationContext(AppConfig.class);
        modelService = context.getBean(ModelService.class);
        brandService = context.getBean(BrandService.class);
        
        initComponents();
        JTableStyler.styleTable(table, 0);
        loadTable();
        
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                context.close();
            }
        });
    }

    private void initComponents() {
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 800, 600);
        contentPane = new JPanel(new BorderLayout(10, 10));
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);

        // Search Panel
        JPanel searchPanel = new JPanel();
        searchPanel.add(new JLabel("Search:"));
        textField = new JTextField(20);
        searchPanel.add(textField);
        contentPane.add(searchPanel, BorderLayout.NORTH);

        // Table
        table = new JTable();
        JScrollPane scrollPane = new JScrollPane(table);
        contentPane.add(scrollPane, BorderLayout.CENTER);

        // Buttons Panel
        JPanel buttonPanel = new JPanel();
        JButton btnAdd = new JButton("Add");
        JButton btnDelete = new JButton("Delete");

        btnAdd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ModelForm(modelService, brandService, ModelView.this).setVisible(true);
            }
        });

        btnDelete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow >= 0) {
                    ModelTableModel model = (ModelTableModel) table.getModel();
                    Model selectedModel = model.getModelAt(selectedRow);
                    modelService.deleteModel(selectedModel);
                    loadTable();
                }
            }
        });

        buttonPanel.add(btnAdd);
        buttonPanel.add(btnDelete);
        contentPane.add(buttonPanel, BorderLayout.SOUTH);

        // Search functionality
        textField.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { filterTable(); }
            public void removeUpdate(DocumentEvent e) { filterTable(); }
            public void changedUpdate(DocumentEvent e) { filterTable(); }

            private void filterTable() {
                String keyword = textField.getText().toLowerCase();
                List<Model> allModels = modelService.getAllModels();
                allModels.removeIf(m -> 
                    !m.getName().toLowerCase().contains(keyword) &&
                    !m.getBrand().getName().toLowerCase().contains(keyword)
                );
                ((ModelTableModel) table.getModel()).setModels(allModels);
            }
        });
    }

    public void loadTable() {
        List<Model> models = modelService.getAllModels();
        List<Brand> brands = brandService.getAllBrands();
        ModelTableModel modelTableModel = new ModelTableModel(models, brands);
        table.setModel(modelTableModel);

        // Configure Brand column
        TableColumn brandColumn = table.getColumnModel().getColumn(1);
        JComboBox<Brand> brandCombo = new JComboBox<>(brands.toArray(new Brand[0]));
        brandCombo.setRenderer(new DefaultListCellRenderer() {
            public Component getListCellRendererComponent(JList<?> list, Object value,
                    int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof Brand) {
                    setText(((Brand) value).getName());
                }
                return this;
            }
        });
        brandColumn.setCellEditor(new DefaultCellEditor(brandCombo));
        brandColumn.setCellRenderer(new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                if (value instanceof Brand) {
                    value = ((Brand) value).getName();
                }
                return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            }
        });
    }

    private class ModelTableModel extends AbstractTableModel {
        private List<Model> models;
        private final String[] columns = {"ID", "Brand", "Model Name"};

        public ModelTableModel(List<Model> models, List<Brand> brands) {
            this.models = models;
        }

        public int getRowCount() { return models.size(); }
        public int getColumnCount() { return columns.length; }
        public String getColumnName(int column) { return columns[column]; }

        public Object getValueAt(int row, int column) {
            Model model = models.get(row);
            switch (column) {
                case 0: return model.getModelId();
                case 1: return model.getBrand();
                case 2: return model.getName();
                default: return null;
            }
        }

        public boolean isCellEditable(int row, int column) { 
            return column != 0; // ID not editable
        }

        public void setValueAt(Object value, int row, int column) {
            Model model = models.get(row);
            switch (column) {
                case 1:
                    if (value instanceof Brand) {
                        model.setBrand((Brand) value);
                    }
                    break;
                case 2:
                    model.setName((String) value);
                    break;
            }
            modelService.updateModel(model);
            fireTableCellUpdated(row, column);
        }

        public void setModels(List<Model> models) {
            this.models = models;
            fireTableDataChanged();
        }

        public Model getModelAt(int row) {
            return models.get(row);
        }
    }

}