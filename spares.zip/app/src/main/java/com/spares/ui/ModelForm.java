package com.spares.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.spares.model.Brand;
import com.spares.model.Model;
import com.spares.service.BrandService;
import com.spares.service.ModelService;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionEvent;

public class ModelForm extends JDialog {

	private JPanel contentPane;
	private JTextField modelTxt;
	private ModelService modelService;
	private ModelView view;
	private BrandService brandService;
	private JComboBox brandCombo;
	private PartRecieptForm partRecieptForm;

	/**
	 * Create the frame.
	 * @param actionListener 
	 * @param modelService 
	 * @param brandService 
	 */
	public ModelForm(ModelService modelService, BrandService brandService, ModelView view) {
		this.setModal(true);
		this.modelService=modelService;
		this.view=view;
		this.brandService=brandService;
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 633, 591);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblBrand = new JLabel("Brand");
		lblBrand.setBounds(94, 37, 46, 14);
		contentPane.add(lblBrand);
		
	     brandCombo = new JComboBox();
		brandCombo.setBounds(201, 34, 132, 20);
		contentPane.add(brandCombo);
		
		JLabel lblModelName = new JLabel("Model Name");
		lblModelName.setBounds(94, 79, 93, 14);
		contentPane.add(lblModelName);
		
		modelTxt = new JTextField();
		modelTxt.setBounds(201, 76, 141, 20);
		contentPane.add(modelTxt);
		modelTxt.setColumns(10);
		loadBrands();
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addModel();
			}

			
		});
		btnAdd.setBounds(183, 132, 89, 23);
		contentPane.add(btnAdd);
	}

	public ModelForm(ModelService modelService2, BrandService brandService2, PartRecieptForm partRecieptForm) {
		this.modelService=modelService2;
		this.brandService=brandService2;
		this.partRecieptForm=partRecieptForm;
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 633, 591);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblBrand = new JLabel("Brand");
		lblBrand.setBounds(94, 37, 46, 14);
		contentPane.add(lblBrand);
		
	     brandCombo = new JComboBox();
		brandCombo.setBounds(201, 34, 132, 20);
		contentPane.add(brandCombo);
		
		JLabel lblModelName = new JLabel("Model Name");
		lblModelName.setBounds(94, 79, 93, 14);
		contentPane.add(lblModelName);
		
		modelTxt = new JTextField();
		modelTxt.setBounds(201, 76, 141, 20);
		contentPane.add(modelTxt);
		modelTxt.setColumns(10);
		loadBrands();
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addModelsForReciept();
			}

			
		});
		btnAdd.setBounds(183, 132, 89, 23);
		contentPane.add(btnAdd);

		
		
	}

	private void addModelsForReciept() {
		
		Model model = new Model();
		Brand br = (Brand) brandCombo.getSelectedItem();
		model.setBrand(br);
		model.setName(modelTxt.getText());
		modelService.saveModel(model);
		
		partRecieptForm.loadModels();
		 JOptionPane.showMessageDialog(this, "Model Added");
		dispose();
	}

	private void loadBrands() {
	    brandCombo.removeAllItems(); // clear existing items
	    List<Brand> brands = brandService.getAllBrands();
	    for (Brand brand : brands) {
	        brandCombo.addItem(brand); // will use toString() for display
	    }
	}
	private void addModel() {
		Model model = new Model();
		Brand br = (Brand) brandCombo.getSelectedItem();
		model.setBrand(br);
		model.setName(modelTxt.getText());
		modelService.saveModel(model);
		
		view.loadTable();
		 JOptionPane.showMessageDialog(this, "Model Added");
		dispose();
		
	}

	
}
