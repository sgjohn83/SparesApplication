package com.spares.ui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import com.spares.model.MobileRepair;
import com.spares.service.MobileRepairService;
import com.toedter.calendar.JDateChooser;

public class MobileRepairForm extends JFrame {

    private JPanel contentPane;
    private JTextField txtServiceId;
    private JTextField txtDeviceModel;
    private JTextField txtCustomerName;
    private JDateChooser dateChooser;
    private JComboBox<String> comboBoxStatus;

    private final MobileRepairService mobileRepairService;
    private final MobileRepairsView view;

    public MobileRepairForm(MobileRepairService mobileRepairService, MobileRepairsView view) {
        this.mobileRepairService = mobileRepairService;
        this.view = view;

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 450, 400);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblServiceId = new JLabel("Service Id");
        lblServiceId.setBounds(30, 30, 100, 20);
        contentPane.add(lblServiceId);

        txtServiceId = new JTextField();
        txtServiceId.setBounds(150, 30, 200, 20);
        contentPane.add(txtServiceId);
        txtServiceId.setColumns(10);

        JLabel lblDate = new JLabel("Date");
        lblDate.setBounds(30, 70, 100, 20);
        contentPane.add(lblDate);

        dateChooser = new JDateChooser();
        dateChooser.setBounds(150, 70, 200, 20);
        dateChooser.setDate(new Date()); // set default date to today
        contentPane.add(dateChooser);

        JLabel lblDeviceModel = new JLabel("Device Model");
        lblDeviceModel.setBounds(30, 110, 100, 20);
        contentPane.add(lblDeviceModel);

        txtDeviceModel = new JTextField();
        txtDeviceModel.setBounds(150, 110, 200, 20);
        contentPane.add(txtDeviceModel);
        txtDeviceModel.setColumns(10);

        JLabel lblCustomerName = new JLabel("Customer Name");
        lblCustomerName.setBounds(30, 150, 100, 20);
        contentPane.add(lblCustomerName);

        txtCustomerName = new JTextField();
        txtCustomerName.setBounds(150, 150, 200, 20);
        contentPane.add(txtCustomerName);
        txtCustomerName.setColumns(10);

        JLabel lblStatus = new JLabel("Status");
        lblStatus.setBounds(30, 190, 100, 20);
        contentPane.add(lblStatus);

        comboBoxStatus = new JComboBox<>();
        comboBoxStatus.setModel(new DefaultComboBoxModel<>(new String[]{"New", "Pending","Completed","Failed","Cancelled","Completed [Delivered]","Failed [Delivered]"}));
        comboBoxStatus.setBounds(150, 190, 200, 20);
        contentPane.add(comboBoxStatus);

        JButton btnAdd = new JButton("Add");
        btnAdd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addRepair();
            }
        });
        btnAdd.setBounds(150, 240, 90, 25);
        contentPane.add(btnAdd);
    }

    private void addRepair() {
        try {
            // Validate and collect input
            String serviceIdStr = txtServiceId.getText().trim();
            String deviceModel = txtDeviceModel.getText().trim();
            String customerName = txtCustomerName.getText().trim();
            Date repairDate = dateChooser.getDate();
            String status = comboBoxStatus.getSelectedItem().toString();

            if (serviceIdStr.isEmpty() || deviceModel.isEmpty() || customerName.isEmpty() || repairDate == null) {
                JOptionPane.showMessageDialog(this, "Please fill all fields.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            long serviceId;
            try {
                serviceId = Long.parseLong(serviceIdStr);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Service ID must be a number.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Bind to model
            MobileRepair mobileRepair = new MobileRepair();
            mobileRepair.setRepairId(serviceId);
            mobileRepair.setDeviceModel(deviceModel);
            mobileRepair.setCustomerName(customerName);
            mobileRepair.setRepairDate(repairDate);
            mobileRepair.setStatus(status);

            // Save to service
            mobileRepairService.save(mobileRepair);

            JOptionPane.showMessageDialog(this, "Mobile repair added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            view.loadTable(); // Refresh table
            dispose(); // Close form

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error saving repair: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
