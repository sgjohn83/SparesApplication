package com.spares.ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spares.AppConfig;
import com.spares.model.*;
import com.spares.service.*;

public class PurchaseDetails extends JDialog {

    private JPanel contentPane;
    private JTable table;
    private DefaultTableModel model;
    private JTextField searchField;

    private RepairPartsUsedService partsUsedService;
    private PartService partService;
    private SupplierService supplierService;
    private PartReceiptService partReceiptService;

    private JComboBox<Part> comboPart;
    private JComboBox<Supplier> comboSupplier;
    private JComboBox<PartReceipt> comboReceipt;
    private JComboBox<String> comboStatus;
	private MobileRepairService mobileRepairService;
	private Long id;

    public PurchaseDetails(Long id) {
    	this.id=id;
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        partsUsedService = context.getBean(RepairPartsUsedService.class);
        partService = context.getBean(PartService.class);
        mobileRepairService = context.getBean(MobileRepairService.class);
        supplierService = context.getBean(SupplierService.class);
        partReceiptService = context.getBean(PartReceiptService.class);

        setTitle("Parts Used");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1050, 600);
        setLocationRelativeTo(null);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(15, 15, 15, 15));
        setContentPane(contentPane);

        JLabel lblSearch = new JLabel("Search:");
        lblSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        searchField = new JTextField(20);
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        JButton btnAdd = new JButton("Add");
        JButton btnUpdate = new JButton("Update");
        JButton btnDelete = new JButton("Delete");

        JButton[] buttons = new JButton[]{btnAdd, btnUpdate, btnDelete};
        for (JButton btn : buttons) {
            btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
            btn.setFocusPainted(false);
            btn.setBackground(new Color(255, 193, 7));
            btn.setForeground(Color.BLACK);
        }

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
       // topPanel.add(lblSearch);
        //topPanel.add(searchField);
       // topPanel.add(btnAdd);
        topPanel.add(btnUpdate);
       // topPanel.add(btnDelete);

        btnDelete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    int modelRow = table.convertRowIndexToModel(selectedRow);
                    Long id = Long.parseLong(model.getValueAt(modelRow, 0).toString());
                    int confirm = JOptionPane.showConfirmDialog(PurchaseDetails.this, "Delete this record?", "Confirm", JOptionPane.YES_NO_OPTION);
                    if (confirm == JOptionPane.YES_OPTION) {
                        partsUsedService.delete(id);
                        loadTable();
                    }
                }
            }
        });

        model = new DefaultTableModel(new Object[]{
                "ID", "Brand", "Model", "Part", "Repair ID", "Supplier", "Qty", "Receipt", "Status"
        }, 0) {
            public boolean isCellEditable(int row, int column) {
                return column != 0; // Only ID is not editable
            }
        };

        table = new JTable(model);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setRowHeight(28);
        table.setFillsViewportHeight(true);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setBackground(new Color(230, 230, 250));
        header.setReorderingAllowed(false);

        JScrollPane scrollPane = new JScrollPane(table);

        GroupLayout layout = new GroupLayout(contentPane);
        contentPane.setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);
        layout.setVerticalGroup(layout.createSequentialGroup()
                .addComponent(topPanel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addComponent(scrollPane));
        layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(topPanel)
                .addComponent(scrollPane));

        initComboBoxes();
        addComboBoxEditors();
        loadTable();
        applyRowRenderer();

        searchField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                filterTable(searchField.getText());
            }
        });

        btnAdd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new PartsUsedForm(partsUsedService, PurchaseDetails.this).setVisible(true);
            }
        });

        btnUpdate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (table.isEditing()) {
                    table.getCellEditor().stopCellEditing();
                }

                for (int i = 0; i < model.getRowCount(); i++) {
                    Long id = Long.parseLong(model.getValueAt(i, 0).toString());
                    Part part = (Part) model.getValueAt(i, 3);
                    Long Id =  (Long) model.getValueAt(i, 4);
                    Supplier supplier = (Supplier) model.getValueAt(i, 5);
                    Integer qty = Integer.parseInt(model.getValueAt(i, 6).toString());
                    PartReceipt receipt = (PartReceipt) model.getValueAt(i, 7);
                    String status = model.getValueAt(i, 8).toString();
                    
                    MobileRepair repair = mobileRepairService.getById(Id);

                    RepairPartsUsed pu = partsUsedService.findById(id);
                    if (pu != null) {
                        pu.setPart(part);
                        pu.setRepair(repair); // You must support this constructor or find by ID
                        pu.setSupplier(supplier);
                        pu.setQuantityUsed(qty);
                        pu.setReceipt(receipt);
                        pu.setStatus(status);
                        partsUsedService.update(pu);
                    }
                }
                loadTable();
                JOptionPane.showMessageDialog(PurchaseDetails.this, "Records updated successfully.");
            }
        });
    }

    private void initComboBoxes() {
        comboPart = new JComboBox<Part>(partsUsedService.findAllUsedParts().toArray(new Part[0]));
        comboSupplier = new JComboBox<Supplier>(partsUsedService.findAllUsedSuppliers().toArray(new Supplier[0]));
        comboReceipt = new JComboBox<PartReceipt>(partsUsedService.findAllUsedReceipts().toArray(new PartReceipt[0]));
        comboStatus = new JComboBox<String>(new String[]{"USED", "FAILED"});
    }

    private void addComboBoxEditors() {
        TableColumnModel columnModel = table.getColumnModel();
        columnModel.getColumn(3).setCellEditor(new DefaultCellEditor(comboPart));
        columnModel.getColumn(5).setCellEditor(new DefaultCellEditor(comboSupplier));
        columnModel.getColumn(7).setCellEditor(new DefaultCellEditor(comboReceipt));
        columnModel.getColumn(8).setCellEditor(new DefaultCellEditor(comboStatus));
    }

    private void filterTable(String text) {
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<DefaultTableModel>(model);
        table.setRowSorter(sorter);
        sorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
    }

    public void loadTable() {
        model.setRowCount(0);
        List<RepairPartsUsed> list = partsUsedService.getByReceiptId(id);
        for (RepairPartsUsed pu : list) {
            model.addRow(new Object[]{
                    pu.getId(),
                    pu.getReceipt().getModel().getBrand().getName(),
                    pu.getReceipt().getModel().getName(),
                    pu.getPart(),
                    pu.getRepair().getRepairId(),
                    pu.getSupplier(),
                    pu.getQuantityUsed(),
                    pu.getReceipt(),
                    pu.getStatus()
            });
        }
    }

    private void applyRowRenderer() {
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                String status = table.getValueAt(row, 8).toString(); // Status column index

                // Default coloring by status
                if ("USED".equalsIgnoreCase(status)) {
                    c.setBackground(new Color(112, 176, 75));
                    c.setForeground(Color.BLACK);
                } else if ("FAILED".equalsIgnoreCase(status)) {
                    c.setBackground(new Color(255, 102, 102));
                    c.setForeground(Color.WHITE);
                } else {
                    c.setBackground(Color.WHITE);
                    c.setForeground(Color.BLACK);
                }

                // Special styling for "Repair ID" column (index 4)
                if (column == 4) {
                    c.setBackground(Color.WHITE);
                    c.setForeground(new Color(0, 102, 204));
                    c.setFont(new Font("Segoe UI", Font.BOLD, 15));
                }

                if (isSelected) {
                    c.setBackground(c.getBackground().darker());
                }

                return c;
            }
        });
    }
}
