package com.spares.ui;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.swing.table.*;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.spares.AppConfig;
import com.spares.model.*;
import com.spares.service.SupplierPaymentService;

public class SupplierPaymentsView extends JFrame {
	private JPanel contentPane;
	private JTextField txtSearch;
	private JTable tblPayments;
	private JComboBox<Supplier> cmbSuppliers;
	private JComboBox<String> cmbStatus;
	private JButton btnMakePayment;
	private JLabel lblSummarySupplier;
	private JLabel lblSummaryStatus;
	private JLabel lblSummaryItems;
	private JLabel lblSummaryAmount;
	private JLabel lblSelectedItems;
	private JLabel lblSelectedAmount;
	private SupplierPaymentService supplierPaymentService;

	public SupplierPaymentsView() {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		supplierPaymentService = context.getBean(SupplierPaymentService.class);

		setTitle("Supplier Payments");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(150, 100, 950, 650);

		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(20, 20, 20, 20));
		setContentPane(contentPane);

		JLabel lblSupplier = new JLabel("Supplier:");
		lblSupplier.setFont(new Font("Segoe UI", Font.PLAIN, 14));

		cmbSuppliers = new JComboBox<>();
		cmbSuppliers.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		Dimension comboDim = new Dimension(200, 28);
		cmbSuppliers.setPreferredSize(comboDim);
		cmbSuppliers.setMaximumSize(comboDim);
		cmbSuppliers.addActionListener(e -> {
			loadStatuses();
			loadTable();
		});

		JLabel lblStatus = new JLabel("Status:");
		lblStatus.setFont(new Font("Segoe UI", Font.PLAIN, 14));

		cmbStatus = new JComboBox<>();
		cmbStatus.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		cmbStatus.setPreferredSize(comboDim);
		cmbStatus.setMaximumSize(comboDim);
		cmbStatus.addActionListener(e -> loadTable());

		JLabel lblSearch = new JLabel("Search:");
		lblSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));

		txtSearch = new JTextField();
		txtSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		txtSearch.setColumns(10);
		txtSearch.setPreferredSize(new Dimension(200, 28));
		txtSearch.addKeyListener(new KeyAdapter() {
			public void keyReleased(KeyEvent e) {
				loadTable();
			}
		});

		tblPayments = new JTable();
	
		tblPayments.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 24));
		tblPayments.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		tblPayments.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "ID", "Supplier", "Service Id",
				"Status", "Brand", "Model", "Part Name", "Amount", "Select" }) {
			Class<?>[] columnTypes = new Class<?>[] { Long.class, String.class, Long.class, String.class, String.class,
					String.class, String.class, Double.class, Boolean.class };

			@Override
			public Class<?> getColumnClass(int col) {
				return columnTypes[col];
			}

			@Override
			public boolean isCellEditable(int row, int col) {
				return col == 8;
			}
		});

		TableColumnModel cols = tblPayments.getColumnModel();
		int[] widths = { 50, 120, 70, 80, 80, 80, 150, 80, 50 };
		for (int i = 0; i < widths.length; i++)
			cols.getColumn(i).setPreferredWidth(widths[i]);

		DefaultTableCellRenderer rightAlign = new DefaultTableCellRenderer();
		rightAlign.setHorizontalAlignment(SwingConstants.RIGHT);
		DefaultTableCellRenderer centerAlign = new DefaultTableCellRenderer();
		centerAlign.setHorizontalAlignment(SwingConstants.CENTER);

		cols.getColumn(0).setCellRenderer(rightAlign);
		cols.getColumn(2).setCellRenderer(rightAlign);
		cols.getColumn(7).setCellRenderer(rightAlign);
		cols.getColumn(8).setCellRenderer(centerAlign);
        tblPayments.setRowHeight(40);
		tblPayments.setDefaultRenderer(Object.class, new TableCellRenderer() {
			DefaultTableCellRenderer dr = new DefaultTableCellRenderer();
			
		
   
			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int col) {
				Component c = dr.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, col);
				
				
				c.setForeground(Color.BLACK);
				c.setBackground(Color.WHITE);
				if(col==2 || col==6 || col==7)
				{
					c.setFont(new Font("Segoe UI", Font.BOLD, 21));
					c.setForeground(Color.BLUE);
				}
				if (col == 3) {
					String status = String.valueOf(table.getValueAt(row, 3));
					switch (status) {
					case "New":
					case "N/A":
						c.setBackground(Color.WHITE);
						break;
					case "Pending":
						c.setBackground(Color.YELLOW);
						break;
					case "Failed":
					case "Cancelled":
						c.setBackground(Color.RED);
						c.setForeground(Color.WHITE);
						break;
					case "Completed":
						c.setBackground(Color.GREEN);
						break;
					default:
						c.setBackground(Color.BLUE);
						c.setForeground(Color.WHITE);
					}
				}
				
				if (isSelected)
					c.setBackground(c.getBackground());
				return c;
			}
		});
		DefaultTableCellRenderer customDoubleRenderer = new DefaultTableCellRenderer() {
		    private java.text.DecimalFormat formatter = new java.text.DecimalFormat("#,##0.00"); // Or "0.00" if no grouping

		    @Override
		    public Component getTableCellRendererComponent(JTable table, Object value,
		                                                 boolean isSelected, boolean hasFocus,
		                                                 int row, int column) {
		        // Let DefaultTableCellRenderer handle selection, background, etc.
		        // but we will set the text ourselves after formatting.
		        Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

		        // Apply your custom formatting
		        c.setFont(new Font("Segoe UI", Font.BOLD, 21));
		        c.setForeground(Color.BLUE);
		        setHorizontalAlignment(SwingConstants.RIGHT);

		        // Format the Double value
		        if (value instanceof Double) {
		            setText(formatter.format(value)); // Sets the displayed text on the JLabel (this class)
		        } else if (value != null) {
		            setText(value.toString());
		        } else {
		            setText("");
		        }
		        if(isSelected)
			      {
			    	  c.setBackground(Color.WHITE);
			      }
		        return this; // Return 'this' as DefaultTableCellRenderer is a JLabel
		    }
		};
		DefaultTableCellRenderer customLongRenderer = new DefaultTableCellRenderer() {
		    @Override
		    public Component getTableCellRendererComponent(JTable table, Object value,
		                                                 boolean isSelected, boolean hasFocus,
		                                                 int row, int column) {
		        // Get the default component (handles selection, basic value toString)
		        Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

		        // Apply your custom formatting
		        c.setFont(new Font("Segoe UI", Font.BOLD, 21));
		        c.setForeground(Color.BLUE);
		        
		        setHorizontalAlignment(SwingConstants.RIGHT); // Ensure right alignment

		      if(isSelected)
		      {
		    	  c.setBackground(Color.WHITE);
		      }
		        return c;
		    }
		};

		TableColumnModel co11 = tblPayments.getColumnModel();
		co11.getColumn(2).setCellRenderer(customLongRenderer); // For "Service Id"
		co11.getColumn(7).setCellRenderer(customDoubleRenderer); // For "Amount"
		
		tblPayments.setDefaultRenderer(Boolean.class, tblPayments.getDefaultRenderer(Boolean.class));
		tblPayments.getColumnModel().getColumn(8).setCellRenderer(new TableCellRenderer() {
			private final JCheckBox check = new JCheckBox();

			@Override
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {
				check.setSelected(Boolean.TRUE.equals(value));
				check.setHorizontalAlignment(SwingConstants.CENTER);
				check.setBackground(isSelected ? table.getSelectionBackground() : table.getBackground());
				return check;
			}
		});
		tblPayments.getModel().addTableModelListener(e -> {
			if (e.getColumn() == 8)
				updateSelectionSummary();
		});

		JButton btnMakePayment = new JButton("Make Payment");
		btnMakePayment.setFont(new Font("Segoe UI", Font.BOLD, 14));
		btnMakePayment.setPreferredSize(new Dimension(160, 35));
		btnMakePayment.setBackground(new Color(33, 150, 243));
		btnMakePayment.setForeground(Color.BLACK);
		btnMakePayment.setFocusPainted(false);
		btnMakePayment.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnMakePayment.setOpaque(true);
		btnMakePayment.getModel().addChangeListener(e -> {
			ButtonModel m = btnMakePayment.getModel();
			btnMakePayment.setBackground(m.isPressed() ? new Color(40, 100, 200) : new Color(66, 133, 244));
		});
		btnMakePayment.addActionListener(e -> makePayment());

		JPanel summaryPanel = createSummaryPanel();

		JScrollPane scrollPane = new JScrollPane(tblPayments);

		GroupLayout layout = new GroupLayout(contentPane);
		contentPane.setLayout(layout);
		layout.setAutoCreateGaps(true);
		layout.setAutoCreateContainerGaps(true);

		layout.setHorizontalGroup(layout.createParallelGroup()
				.addGroup(layout.createSequentialGroup().addComponent(lblSupplier).addComponent(cmbSuppliers).addGap(20)
						.addComponent(lblStatus).addComponent(cmbStatus).addGap(20).addComponent(lblSearch)
						.addComponent(txtSearch))
				.addComponent(scrollPane).addComponent(summaryPanel)
				.addGroup(GroupLayout.Alignment.CENTER, layout.createSequentialGroup().addComponent(btnMakePayment)));

		layout.setVerticalGroup(layout.createSequentialGroup()
				.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(lblSupplier)
						.addComponent(cmbSuppliers).addComponent(lblStatus).addComponent(cmbStatus)
						.addComponent(lblSearch).addComponent(txtSearch))
				.addGap(15).addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE).addGap(15)
				.addComponent(summaryPanel).addGap(15).addComponent(btnMakePayment));

		
		setExtendedState(JFrame.MAXIMIZED_BOTH); 
		loadSuppliers();
		loadStatuses();
		loadTable();
	}

	private JPanel createSummaryPanel() {
		JPanel panel = new JPanel();
		panel.setBackground(new Color(48, 63, 159));
		panel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

		Font baseFont = new Font("Segoe UI", Font.PLAIN, 16);
		Font amountFont = new Font("Segoe UI", Font.BOLD, 18);

		lblSummarySupplier = new JLabel("Supplier: -");
		lblSummaryStatus = new JLabel("Status: All");
		lblSummaryItems = new JLabel("Total Items: 0");
		lblSummaryAmount = new JLabel("Total Amount: ₹0.00");
		lblSelectedItems = new JLabel("Selected Items: 0");
		lblSelectedAmount = new JLabel("Selected Amount: ₹0.00");

		lblSummarySupplier.setFont(baseFont);
		lblSummaryStatus.setFont(baseFont);
		lblSummaryItems.setFont(baseFont);
		lblSummaryAmount.setFont(amountFont);
		lblSelectedItems.setFont(baseFont);
		lblSelectedAmount.setFont(amountFont);

		for (JLabel lbl : Arrays.asList(lblSummarySupplier, lblSummaryStatus, lblSummaryItems, lblSummaryAmount,
				lblSelectedItems, lblSelectedAmount)) {
			lbl.setForeground(Color.WHITE);
		}

		GroupLayout gl = new GroupLayout(panel);
		panel.setLayout(gl);
		gl.setAutoCreateGaps(true);
		gl.setAutoCreateContainerGaps(true);

		gl.setHorizontalGroup(gl.createParallelGroup()
				.addGroup(gl.createSequentialGroup().addComponent(lblSummarySupplier).addGap(20)
						.addComponent(lblSummaryStatus).addGap(20).addComponent(lblSummaryItems).addGap(20)
						.addComponent(lblSummaryAmount))
				.addGroup(gl.createSequentialGroup().addComponent(lblSelectedItems).addGap(20)
						.addComponent(lblSelectedAmount)));

		gl.setVerticalGroup(gl.createSequentialGroup()
				.addGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(lblSummarySupplier)
						.addComponent(lblSummaryStatus).addComponent(lblSummaryItems).addComponent(lblSummaryAmount))
				.addGap(10).addGroup(gl.createParallelGroup(GroupLayout.Alignment.BASELINE)
						.addComponent(lblSelectedItems).addComponent(lblSelectedAmount)));

		return panel;
	}

	private void loadSuppliers() {
		List<SupplierPayment> slist = supplierPaymentService.getAllSupplierPayments();
		Set<Supplier> uniqueSup = new HashSet<>();
		for (SupplierPayment s : slist) {
			if (s.getSupplier() != null)
				uniqueSup.add(s.getSupplier());
		}
		cmbSuppliers.removeAllItems();
		for (Supplier sup : uniqueSup)
			cmbSuppliers.addItem(sup);
	}

	private void loadStatuses() {
		Supplier sel = (Supplier) cmbSuppliers.getSelectedItem();
		List<SupplierPayment> list = supplierPaymentService.getUnpaidSupplierPayments();
		Set<String> statuses = new LinkedHashSet<>();
		statuses.add("All");
		for (SupplierPayment s : list) {
			if (sel != null && !s.getSupplier().equals(sel))
				continue;
			if (s.getRepairStatus() != null)
				statuses.add(s.getRepairStatus());
		}
		cmbStatus.removeAllItems();
		for (String st : statuses)
			cmbStatus.addItem(st);
	}

	private void loadTable() {
		Supplier selSup = (Supplier) cmbSuppliers.getSelectedItem();
		String selStatus = (String) cmbStatus.getSelectedItem();
		String kw = txtSearch.getText().trim().toLowerCase();
		List<SupplierPayment> list = supplierPaymentService.getUnpaidSupplierPayments();
		DefaultTableModel model = (DefaultTableModel) tblPayments.getModel();
		model.setRowCount(0);
		double totalAmt = 0;
		int totalCnt = 0;
		String supName = selSup != null ? selSup.getName() : "-";

		for (SupplierPayment s : list) {
			if (selSup != null && !s.getSupplier().equals(selSup))
				continue;
			String status = s.getRepairStatus() != null ? s.getRepairStatus() : "N/A";
			if (selStatus != null && !"All".equals(selStatus) && !status.equals(selStatus))
				continue;
			String brandName = "N/A";
			if (s.getPartUsed() != null && s.getPartUsed().getReceipt() != null
					&& s.getPartUsed().getReceipt().getModel() != null
					&& s.getPartUsed().getReceipt().getModel().getBrand() != null) {
				brandName = s.getPartUsed().getReceipt().getModel().getBrand().getName();
			}
			String modelName = "N/A";
			if (s.getPartUsed() != null && s.getPartUsed().getReceipt() != null
					&& s.getPartUsed().getReceipt().getModel() != null) {
				modelName = s.getPartUsed().getReceipt().getModel().getName();
			}
			String partName = "N/A";
			if (s.getPartUsed() != null && s.getPartUsed().getPart() != null) {
				partName = s.getPartUsed().getPart().getName();
			}
			double amt = s.getPaidAmount() != null ? s.getPaidAmount().doubleValue() : 0.0;
			if (!kw.isEmpty() && !partName.toLowerCase().contains(kw))
				continue;

			model.addRow(new Object[] { s.getPaymentId(), supName, s.getRepairId() != null ? s.getRepairId() : 0L,
					status, brandName, modelName, partName, amt, Boolean.FALSE });
			totalAmt += amt;
			totalCnt++;
		}

		lblSummarySupplier.setText("Supplier: " + supName);
		lblSummaryStatus.setText("Status: " + (selStatus == null ? "All" : selStatus));
		lblSummaryItems.setText("Total Items: " + totalCnt);
		lblSummaryAmount.setText(String.format("Total Amount: %.2f", totalAmt));
		lblSelectedItems.setText("Selected Items: 0");
		lblSelectedAmount.setText("Selected Amount: 0.00");
	}

	private void updateSelectionSummary() {
		DefaultTableModel model = (DefaultTableModel) tblPayments.getModel();
		int selCnt = 0;
		double selAmt = 0;
		for (int i = 0; i < model.getRowCount(); i++) {
			if (Boolean.TRUE.equals(model.getValueAt(i, 8))) {
				selCnt++;
				selAmt += (Double) model.getValueAt(i, 7);
			}
		}
		lblSelectedItems.setText("Selected Items: " + selCnt);
		lblSelectedAmount.setText(String.format("Selected Amount: %.2f", selAmt));
	}

	private void makePayment() {
		DefaultTableModel model = (DefaultTableModel) tblPayments.getModel();
		List<Long> ids = new ArrayList<>();
		for (int i = 0; i < model.getRowCount(); i++) {
			if (Boolean.TRUE.equals(model.getValueAt(i, 8))) {
				ids.add((Long) model.getValueAt(i, 0));
			}
		}
		if (ids.isEmpty()) {
			JOptionPane.showMessageDialog(this, "No payments selected.", "Warning", JOptionPane.WARNING_MESSAGE);
			return;
		}
		int confirm = JOptionPane.showConfirmDialog(this, "Confirm payment for " + ids.size() + " item(s)?", "Confirm",
				JOptionPane.YES_NO_OPTION);
		if (confirm != JOptionPane.YES_OPTION)
			return;
		supplierPaymentService.updatePaymentDateByIds(ids.toArray(new Long[0]), new Date());
		JOptionPane.showMessageDialog(this, "Payments recorded successfully.");
		loadTable();
	}

	
}
