package com.spares.ui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.AbstractTableModel;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spares.AppConfig;
import com.spares.model.Part;
import com.spares.service.PartService;

public class SparePartsView extends JFrame {

    private JPanel contentPane;
    private JTable table;
    private PartTableModel tableModel;
    private JTextField textFieldSearch;
    private PartService partService;

    public SparePartsView() {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        partService = context.getBean(PartService.class);

        setTitle("Spare Parts Management");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(700, 500);
        setLocationRelativeTo(null);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(15, 15, 15, 15));
        setContentPane(contentPane);

        // Use GroupLayout for responsive layout with padding and gaps
        GroupLayout layout = new GroupLayout(contentPane);
        contentPane.setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        // Components
        JLabel lblSearch = new JLabel("Search:");
        textFieldSearch = new JTextField(20);
        JButton btnSearch = new JButton("Search");
        JButton btnAdd = new JButton("Add");
        JButton btnUpdate = new JButton("Update");
        JButton btnDelete = new JButton("Delete");
        JButton btnRefresh = new JButton("Refresh");

        JScrollPane scrollPane = new JScrollPane();
        tableModel = new PartTableModel(partService.getAllParts());
        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        scrollPane.setViewportView(table);

        // Button Actions
        btnSearch.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                searchParts();
            }
        });

        btnAdd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addPart();
            }
        });

        btnUpdate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updatePart();
            }
        });

        btnDelete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deletePart();
            }
        });

        btnRefresh.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                refreshTable();
            }
        });

        // Styling JTable
        JTableStyler.styleTable(table, 0, 2);

        // Layout horizontal group
        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(lblSearch)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(textFieldSearch)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(btnSearch)
                )
                .addComponent(scrollPane)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(btnAdd, 100, 100, 100)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(btnUpdate, 100, 100, 100)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(btnDelete, 100, 100, 100)
                    .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(btnRefresh, 100, 100, 100)
                    .addGap(0, 0, Short.MAX_VALUE)
                )
        );

        // Layout vertical group
        layout.setVerticalGroup(
            layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSearch)
                    .addComponent(textFieldSearch, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSearch)
                )
                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
                .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAdd, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnUpdate, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnDelete, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnRefresh, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                )
        );
    }

    private void searchParts() {
        String query = textFieldSearch.getText().trim().toLowerCase();
        List<Part> all = partService.getAllParts();
        List<Part> filtered = new ArrayList<Part>();
        for (Part p : all) {
            if (p.getName() != null && p.getName().toLowerCase().contains(query)) {
                filtered.add(p);
            }
        }
        tableModel.setParts(filtered);
    }

    public void refreshTable() {
        tableModel.setParts(partService.getAllParts());
    }

    private void addPart() {
        new SparePartsForm(partService, SparePartsView.this).setVisible(true);
    }

    private void updatePart() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a part to update.");
            return;
        }

        Part part = tableModel.getPartAt(selectedRow);
        try {
            String name = table.getValueAt(selectedRow, 1).toString();
            BigDecimal cost = new BigDecimal(table.getValueAt(selectedRow, 2).toString());

            part.setName(name.trim());
            part.setUnitCost(cost);
            partService.update(part);
            refreshTable();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid data for update.");
        }
    }

    private void deletePart() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a part to delete.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure to delete this part?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            Part part = tableModel.getPartAt(selectedRow);
            partService.delete(part.getPartId());
            refreshTable();
        }
    }

    // Custom TableModel
    class PartTableModel extends AbstractTableModel {
        private String[] columnNames = {"Part ID", "Name", "Unit Cost"};
        private List<Part> parts;

        public PartTableModel(List<Part> parts) {
            this.parts = parts;
        }

        public void setParts(List<Part> parts) {
            this.parts = parts;
            fireTableDataChanged();
        }

        public Part getPartAt(int row) {
            return parts.get(row);
        }

        public int getColumnCount() {
            return columnNames.length;
        }

        public int getRowCount() {
            return parts.size();
        }

        public String getColumnName(int col) {
            return columnNames[col];
        }

        public Object getValueAt(int row, int col) {
            Part part = parts.get(row);
            if (col == 0) return part.getPartId();
            if (col == 1) return part.getName();
            if (col == 2) return part.getUnitCost();
            return null;
        }

        public boolean isCellEditable(int row, int col) {
            return col == 1 || col == 2;
        }

        public void setValueAt(Object value, int row, int col) {
            Part part = parts.get(row);
            if (col == 1) part.setName(value.toString());
            if (col == 2) {
                try {
                    part.setUnitCost(new BigDecimal(value.toString()));
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "Invalid number format.");
                }
            }
            fireTableCellUpdated(row, col);
        }
    }
}
