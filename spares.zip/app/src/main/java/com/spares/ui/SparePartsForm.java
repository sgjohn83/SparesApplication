package com.spares.ui;

import java.math.BigDecimal;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.spares.model.Part;
import com.spares.service.PartService;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SparePartsForm extends JDialog {

    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;
    private PartService partService;
    private SparePartsView sparePartsView;

    public SparePartsForm(PartService partService, SparePartsView sparePartsView) {
        this.partService = partService;
        this.sparePartsView = sparePartsView;

        setTitle("Add Spare Part");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblPartName = new JLabel("Part Name:");
        lblPartName.setBounds(48, 65, 100, 14);
        contentPane.add(lblPartName);

        textField = new JTextField();
        textField.setBounds(178, 62, 200, 20);
        contentPane.add(textField);
        textField.setColumns(10);

        JLabel lblCost = new JLabel("Cost:");
        lblCost.setBounds(48, 105, 100, 14);
        contentPane.add(lblCost);

        textField_1 = new JTextField();
        textField_1.setBounds(178, 102, 200, 20);
        contentPane.add(textField_1);
        textField_1.setColumns(10);

        JButton btnAdd = new JButton("Add");
        btnAdd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addToDB();
            }
        });
        btnAdd.setBounds(178, 160, 100, 30);
        contentPane.add(btnAdd);
    }

    private void addToDB() {
        String name = textField.getText().trim();
        String costText = textField_1.getText().trim();

        if (name.isEmpty() || costText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter all fields.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            BigDecimal cost = new BigDecimal(costText);
            Part part = new Part();
            part.setName(name);
            part.setUnitCost(cost);

            partService.save(part);
            JOptionPane.showMessageDialog(this, "Part added successfully!");

            if (sparePartsView != null) {
                sparePartsView.refreshTable();// Update table after insert
            }

            dispose(); // Close the form
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid cost value. Enter a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error saving part: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
