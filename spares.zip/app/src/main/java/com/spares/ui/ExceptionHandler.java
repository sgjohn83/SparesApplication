package com.spares.ui;

import org.hibernate.HibernateException;
import javax.swing.*;

public class ExceptionHandler {

    public static void showRootCause(Throwable e) {
        Throwable root = e;
        while (root.getCause() != null) {
            root = root.getCause();
        }

        JOptionPane.showMessageDialog(
            null,
            "Database Error:\n" + root.getClass().getName() + "\n" + root.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE
        );
        
    }
}

