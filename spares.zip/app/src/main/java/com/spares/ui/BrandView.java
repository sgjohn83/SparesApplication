package com.spares.ui;

import java.awt.*;
import java.awt.event.*;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.*;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spares.AppConfig;
import com.spares.model.Brand;
import com.spares.service.BrandService;

public class BrandView extends JFrame {

    private JPanel contentPane;
    private JTextField searchField;
    private JTable brandTable;
    private DefaultTableModel tableModel;
    private TableRowSorter<DefaultTableModel> rowSorter;
    private BrandService brandService;

    public BrandView() {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        brandService = context.getBean(BrandService.class);

        setTitle("Brand Management");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        initializeComponents();
        JTableStyler.styleTable(brandTable, 0);
        loadBrandTable();
       
    }

    private void initializeComponents() {
        contentPane = new JPanel(new BorderLayout(10, 10));
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel searchLabel = new JLabel("Search:");
        searchField = new JTextField(25);
        searchField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                String text = searchField.getText();
                rowSorter.setRowFilter(text.trim().isEmpty() ? null : RowFilter.regexFilter("(?i)" + text));
            }
        });

        searchPanel.add(searchLabel);
        searchPanel.add(searchField);
        contentPane.add(searchPanel, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(new Object[] { "ID", "Brand Name" }, 0) {
            public boolean isCellEditable(int row, int col) {
                return col == 1; // Only Brand Name is editable
            }
        };

        tableModel.addTableModelListener(new TableModelListener() {
            public void tableChanged(TableModelEvent e) {
                if (e.getType() == TableModelEvent.UPDATE) {
                    int row = e.getFirstRow();
                    Long id = (Long) tableModel.getValueAt(row, 0);
                    String name = (String) tableModel.getValueAt(row, 1);
                    Brand brand = brandService.getBrandById(id);
                    if (brand != null && !brand.getName().equals(name)) {
                        brand.setName(name);
                        brandService.updateBrand(brand); // persist change
                        JOptionPane.showMessageDialog(BrandView.this, "Brand updated.", "Success", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
        });

        brandTable = new JTable(tableModel);
        brandTable.setRowHeight(24);
        brandTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        brandTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        rowSorter = new TableRowSorter<>(tableModel);
        brandTable.setRowSorter(rowSorter);

        JScrollPane scrollPane = new JScrollPane(brandTable);
        contentPane.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        JButton btnAdd = new JButton("Add");
        JButton btnDelete = new JButton("Delete");

        btnAdd.addActionListener(e -> openBrandForm(null));
        btnDelete.addActionListener(e -> deleteSelectedBrand());

        buttonPanel.add(btnAdd);
        buttonPanel.add(btnDelete);
        contentPane.add(buttonPanel, BorderLayout.SOUTH);
    }

    public void loadBrandTable() {
        List<Brand> brands = brandService.getAllBrands();
        tableModel.setRowCount(0);
        for (Brand brand : brands) {
            tableModel.addRow(new Object[] { brand.getBrandId(), brand.getName() });
        }
    }

    private void deleteSelectedBrand() {
        int selectedRow = brandTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a brand to delete.", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int modelIndex = brandTable.convertRowIndexToModel(selectedRow);
        Long id = (Long) tableModel.getValueAt(modelIndex, 0);
        Brand brand = brandService.getBrandById(id);

        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this brand?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            brandService.deleteBrand(brand);
            tableModel.removeRow(modelIndex);
        }
    }

    private void openBrandForm(Brand brand) {
        BrandForm form = new BrandForm(brandService, this);
         
        form.setVisible(true);
    }

    public void addBrandToTable(Brand brand) {
        tableModel.addRow(new Object[] { brand.getBrandId(), brand.getName() });
    }
}
