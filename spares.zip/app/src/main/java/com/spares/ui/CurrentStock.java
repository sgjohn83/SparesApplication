package com.spares.ui;

import java.awt.*;
import java.awt.event.ItemEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
// import java.util.concurrent.ExecutionException; // No longer needed for SwingWorker
import java.util.stream.Collectors;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import org.springframework.context.annotation.AnnotationConfigApplicationContext; // Only for standalone main()

import com.spares.AppConfig; // For standalone main()
import com.spares.model.AvailablePartStock;
import com.spares.service.AvailablePartStockService;

public class CurrentStock extends JFrame {

    private JPanel contentPane;
    private JTextField searchTextField;
    private JTable table;
    private JComboBox<String> supplierComboBox;
    private final AvailablePartStockService stockService;
    private DefaultTableModel tableModel;
    private TableRowSorter<DefaultTableModel> sorter;
    private List<AvailablePartStock> allPartsList; // To store all data for filtering

    private JLabel statusLabel; // Optional status label

    /**
     * Constructor to be used when integrating with Spring.
     * The AvailablePartStockService should be injected.
     */
    public CurrentStock() {
    	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		stockService = context.getBean(AvailablePartStockService.class);
      
        this.allPartsList = new ArrayList<>();

        setTitle("Current Stock Viewer");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        initComponents();
        loadInitialData(); // Load data directly (no SwingWorker)

        setPreferredSize(new Dimension(800, 600));
        pack();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        contentPane = new JPanel(new BorderLayout(10, 10));
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);

        // --- Filter Panel (Top) ---
        JPanel filterPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0;
        gbc.gridy = 0;
        filterPanel.add(new JLabel("Filter by Supplier:"), gbc);

        supplierComboBox = new JComboBox<>();
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0.3;
        filterPanel.add(supplierComboBox, gbc);

        gbc.gridx = 2;
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        filterPanel.add(new JLabel("Search:"), gbc);

        searchTextField = new JTextField();
        gbc.gridx = 3;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0.7;
        filterPanel.add(searchTextField, gbc);

        contentPane.add(filterPanel, BorderLayout.NORTH);

        // --- Table (Center) ---
        JScrollPane scrollPane = new JScrollPane();
        contentPane.add(scrollPane, BorderLayout.CENTER);

        String[] columns = {"Supplier", "Brand", "Model", "Part Name", "Cost", "Available Quantity"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 4) return Double.class;
                if (columnIndex == 5) return Integer.class;
                return String.class;
            }
        };
        table = new JTable(tableModel);
        table.setAutoCreateRowSorter(false);
        table.setFillsViewportHeight(true);
        table.getTableHeader().setBackground(UIManager.getColor("TableHeader.background"));
        table.setRowHeight(table.getRowHeight() + 4);
        table.setIntercellSpacing(new Dimension(0,1));

        scrollPane.setViewportView(table);

        // --- Status Bar (Bottom) ---
        statusLabel = new JLabel("Initializing...");
        statusLabel.setBorder(new EmptyBorder(5,0,0,0));
        contentPane.add(statusLabel, BorderLayout.SOUTH);

        // Add listeners for filtering
        supplierComboBox.addItemListener(e -> {
            if (e.getStateChange() == ItemEvent.SELECTED) {
                applyFilters();
            }
        });

        searchTextField.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { applyFilters(); }
            @Override public void removeUpdate(DocumentEvent e) { applyFilters(); }
            @Override public void changedUpdate(DocumentEvent e) { applyFilters(); }
        });
    }

    /**
     * Loads initial data directly on the current thread (EDT).
     * WARNING: If stockService.getAvailableParts() is a long operation,
     * this will freeze the UI.
     */
    private void loadInitialData() {
        statusLabel.setText("Loading data...");
        supplierComboBox.setEnabled(false);
        searchTextField.setEnabled(false);

        try {
            // This call runs on the EDT. UI will freeze if it's slow.
            allPartsList = stockService.getAvailableParts();

            populateTableWithData(allPartsList);
            populateSupplierComboBox();
            setupTableSorter();
            statusLabel.setText("Data loaded successfully. " + allPartsList.size() + " items.");
        } catch (Exception e) { // Catch any exception from the service call or UI updates
            // It's crucial to handle exceptions properly
            JOptionPane.showMessageDialog(CurrentStock.this, "Error loading data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            statusLabel.setText("Error: Could not load data.");
            e.printStackTrace(); // Log the full stack trace for debugging
        } finally {
            supplierComboBox.setEnabled(true);
            searchTextField.setEnabled(true);
            applyFilters(); // Apply initial filters
        }
    }

    private void populateTableWithData(List<AvailablePartStock> partsToDisplay) {
        tableModel.setRowCount(0);
        for (AvailablePartStock part : partsToDisplay) {
            Object[] row = {
                part.getSupplier(),
                part.getBrand(),
                part.getModel(),
                part.getPartName(),
                part.getCost(),
                part.getAvailableQuantity()
            };
            tableModel.addRow(row);
        }
    }

    private void populateSupplierComboBox() {
        supplierComboBox.removeAllItems();
        supplierComboBox.addItem("All Suppliers");

        if (allPartsList != null) {
            allPartsList.stream()
                .map(AvailablePartStock::getSupplier)
                .filter(Objects::nonNull)
                .distinct()
                .sorted()
                .forEach(supplierComboBox::addItem);
        }
    }
    
    private void setupTableSorter() {
        sorter = new TableRowSorter<>(tableModel);
        table.setRowSorter(sorter);
    }

    private void applyFilters() {
        if (sorter == null) return;

        String selectedSupplier = (String) supplierComboBox.getSelectedItem();
        String searchText = searchTextField.getText().trim();

        List<RowFilter<Object, Object>> filters = new ArrayList<>();

        if (selectedSupplier != null && !"All Suppliers".equalsIgnoreCase(selectedSupplier)) {
            filters.add(RowFilter.regexFilter("^" + selectedSupplier + "$", 0));
        }

        if (!searchText.isEmpty()) {
            filters.add(RowFilter.regexFilter("(?i)" + searchText, 1, 2, 3));
        }

        if (filters.isEmpty()) {
            sorter.setRowFilter(null);
        } else {
            sorter.setRowFilter(RowFilter.andFilter(filters));
        }
        statusLabel.setText(table.getRowCount() + " items matching filters.");
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(new com.formdev.flatlaf.FlatLightLaf());
        } catch (Exception ex) {
            System.err.println("Failed to initialize LaF. Using default.");
        }

        EventQueue.invokeLater(() -> {
            AnnotationConfigApplicationContext context = null;
            try {
                context = new AnnotationConfigApplicationContext(AppConfig.class);
                AvailablePartStockService service = context.getBean(AvailablePartStockService.class);
                CurrentStock frame = new CurrentStock();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Could not start application: " + e.getMessage(), "Startup Error", JOptionPane.ERROR_MESSAGE);
            }
            // Note: Context is not closed here to keep service alive for the frame.
            // In a real app, context lifecycle would be managed more robustly.
        });
    }
}