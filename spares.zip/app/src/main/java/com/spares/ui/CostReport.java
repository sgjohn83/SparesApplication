package com.spares.ui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.math.BigDecimal;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableRowSorter;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spares.AppConfig;
import com.spares.model.CostReportModel;
import com.spares.service.CostReportService;

public class CostReport extends JFrame {

    private JPanel contentPane;
    private JTextField searchTextField;
    private JTable table;
    private DefaultTableModel tableModel;
    private CostReportService costReportService;
    private TableRowSorter<DefaultTableModel> sorter;


    // A scheduler for debouncing search input to avoid excessive DB calls
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();

    /**
     * Create the frame.
     */
    public CostReport() {
        // Initialize Spring Context and get the service bean
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        costReportService = context.getBean(CostReportService.class);

        setTitle("Cost Report");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 1024, 768);
        setMinimumSize(new Dimension(800, 600));
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);

        GridBagLayout gbl_contentPane = new GridBagLayout();
        gbl_contentPane.columnWidths = new int[]{0, 0, 0};
        gbl_contentPane.rowHeights = new int[]{0, 0, 0};
        gbl_contentPane.columnWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
        gbl_contentPane.rowWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
        contentPane.setLayout(gbl_contentPane);

        JLabel lblSearch = new JLabel("Search");
        lblSearch.setFont(new Font("Tahoma", Font.PLAIN, 14));
        GridBagConstraints gbc_lblSearch = new GridBagConstraints();
        gbc_lblSearch.insets = new Insets(0, 0, 5, 5);
        gbc_lblSearch.anchor = GridBagConstraints.EAST;
        gbc_lblSearch.gridx = 0;
        gbc_lblSearch.gridy = 0;
        contentPane.add(lblSearch, gbc_lblSearch);

        searchTextField = new JTextField();
        searchTextField.setFont(new Font("Tahoma", Font.PLAIN, 14));
        GridBagConstraints gbc_textField = new GridBagConstraints();
        gbc_textField.insets = new Insets(0, 0, 5, 0);
        gbc_textField.fill = GridBagConstraints.HORIZONTAL;
        gbc_textField.gridx = 1;
        gbc_textField.gridy = 0;
        contentPane.add(searchTextField, gbc_textField);
        searchTextField.setColumns(10);

        JScrollPane scrollPane = new JScrollPane();
        GridBagConstraints gbc_scrollPane = new GridBagConstraints();
        gbc_scrollPane.gridwidth = 2;
        gbc_scrollPane.insets = new Insets(10, 0, 0, 0);
        gbc_scrollPane.fill = GridBagConstraints.BOTH;
        gbc_scrollPane.gridx = 0;
        gbc_scrollPane.gridy = 1;
        contentPane.add(scrollPane, gbc_scrollPane);

        String[] columnNames = {
            "ID", "SUPPLIER NAME", "BRAND NAME", "MODEL NAME", "PART NAME",
            "TOTAL QTY PURCHASED", "AVERAGE UNIT COST", "MIN UNIT COST",
            "MAX UNIT COST", "TOTAL SPENT"
        };
        tableModel = new DefaultTableModel(columnNames, 0) {
            // Make cells non-editable
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(tableModel);
        
        
        
        

        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setRowHeight(28);
        table.setFillsViewportHeight(true);
        table.setAutoCreateRowSorter(true); // Enable basic sorting

        JTableHeader tableHeader = table.getTableHeader();
        tableHeader.setFont(new Font("Segoe UI", Font.BOLD, 14));
        tableHeader.setBackground(new Color(240, 240, 240));
        tableHeader.setForeground(Color.BLACK);
        tableHeader.setPreferredSize(new Dimension(100, 32));

        scrollPane.setViewportView(table);

        // --- Feature Implementations ---

        // 1. Initial data load
        loadTableData(null);
      
        sorter = new TableRowSorter<>(tableModel);
        table.setRowSorter(sorter);
        // 2. Add search filter listener
        addSearchFilterListener();
        
        // 3. Implement coloring for cost columns
        applyCostColoring();
    }

    /**
     * Loads or filters the table data by calling the backend service.
     * @param keyword The search term, or null/empty to load all data.
     */
    private void loadTableData(String keyword) {
        // Fetch data from the service (backend)
        // Note: Using PartReceiptsSummary as the model based on previous step.
        List<CostReportModel> reportData = costReportService.getAllSummaries();

        // Clear existing rows from the table model
        tableModel.setRowCount(0);

        // Populate the table with new data
        int rowId = 1;
        if (reportData != null) {
            for (CostReportModel item : reportData) {
                tableModel.addRow(new Object[]{
                    rowId++,
                    item.getSupplierName(),
                    item.getBrandName(),
                    item.getModelName(),
                    item.getPartName(),
                    item.getTotalQuantityPurchased(),
                    item.getAverageUnitCost().trim(),
                    item.getMinUnitCost().trim(),
                    item.getMaxUnitCost().trim(),
                    item.getTotalSpentOnPartFromSupplier().trim()
                });
            }
        }
    }

  
   //not working fix this
    private void addSearchFilterListener() {
        searchTextField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                filterTable();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                filterTable();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                filterTable();
            }


            private void filterTable() {
                String text = searchTextField.getText();
                if (text.trim().length() == 0) {
                    sorter.setRowFilter(null);
                } else {
                    try {
                        sorter.setRowFilter(RowFilter.regexFilter("(?i)" + java.util.regex.Pattern.quote(text.trim())));
                    } catch (java.util.regex.PatternSyntaxException ex) {
                        // If something bad happens, fallback to no filter
                        sorter.setRowFilter(null);
                    }
                }
            }
        });
    }

    /**
     * Applies the custom cell renderer to all cost-related columns.
     */
    private void applyCostColoring() {
        CostCellRenderer costRenderer = new CostCellRenderer();
        // Column indices for cost columns
        table.getColumnModel().getColumn(6).setCellRenderer(costRenderer); // AVERAGE UNIT COST
        table.getColumnModel().getColumn(7).setCellRenderer(costRenderer); // MIN UNIT COST
        table.getColumnModel().getColumn(8).setCellRenderer(costRenderer); // MAX UNIT COST
    }

    /**
     * Custom renderer to color cells based on their numeric value.
     */
    private static class CostCellRenderer extends DefaultTableCellRenderer {
        private static final Color COLOR_LOW = new Color(220, 255, 220); // Light Green
        private static final Color COLOR_MEDIUM = new Color(255, 240, 210); // Light Orange
        private static final Color COLOR_HIGH = new Color(255, 220, 220); // Light Red
        
        private static final BigDecimal THRESHOLD_LOW = new BigDecimal("100");
        private static final BigDecimal THRESHOLD_HIGH = new BigDecimal("500");

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            // Let the superclass create the component (JLabel)
            Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

            // If the cell is not selected, apply custom background colors
            if (!isSelected && value instanceof String) {
                try {
                    BigDecimal numericValue = new BigDecimal((String) value);
                    if (numericValue.compareTo(THRESHOLD_LOW) < 0) {
                        c.setBackground(COLOR_LOW);
                    } else if (numericValue.compareTo(THRESHOLD_HIGH) > 0) {
                        c.setBackground(COLOR_HIGH);
                    } else {
                        c.setBackground(COLOR_MEDIUM);
                    }
                } catch (NumberFormatException e) {
                    // If parsing fails, revert to default table background
                    c.setBackground(table.getBackground());
                }
            } else if (isSelected) {
                // If selected, use the default selection background color
                c.setBackground(table.getSelectionBackground());
            }

            return c;
        }
    }
}