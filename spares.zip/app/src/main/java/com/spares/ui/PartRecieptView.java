package com.spares.ui;

import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.*;
import javax.swing.DefaultComboBoxModel;

import com.toedter.calendar.JDateChooser;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.spares.AppConfig;
import com.spares.model.Brand;
import com.spares.model.Model;
import com.spares.model.Part;
import com.spares.model.PartReceipt;
import com.spares.model.PartReceiptStock;
import com.spares.model.Supplier;
import com.spares.service.BrandService;
import com.spares.service.ModelService;
import com.spares.service.PartReceiptService;
import com.spares.service.PartReceiptStockService;
import com.spares.service.PartService;
import com.spares.service.SupplierService;

public class PartRecieptView extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField textField;
	private JLabel lblSearch;

	private PartReceiptService partReceiptService;
	private PartService partService;
	private SupplierService supplierService;
	private BrandService brandService;
	private ModelService modelService;
	private PartReceiptStockService partReceiptStockService;

	private JButton btnAdd;
	private JButton btnUpdate;
	private JButton btnDelete;
	private JButton btnAddBrand;
	private JButton btnAddSpares;
	private JButton btnApplyService;
	private JButton btnDetails;

	private List<PartReceipt> fullReceiptList;
	private List<Part> partList;
	private List<Supplier> supplierList;
	private List<Brand> brandList;
	private List<Model> modelList;
	private Map<Long, Integer> remainingQtyMap;

	private JDateChooser fromDateChooser;
	private JDateChooser toDateChooser;
	private JComboBox<Supplier> comboSupplier;
	private JComboBox<Brand> comboBrand;
	private JComboBox<Model> comboModel;
	private JComboBox<String> comboStockStatus;
	private JButton btnSearch;

	private JLabel lblFromDate;
	private JLabel lblToDate;
	private JLabel lblFilterSupplier;
	private JLabel lblFilterBrand;
	private JLabel lblFilterModel;
	private JLabel lblStockStatus;

	private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
	private AnnotationConfigApplicationContext context;
	private PartRecieptForm partRecieptForm;
	private Date fromDate;
	private Date toDate;

	private final Model modelAllOption = new Model();
	private boolean isUpdatingModelComboByCode = false;
	private Brand selectedBrand;

	public PartRecieptView() {
		modelAllOption.setName("All");

		context = new AnnotationConfigApplicationContext(AppConfig.class);
		initializeServices();
		initializeUI();
		loadInitialData();
		setupWindowListener();
	}

	private void initializeServices() {
		partReceiptService = context.getBean(PartReceiptService.class);
		partService = context.getBean(PartService.class);
		supplierService = context.getBean(SupplierService.class);
		brandService = context.getBean(BrandService.class);
		modelService = context.getBean(ModelService.class);
		partReceiptStockService = context.getBean(PartReceiptStockService.class);
	}

	private void initializeUI() {
		setTitle("Part Receipt Records");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(1300, 700); // Increased width for the new filter
		setLocationRelativeTo(null);

		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(15, 15, 15, 15));
		setContentPane(contentPane);

		modelList = new ArrayList<>();
		brandList = new ArrayList<>();
		supplierList = new ArrayList<>();
		partList = new ArrayList<>();
		fullReceiptList = new ArrayList<>();
		remainingQtyMap = new HashMap<>();

		createSearchField();
		createStyledTable();
		createButtons();
		createFilterComponents();
		setupLayout();
	}

	private void createSearchField() {
		lblSearch = new JLabel("Search:");
		lblSearch.setFont(new Font("SansSerif", Font.PLAIN, 15));

		textField = new JTextField(25);
		textField.setFont(new Font("SansSerif", Font.PLAIN, 15));
		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				filterTable(textField.getText().trim().toLowerCase());
			}
		});
	}

	private void createStyledTable() {
		table = new JTable() {
			@Override
			public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
				Component c = super.prepareRenderer(renderer, row, column);
				int modelRow = convertRowIndexToModel(row);
				int remainingQty = 0;

				try {
					Object value = getModel().getValueAt(modelRow, getModel().getColumnCount() - 1);
					if (value instanceof Integer) {
						remainingQty = (Integer) value;
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

				if (!isRowSelected(row)) {
					if (remainingQty <= 0) { // Changed to <= 0 for "Out of Stock"
						c.setBackground(Color.RED);
						c.setForeground(Color.WHITE);
					} else {
						c.setBackground(Color.WHITE);
						c.setForeground(Color.BLACK);
					}
				}
				if (column == 4) {
					c.setBackground(Color.WHITE);
					c.setForeground(Color.BLUE);
					c.setFont(new Font("Arial", Font.BOLD, 20));
				}
				return c;
			}

			@Override
			public TableCellEditor getCellEditor(int row, int column) {
				int modelColumn = convertColumnIndexToModel(column);
				JComboBox<?> combo = createComboBoxForColumn(modelColumn, row);
				if (combo != null) {
					styleComboBox(combo);
					return new DefaultCellEditor(combo);
				}
				return super.getCellEditor(row, column);
			}
		};

		table.setFont(new Font("SansSerif", Font.PLAIN, 20));
		table.setRowHeight(50);
		table.setIntercellSpacing(new Dimension(20, 20));
		table.setShowGrid(true);

		JTableHeader header = table.getTableHeader();
		header.setFont(new Font("SansSerif", Font.BOLD, 24));
		header.setBackground(new Color(0x404040));
		header.setForeground(Color.WHITE);
		header.setPreferredSize(new Dimension(header.getPreferredSize().width, 40));
		header.setDefaultRenderer(new HeaderRenderer());
	}

	private JComboBox<?> createComboBoxForColumn(int column, int row) {
		switch (column) {
		case 1:
			return new JComboBox<>(supplierList.toArray(new Supplier[0]));
		case 2:
			return new JComboBox<>(brandList.toArray(new Brand[0]));
		case 3:
			return createModelComboBox(row);
		case 4:
			return new JComboBox<>(partList.toArray(new Part[0]));
		default:
			return null;
		}
	}

	private JComboBox<Model> createModelComboBox(int row) {
		Brand selectedBrandInRow = (Brand) table.getValueAt(row, 2);
		DefaultComboBoxModel<Model> model = new DefaultComboBoxModel<>();
		if (selectedBrandInRow != null && modelList != null) {
			modelList.stream().filter(m -> m.getBrand() != null && m.getBrand().equals(selectedBrandInRow))
					.forEach(model::addElement);
		}
		return new JComboBox<>(model);
	}

	private void styleComboBox(JComboBox<?> combo) {
		combo.setFont(new Font("SansSerif", Font.PLAIN, 15));
		combo.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 0));
	}

	private void createButtons() {
		btnAdd = createStyledButton("Add", e -> {
			partRecieptForm = new PartRecieptForm(partReceiptService, this);
			partRecieptForm.setModal(true);
			partRecieptForm.setVisible(true);
		});
		btnUpdate = createStyledButton("Update", e -> {
			stopEditing();
			updateSelectedRow();
		});
		btnDelete = createStyledButton("Delete", e -> {
			stopEditing();
			deleteSelectedRow();
		});
		btnAddBrand = createStyledButton("Add Brand", e -> addBrand());
		btnAddSpares = createStyledButton("Add Spares", e -> addSpares());
		btnApplyService = createStyledButton("Apply Service", e -> openApplyServiceForm());
		btnDetails = createStyledButton("Details", e -> openPurchaseDetails());
	}

	private void createFilterComponents() {
		lblFromDate = new JLabel("From Date:");
		lblFromDate.setFont(new Font("SansSerif", Font.PLAIN, 15));
		lblToDate = new JLabel("To Date:");
		lblToDate.setFont(new Font("SansSerif", Font.PLAIN, 15));
		lblFilterSupplier = new JLabel("Supplier:");
		lblFilterSupplier.setFont(new Font("SansSerif", Font.PLAIN, 15));
		lblFilterBrand = new JLabel("Brand:");
		lblFilterBrand.setFont(new Font("SansSerif", Font.PLAIN, 15));
		lblFilterModel = new JLabel("Model:");
		lblFilterModel.setFont(new Font("SansSerif", Font.PLAIN, 15));
		lblStockStatus = new JLabel("Stock:");
		lblStockStatus.setFont(new Font("SansSerif", Font.PLAIN, 15));

		fromDateChooser = new JDateChooser();
		fromDateChooser.setFont(new Font("SansSerif", Font.PLAIN, 15));
		fromDateChooser.setDateFormatString("dd-MM-yyyy");
		fromDateChooser.setPreferredSize(new Dimension(130, fromDateChooser.getPreferredSize().height));

		toDateChooser = new JDateChooser();
		toDateChooser.setFont(new Font("SansSerif", Font.PLAIN, 15));
		toDateChooser.setDateFormatString("dd-MM-yyyy");
		toDateChooser.setPreferredSize(new Dimension(130, toDateChooser.getPreferredSize().height));

		comboSupplier = new JComboBox<>();
		styleComboBox(comboSupplier);
		comboSupplier.setPreferredSize(new Dimension(130, comboSupplier.getPreferredSize().height));

		comboBrand = new JComboBox<>();
		styleComboBox(comboBrand);
		comboBrand.setPreferredSize(new Dimension(130, comboBrand.getPreferredSize().height));
		comboBrand.addActionListener(e -> handleBrandChangeForModelCombo());

		comboModel = new JComboBox<>();
		styleComboBox(comboModel);
		comboModel.setPreferredSize(new Dimension(130, comboModel.getPreferredSize().height));
		comboModel.setEditable(true);
		JTextField modelEditor = (JTextField) comboModel.getEditor().getEditorComponent();
		modelEditor.getDocument().addDocumentListener(createModelAutoCompleteListener(modelEditor));
		
		comboStockStatus = new JComboBox<>(new String[] { "All", "In Stock", "Out of Stock" });
		styleComboBox(comboStockStatus);
		comboStockStatus.setPreferredSize(new Dimension(130, comboStockStatus.getPreferredSize().height));

		btnSearch = createStyledButton("Filter", e -> filterResults());
		btnSearch.setPreferredSize(new Dimension(90, 40));
	}
	
	private void handleBrandChangeForModelCombo() {
		JTextField modelEditor = (JTextField) comboModel.getEditor().getEditorComponent();
		String currentTextInModelEditor = modelEditor.getText();
		updateModelComboBoxFilter(currentTextInModelEditor);

		SwingUtilities.invokeLater(() -> {
			String editorTextAfterUpdate = modelEditor.getText();
			boolean modelSelected = false;
			if (editorTextAfterUpdate.isEmpty() || editorTextAfterUpdate.equals(modelAllOption.getName())) {
				for (int i = 0; i < comboModel.getItemCount(); i++) {
					Model item = comboModel.getItemAt(i);
					if (item != null && modelAllOption.getName().equals(item.getName())) {
						isUpdatingModelComboByCode = true;
						comboModel.setSelectedItem(item);
						isUpdatingModelComboByCode = false;
						modelSelected = true;
						break;
					}
				}
				if (!modelSelected && comboModel.getItemCount() > 0) {
					isUpdatingModelComboByCode = true;
					comboModel.setSelectedIndex(0);
					isUpdatingModelComboByCode = false;
				}
			}
		});
	}

	private DocumentListener createModelAutoCompleteListener(final JTextField editor) {
		return new DocumentListener() {
			@Override
			public void insertUpdate(DocumentEvent e) { filter(); }
			@Override
			public void removeUpdate(DocumentEvent e) { filter(); }
			@Override
			public void changedUpdate(DocumentEvent e) { filter(); }

			public void filter() {
				if (isUpdatingModelComboByCode) {
					return;
				}
				SwingUtilities.invokeLater(() -> {
					String typedText = editor.getText();
					updateModelComboBoxFilter(typedText);
				});
			}
		};
	}
	
	private void updateModelComboBoxFilter(String typedText) {
		if (isUpdatingModelComboByCode) return;
		isUpdatingModelComboByCode = true;

		if (this.modelList == null) {
			if (modelService != null) {
				this.modelList = modelService.getAllModels();
			}
			if (this.modelList == null) {
				 this.modelList = new ArrayList<>();
				 System.err.println("Warning: modelList was null in updateModelComboBoxFilter and could not be reloaded.");
			}
		}

		selectedBrand = null;
		if (comboBrand != null && comboBrand.getSelectedItem() instanceof Brand) {
			selectedBrand = (Brand) comboBrand.getSelectedItem();
		}

		List<Model> modelsForCurrentBrandContext = new ArrayList<>();
		modelsForCurrentBrandContext.add(modelAllOption);

		if (selectedBrand != null && selectedBrand.getName() != null && !"All".equalsIgnoreCase(selectedBrand.getName())) {
			List<Model> brandSpecificModels = this.modelList.stream()
					.filter(m -> m != null && m.getBrand() != null && selectedBrand.equals(m.getBrand()))
					.collect(Collectors.toList());
			modelsForCurrentBrandContext.addAll(brandSpecificModels);
		} else {
			modelsForCurrentBrandContext.addAll(this.modelList);
		}
		
		List<Model> distinctBaseModels = modelsForCurrentBrandContext.stream().distinct().collect(Collectors.toList());
		List<Model> filteredModelsToShow = new ArrayList<>();

		if (typedText == null || typedText.isEmpty()) {
			filteredModelsToShow.addAll(distinctBaseModels);
		} else {
			String lowerCaseTypedText = typedText.toLowerCase();
			for (Model m : distinctBaseModels) {
				if (m != null && m.getName() != null && m.getName().toLowerCase().contains(lowerCaseTypedText)) {
					filteredModelsToShow.add(m);
				}
			}
		}

		DefaultComboBoxModel<Model> newDcbm = new DefaultComboBoxModel<>();
		for (Model m : filteredModelsToShow) {
			newDcbm.addElement(m);
		}
		comboModel.setModel(newDcbm);

		JTextField modelEditor = (JTextField) comboModel.getEditor().getEditorComponent();
		modelEditor.setText(typedText);

		Model exactMatch = null;
		if (typedText != null && !typedText.isEmpty()) {
			for (Model m : filteredModelsToShow) {
				if (m != null && m.getName() != null && m.getName().equalsIgnoreCase(typedText)) {
					exactMatch = m;
					break;
				}
			}
		}

		if (exactMatch != null) {
			comboModel.setSelectedItem(exactMatch);
		} else if ((typedText == null || typedText.isEmpty()) && newDcbm.getSize() > 0) {
			boolean allSelected = false;
			for (int i = 0; i < newDcbm.getSize(); ++i) {
				Model currentItem = newDcbm.getElementAt(i);
				if (currentItem != null && modelAllOption.getName().equals(currentItem.getName())) {
					comboModel.setSelectedItem(currentItem);
					allSelected = true;
					break;
				}
			}
			if (!allSelected) comboModel.setSelectedIndex(0);
		}
		
		if (modelEditor.isFocusOwner() && comboModel.getItemCount() > 0 && typedText != null && !typedText.isEmpty() ) {
			 comboModel.showPopup();
		} else {
			 comboModel.hidePopup();
		}
		
		isUpdatingModelComboByCode = false;
	}

	private void openPurchaseDetails() {
		int selectedRow = table.getSelectedRow();
		if (selectedRow != -1) {
			Object value = table.getValueAt(selectedRow, 0);
			Long id;
			if (value instanceof Long) {
				id = (Long) value;
			} else if (value instanceof Integer) {
				id = ((Integer) value).longValue();
			} else {
				JOptionPane.showMessageDialog(null, "Invalid ID type.");
				return;
			}
			PurchaseDetails p = new PurchaseDetails(id);
			p.setModal(true);
			p.setVisible(true);
		} else {
			JOptionPane.showMessageDialog(null, "Please select a row.", "No Selection", JOptionPane.WARNING_MESSAGE);
		}
	}

	private void addSpares() {
		SparePartsForm ss = new SparePartsForm(partService, null);
		ss.setModal(true);
		ss.setVisible(true);
	}

	private void addBrand() {
		BrandForm b = new BrandForm();
		b.setModal(true);
		b.setVisible(true);
	}
	
	public void refreshBrandCombo() {
		if (brandService != null && comboBrand != null) {
			List<Brand> updatedBrandList = brandService.getAllBrands();
			if (updatedBrandList == null) updatedBrandList = new ArrayList<>();
			
			this.brandList.clear();
			this.brandList.addAll(updatedBrandList);

			DefaultComboBoxModel<Brand> brandDcbm = new DefaultComboBoxModel<>();
			Brand bAll = new Brand();
			bAll.setName("All");
			brandDcbm.addElement(bAll);
			for (Brand brd : this.brandList) {
				brandDcbm.addElement(brd);
			}
			comboBrand.setModel(brandDcbm);

			if (brandDcbm.getSize() > 0) {
				comboBrand.setSelectedIndex(0);
			} else {
				handleBrandChangeForModelCombo();
			}
		}
	}


	private JButton createStyledButton(String text, ActionListener listener) {
		JButton button = new JButton(text);
		button.setFont(new Font("SansSerif", Font.BOLD, 14));
		button.setBackground(Color.CYAN);
		button.setFocusPainted(false);
		button.setPreferredSize(new Dimension(120, 40));
		button.addActionListener(listener);
		return button;
	}

	private void setupLayout() {
		GroupLayout layout = new GroupLayout(contentPane);
		contentPane.setLayout(layout);
		JScrollPane scrollPane = new JScrollPane(table);

		layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
			.addGroup(layout.createSequentialGroup().addComponent(lblSearch).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(textField))
			.addGroup(layout.createSequentialGroup()
				.addComponent(lblFromDate)
				.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
				.addComponent(fromDateChooser, GroupLayout.PREFERRED_SIZE, 130, GroupLayout.PREFERRED_SIZE)
				.addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
				.addComponent(lblToDate)
				.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
				.addComponent(toDateChooser, GroupLayout.PREFERRED_SIZE, 130, GroupLayout.PREFERRED_SIZE)
				.addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
				.addComponent(lblFilterSupplier)
				.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
				.addComponent(comboSupplier, GroupLayout.PREFERRED_SIZE, 130, GroupLayout.PREFERRED_SIZE)
				.addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
				.addComponent(lblFilterBrand)
				.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
				.addComponent(comboBrand, GroupLayout.PREFERRED_SIZE, 130, GroupLayout.PREFERRED_SIZE)
				.addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
				.addComponent(lblFilterModel)
				.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
				.addComponent(comboModel, GroupLayout.PREFERRED_SIZE, 130, GroupLayout.PREFERRED_SIZE)
				.addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
				.addComponent(lblStockStatus)
				.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
				.addComponent(comboStockStatus, GroupLayout.PREFERRED_SIZE, 130, GroupLayout.PREFERRED_SIZE)
				.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				.addComponent(btnSearch, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
			.addGroup(layout.createSequentialGroup().addComponent(btnAddBrand)
				.addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
				.addComponent(btnAddSpares)
				.addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
				.addComponent(btnApplyService)
				.addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
				.addComponent(btnDetails))
			.addComponent(scrollPane)
			.addGroup(GroupLayout.Alignment.TRAILING,
				layout.createSequentialGroup().addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addComponent(btnAdd).addComponent(btnUpdate).addComponent(btnDelete).addContainerGap()));

		layout.setVerticalGroup(layout.createSequentialGroup()
			.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
				.addComponent(lblSearch).addComponent(textField))
			.addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
			.addGroup(layout.createParallelGroup(GroupLayout.Alignment.CENTER)
				.addComponent(lblFromDate).addComponent(fromDateChooser, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
				.addComponent(lblToDate).addComponent(toDateChooser, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
				.addComponent(lblFilterSupplier).addComponent(comboSupplier, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
				.addComponent(lblFilterBrand).addComponent(comboBrand, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
				.addComponent(lblFilterModel).addComponent(comboModel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
				.addComponent(lblStockStatus).addComponent(comboStockStatus, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
				.addComponent(btnSearch, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
			.addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
			.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
				.addComponent(btnAddBrand).addComponent(btnAddSpares)
				.addComponent(btnApplyService).addComponent(btnDetails))
			.addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
			.addComponent(scrollPane)
			.addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
			.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
				.addComponent(btnAdd).addComponent(btnUpdate).addComponent(btnDelete)));
	}

	public void loadInitialData() {
		supplierList = supplierService.getAllSuppliers();
		brandList = brandService.getAllBrands();
		modelList = modelService.getAllModels();
		partList = partService.getAllParts();
		fullReceiptList = partReceiptService.getAllReceipts();

		if (modelList == null) modelList = new ArrayList<>();
		if (brandList == null) brandList = new ArrayList<>();
		if (supplierList == null) supplierList = new ArrayList<>();
		if (partList == null) partList = new ArrayList<>();
		if (fullReceiptList == null) fullReceiptList = new ArrayList<>();
		
		updateRemainingQtyMap();
		loadCombos();
		updateTableModel(fullReceiptList);
	}
	
	private void updateRemainingQtyMap() {
		if (partReceiptStockService != null) {
			List<PartReceiptStock> pst = partReceiptStockService.getAllPartReceiptStocks();
			remainingQtyMap = new HashMap<>(); 
			if (pst != null) {
				for (PartReceiptStock stock : pst) {
					if (stock.getReceipt() != null) {
						int remaining = stock.getQuantityReceived() - stock.getQuantityUsed();
						remainingQtyMap.put(stock.getReceipt().getReceiptId(), remaining);
					}
				}
			}
		} else {
			remainingQtyMap = new HashMap<>(); 
		}
	}


	private void loadCombos() {
		DefaultComboBoxModel<Supplier> supplierDcbm = new DefaultComboBoxModel<>();
		Supplier sAll = new Supplier(); sAll.setName("All");
		supplierDcbm.addElement(sAll);
		if (supplierList != null) {
			for (Supplier sup : supplierList) supplierDcbm.addElement(sup);
		}
		comboSupplier.setModel(supplierDcbm);
		if (supplierDcbm.getSize() > 0) comboSupplier.setSelectedIndex(0);

		DefaultComboBoxModel<Brand> brandDcbm = new DefaultComboBoxModel<>();
		Brand bAll = new Brand(); bAll.setName("All");
		brandDcbm.addElement(bAll);
		if (brandList != null) {
			for (Brand brd : brandList) brandDcbm.addElement(brd);
		}
		comboBrand.setModel(brandDcbm);

		if (brandDcbm.getSize() > 0) {
			comboBrand.setSelectedIndex(0);
		} else {
			 handleBrandChangeForModelCombo();
		}
	}

	private void setupWindowListener() {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				if (context != null) {
					context.close();
				}
				super.windowClosing(e);
			}
		});
	}

	public void updateTableModel(List<PartReceipt> receipts) {
		DefaultTableModel model = new DefaultTableModel(new String[] { "Receipt ID", "Supplier", "Brand", "Model",
				"Part", "Quantity", "Date", "Cost", "Remaining Qty" }, 0) {
			@Override
			public boolean isCellEditable(int row, int column) {
				return column != 0;
			}

			@Override
			public Class<?> getColumnClass(int column) {
				switch (column) {
				case 0: return Long.class;
				case 1: return Supplier.class;
				case 2: return Brand.class;
				case 3: return Model.class;
				case 4: return Part.class;
				case 5: return Integer.class;
				case 6: return String.class;
				case 7: return BigDecimal.class;
				case 8: return Integer.class;
				default: return Object.class;
				}
			}
		};

		if (receipts != null) {
			SimpleDateFormat tableDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			for (PartReceipt r : receipts) {
				int remainingQty = remainingQtyMap.getOrDefault(r.getReceiptId(), 0);
				Object brandObj = (r.getModel() != null) ? r.getModel().getBrand() : null;
				model.addRow(new Object[] { r.getReceiptId(), r.getSupplier(), brandObj,
						r.getModel(), r.getPart(), r.getQuantity(),
						r.getReceiptDate() != null ? tableDateFormat.format(r.getReceiptDate()) : "", r.getUnitCost(),
						remainingQty });
			}
		}
		table.setModel(model);
		table.getColumnModel().getColumn(1).setPreferredWidth(200);
		table.getColumnModel().getColumn(3).setPreferredWidth(100);
		table.getColumnModel().getColumn(4).setPreferredWidth(200);
		table.getColumnModel().getColumn(6).setPreferredWidth(200);
		configureColumnRenderers();
	}

	private void configureColumnRenderers() {
		for (int i = 0; i < table.getColumnCount(); i++) {
			table.getColumnModel().getColumn(i).setCellRenderer(new DefaultTableCellRenderer() {
				{
					setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
				}
				@Override
				public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
						boolean hasFocus, int row, int column) {
					super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
					if (value instanceof Supplier) setText(((Supplier) value).getName());
					else if (value instanceof Brand) setText(((Brand) value).getName());
					else if (value instanceof Model) setText(((Model) value).getName());
					else if (value instanceof Part) setText(((Part) value).getName());
					return this;
				}
			});
		}
	}

	private void filterTable(String query) {
		if (fullReceiptList == null) fullReceiptList = new ArrayList<>();
		if (query == null || query.isEmpty()) {
			updateTableModel(fullReceiptList);
			return;
		}
		List<PartReceipt> filtered = fullReceiptList.stream().filter(r -> containsQuery(r, query))
				.collect(Collectors.toList());
		updateTableModel(filtered);
	}

	private boolean containsQuery(PartReceipt r, String query) {
		if (r == null || query == null) return false;
		String lowerCaseQuery = query.toLowerCase();
		return (r.getSupplier() != null && r.getSupplier().getName() != null && r.getSupplier().getName().toLowerCase().contains(lowerCaseQuery))
				|| (r.getPart() != null && r.getPart().getName() != null && r.getPart().getName().toLowerCase().contains(lowerCaseQuery))
				|| (r.getModel() != null && r.getModel().getName() != null && r.getModel().getName().toLowerCase().contains(lowerCaseQuery))
				|| (r.getModel() != null && r.getModel().getBrand() != null && r.getModel().getBrand().getName() != null
						&& r.getModel().getBrand().getName().toLowerCase().contains(lowerCaseQuery));
	}

	private void stopEditing() {
		if (table.isEditing())
			table.getCellEditor().stopCellEditing();
	}

	private void updateSelectedRow() {
		int viewRow = table.getSelectedRow();
		if (viewRow < 0) {
			JOptionPane.showMessageDialog(this, "Please select a row to update", "Warning", JOptionPane.WARNING_MESSAGE);
			return;
		}
		try {
			int modelRow = table.convertRowIndexToModel(viewRow);
			DefaultTableModel dtm = (DefaultTableModel) table.getModel();
			PartReceipt receipt = createReceiptFromModel(dtm, modelRow);
			if (partReceiptService != null && receipt != null) {
				partReceiptService.update(receipt);
				JOptionPane.showMessageDialog(this, "Update successful", "Success", JOptionPane.INFORMATION_MESSAGE);
				refreshTable();
			} else {
				showError("Update failed: service or receipt data is null.");
			}
		} catch (Exception ex) {
			showError("Update error: " + ex.getMessage());
			ex.printStackTrace();
		}
	}

	private PartReceipt createReceiptFromModel(DefaultTableModel model, int row) throws ParseException {
		PartReceipt receipt = new PartReceipt();
		receipt.setReceiptId((Long) model.getValueAt(row, 0));
		receipt.setSupplier((Supplier) model.getValueAt(row, 1));
		receipt.setModel((Model) model.getValueAt(row, 3));
		receipt.setPart((Part) model.getValueAt(row, 4));
		receipt.setQuantity((Integer) model.getValueAt(row, 5));
		Object dateValue = model.getValueAt(row, 6);
		if (dateValue instanceof String && !((String)dateValue).isEmpty()) {
			receipt.setReceiptDate(DATE_FORMAT.parse((String) dateValue));
		}
		receipt.setUnitCost((BigDecimal) model.getValueAt(row, 7));
		return receipt;
	}

	private void deleteSelectedRow() {
		int viewRow = table.getSelectedRow();
		if (viewRow < 0) {
			JOptionPane.showMessageDialog(this, "Please select a row to delete", "Warning", JOptionPane.WARNING_MESSAGE);
			return;
		}
		int confirm = JOptionPane.showConfirmDialog(this, "Delete this receipt permanently?", "Confirm", JOptionPane.YES_NO_OPTION);
		if (confirm == JOptionPane.YES_OPTION) {
			try {
				Long receiptId = (Long) table.getModel().getValueAt(table.convertRowIndexToModel(viewRow), 0);
				if (partReceiptService != null) {
					partReceiptService.delete(receiptId);
					refreshTable();
				}
			} catch (Exception ex) {
				showError("Delete error: " + ex.getMessage());
				ex.printStackTrace();
			}
		}
	}

	public void refreshTable() {
		if (partReceiptService != null) {
			fullReceiptList = partReceiptService.getAllReceipts();
			if (fullReceiptList == null) fullReceiptList = new ArrayList<>();
		} else {
			fullReceiptList = new ArrayList<>();
		}
		
		updateRemainingQtyMap();
		
		String currentSearchQuery = "";
		if (textField != null) currentSearchQuery = textField.getText().trim().toLowerCase();
		
		boolean isAdvancedFilterActive = (fromDateChooser != null && fromDateChooser.getDate() != null) ||
									(toDateChooser != null && toDateChooser.getDate() != null) ||
									(comboSupplier != null && comboSupplier.getSelectedItem() != null && !"All".equalsIgnoreCase(((Supplier)comboSupplier.getSelectedItem()).getName())) ||
									(comboBrand != null && comboBrand.getSelectedItem() != null && !"All".equalsIgnoreCase(((Brand)comboBrand.getSelectedItem()).getName())) ||
									(comboModel != null && comboModel.getSelectedItem() != null && !"All".equalsIgnoreCase(((Model)comboModel.getSelectedItem()).getName())) ||
									(comboStockStatus != null && comboStockStatus.getSelectedItem() != null && !"All".equals(comboStockStatus.getSelectedItem()));

		if (!currentSearchQuery.isEmpty() || isAdvancedFilterActive) {
			filterResults(); 
		} else {
			updateTableModel(fullReceiptList);
		}
	}

	private void showError(String message) {
		JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
	}

	private void openApplyServiceForm() {
		int viewRow = table.getSelectedRow();
		if (viewRow >= 0) {
			int modelRow = table.convertRowIndexToModel(viewRow);
			Long receiptId = (Long) table.getModel().getValueAt(modelRow, 0);
			if (partReceiptService != null) {
				PartReceipt pr = partReceiptService.getById(receiptId);
				if (pr != null) {
					PartsUsedForm pp = new PartsUsedForm(pr, this);
					pp.setModal(true);
					pp.setVisible(true);
				} else {
					showError("Selected receipt not found.");
				}
			}
		} else {
			JOptionPane.showMessageDialog(this, "Select a row");
		}
	}

	public void updateColorStatus(Long prId) {
		table.repaint();
		table.clearSelection();
	}
	
	private void filterResults() {
		if (fullReceiptList == null) fullReceiptList = new ArrayList<>();

		Date tempFromDate = null;
		Date tempToDate = null;

		if(fromDateChooser != null) tempFromDate = fromDateChooser.getDate();
		if(toDateChooser != null) tempToDate = toDateChooser.getDate();

		if (tempFromDate != null) {
			Calendar cal = Calendar.getInstance();
			cal.setTime(tempFromDate);
			cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0);
			fromDate = cal.getTime();
		} else {
			fromDate = null;
		}

		if (tempToDate != null) {
			Calendar cal = Calendar.getInstance();
			cal.setTime(tempToDate);
			cal.set(Calendar.HOUR_OF_DAY, 23); cal.set(Calendar.MINUTE, 59); cal.set(Calendar.SECOND, 59); cal.set(Calendar.MILLISECOND, 999);
			toDate = cal.getTime();
		} else {
			toDate = null;
		}

		Supplier selectedSupplier = (comboSupplier != null && comboSupplier.getSelectedItem() instanceof Supplier) ? (Supplier) comboSupplier.getSelectedItem() : null;
		Brand selectedBrand = (comboBrand != null && comboBrand.getSelectedItem() instanceof Brand) ? (Brand) comboBrand.getSelectedItem() : null;
		Model selectedModel = (comboModel != null && comboModel.getSelectedItem() instanceof Model) ? (Model) comboModel.getSelectedItem() : null;
		String selectedStockStatus = (comboStockStatus != null && comboStockStatus.getSelectedItem() != null) ? (String) comboStockStatus.getSelectedItem() : "All";
		
		String textSearchQuery = textField.getText().trim().toLowerCase();

		List<PartReceipt> filteredList = fullReceiptList.stream().filter(r -> {
			boolean dateMatch = (fromDate == null || !r.getReceiptDate().before(fromDate)) &&
								(toDate == null || !r.getReceiptDate().after(toDate));

			boolean supplierMatch = selectedSupplier == null || "All".equalsIgnoreCase(selectedSupplier.getName()) ||
									(r.getSupplier() != null && r.getSupplier().equals(selectedSupplier));

			boolean brandMatch = selectedBrand == null || "All".equalsIgnoreCase(selectedBrand.getName()) ||
								 (r.getModel() != null && r.getModel().getBrand() != null && r.getModel().getBrand().equals(selectedBrand));

			boolean modelMatch = selectedModel == null || "All".equalsIgnoreCase(selectedModel.getName()) ||
								 (r.getModel() != null && r.getModel().equals(selectedModel));

			boolean stockMatch = true;
			if (selectedStockStatus != null && !"All".equals(selectedStockStatus)) {
				int remainingQty = remainingQtyMap.getOrDefault(r.getReceiptId(), 0);
				if ("In Stock".equals(selectedStockStatus)) {
					stockMatch = remainingQty > 0;
				} else if ("Out of Stock".equals(selectedStockStatus)) {
					stockMatch = remainingQty <= 0;
				}
			}
			
			boolean textMatch = textSearchQuery.isEmpty() || containsQuery(r, textSearchQuery);

			return dateMatch && supplierMatch && brandMatch && modelMatch && stockMatch && textMatch;
		}).collect(Collectors.toList());

		updateTableModel(filteredList);
	}
	class HeaderRenderer extends DefaultTableCellRenderer {
	    public HeaderRenderer() {
	        setOpaque(true);
	    }

	    @Override
	    public Component getTableCellRendererComponent(JTable table, Object value,
	            boolean isSelected, boolean hasFocus, int row, int column) {
	        super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
	        setHorizontalAlignment(SwingConstants.CENTER);
	        return this;
	    }
	}
}