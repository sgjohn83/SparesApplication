package com.spares.ui;

import ca.odell.glazedlists.BasicEventList;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.swing.AutoCompleteSupport;
import com.spares.AppConfig;
import com.spares.model.*;
import com.spares.service.*;

import org.apache.commons.text.similarity.LevenshteinDistance;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.dao.DataAccessException;

import javax.persistence.PersistenceException;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.util.List;
import java.util.stream.Collectors;

public class PartsUsedForm extends JDialog {

    private final RepairPartsUsedService partsUsedService;
    private final PartReceiptService partReceiptService;
    private final SupplierService supplierService;
    private final MobileRepairService repairService;
    private final PartsUsedView parentView;

    private final JComboBox<Supplier>      cmbSupplier  = new JComboBox<>();
    private final JComboBox<Brand>         cmbBrand     = new JComboBox<>();
    private final JComboBox<Model>         cmbModel     = new JComboBox<>();
    private final JComboBox<Part>          cmbPart      = new JComboBox<>();
    private final JComboBox<PartReceipt>   cmbReceipt   = new JComboBox<>();
    private final JComboBox<MobileRepair>  cmbRepairId  = new JComboBox<>();
    private final JComboBox<String>        cmbStatus    = new JComboBox<>(new String[] { "USED", "FAILED" });
    private final JSpinner                 spnQuantity  = new JSpinner(new SpinnerNumberModel(1, 1, 999, 1));

    // For Autocomplete
    private final EventList<MobileRepair>  repairList   = new BasicEventList<>();
    private MobileRepairsView              mobileRepair;
    private PartRecieptView                partRecieptView;
    private Long                            prId;

    // --------------------------------------------------------------------------------------------
    // 1) Constructor: called from PartsUsedView
    // --------------------------------------------------------------------------------------------
    public PartsUsedForm(RepairPartsUsedService service, PartsUsedView view) {
        super((Frame) null, "Used Part Entry", true);

        // Apply a global Swing font of “Segoe UI 20px” for any component not overridden below
        setUIFont(new Font("Segoe UI", Font.PLAIN, 20));

        this.partsUsedService   = service;
        this.parentView         = view;

        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
        this.supplierService    = ctx.getBean(SupplierService.class);
        this.partReceiptService = ctx.getBean(PartReceiptService.class);
        this.repairService      = ctx.getBean(MobileRepairService.class);

        // Increase window size
        setSize(700, 600);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(new BorderLayout(12, 12));
        getContentPane().setBackground(new Color(245, 248, 250));

        add(createFormPanel(),   BorderLayout.CENTER);
        add(createButtonPanel(), BorderLayout.SOUTH);

        // Autocomplete for full MobileRepair entities
        AutoCompleteSupport.install(cmbRepairId, repairList);

        // Cascading dropdown listeners
        cmbSupplier.addItemListener(e -> { if (e.getStateChange() == ItemEvent.SELECTED) loadBrands(); });
        cmbBrand   .addItemListener(e -> { if (e.getStateChange() == ItemEvent.SELECTED) loadModels(); });
        cmbModel   .addItemListener(e -> { if (e.getStateChange() == ItemEvent.SELECTED) loadParts(); });
        cmbPart    .addItemListener(e -> { if (e.getStateChange() == ItemEvent.SELECTED) loadReceipts(); });

        loadSuppliers();
        loadRepairIds();
    }

    // --------------------------------------------------------------------------------------------
    // 2) Constructor: called when opening from MobileRepairsView with a pre‐set ID
    // --------------------------------------------------------------------------------------------
    public PartsUsedForm(Long idValue, MobileRepairsView mobileRepair) {
        super((Frame) null, "Used Part Entry", true);

        setUIFont(new Font("Segoe UI", Font.PLAIN, 20));

        this.mobileRepair        = mobileRepair;
        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
        this.supplierService     = ctx.getBean(SupplierService.class);
        this.partReceiptService  = ctx.getBean(PartReceiptService.class);
        this.repairService       = ctx.getBean(MobileRepairService.class);
        this.partsUsedService    = ctx.getBean(RepairPartsUsedService.class);
        this.parentView          = null; // No PartsUsedView to refresh

        setSize(700, 600);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(new BorderLayout(12, 12));
        getContentPane().setBackground(new Color(245, 248, 250));

        add(createFormPanel(),   BorderLayout.CENTER);
        add(createButtonPanel(), BorderLayout.SOUTH);

        AutoCompleteSupport.install(cmbRepairId, repairList);

        cmbSupplier.addItemListener(e -> { if (e.getStateChange() == ItemEvent.SELECTED) loadBrands(); });
        cmbBrand   .addItemListener(e -> { if (e.getStateChange() == ItemEvent.SELECTED) loadModels(); });
        cmbModel   .addItemListener(e -> { if (e.getStateChange() == ItemEvent.SELECTED) loadParts(); });
        cmbPart    .addItemListener(e -> { if (e.getStateChange() == ItemEvent.SELECTED) loadReceipts(); });

        loadSuppliers();
        loadRepairIds();

        setRepairId(idValue);
    }

    // --------------------------------------------------------------------------------------------
    // 3) Constructor: called when opening from PartRecieptView with an existing PartReceipt
    // --------------------------------------------------------------------------------------------
    public PartsUsedForm(PartReceipt pr, PartRecieptView partRecieptView) {
        super((Frame) null, "Used Part Entry", true);

        setUIFont(new Font("Segoe UI", Font.PLAIN, 20));

        this.prId                = pr.getReceiptId();
        this.partRecieptView     = partRecieptView;
        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
        this.supplierService     = ctx.getBean(SupplierService.class);
        this.partReceiptService  = ctx.getBean(PartReceiptService.class);
        this.repairService       = ctx.getBean(MobileRepairService.class);
        this.partsUsedService    = ctx.getBean(RepairPartsUsedService.class);
        this.parentView          = null;

        setSize(700, 600);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(new BorderLayout(12, 12));
        getContentPane().setBackground(new Color(245, 248, 250));

        add(createFormPanel(),   BorderLayout.CENTER);
        add(createButtonPanel(), BorderLayout.SOUTH);

        AutoCompleteSupport.install(cmbRepairId, repairList);

        cmbSupplier.addItemListener(e -> { if (e.getStateChange() == ItemEvent.SELECTED) loadBrands(); });
        cmbBrand   .addItemListener(e -> { if (e.getStateChange() == ItemEvent.SELECTED) loadModels(); });
        cmbModel   .addItemListener(e -> { if (e.getStateChange() == ItemEvent.SELECTED) loadParts(); });
        cmbPart    .addItemListener(e -> { if (e.getStateChange() == ItemEvent.SELECTED) loadReceipts(); });

        loadSuppliers();
        loadRepairIds();

        // Pre‐select all cascading fields based on the given PartReceipt
        setSupplier(pr);
        setBrand(pr);
        setModel(pr);
        setPart(pr);
        setPartReciept(pr);
        setServiceId(pr);
    }

    // --------------------------------------------------------------------------------------------
    // 4) Dummy constructor kept for compatibility
    // --------------------------------------------------------------------------------------------
    public PartsUsedForm(RepairPartsUsedService partsUsedService2, PurchaseDetails purchaseDetails) {
        setUIFont(new Font("Segoe UI", Font.PLAIN, 20));

        parentView        = null;
        supplierService   = null;
        repairService     = null;
        partsUsedService  = null;
        partReceiptService= null;
    }

    // ============================================================================================
    //   Helper methods for pre‐selection (when opening with PartReceipt)
    // ============================================================================================

    private void setServiceId(PartReceipt pr) {
        if (pr == null || pr.getModel() == null || pr.getModel().getBrand() == null) return;

        String expectedModel = (pr.getModel().getBrand().getName() + " " + pr.getModel().getName())
                                   .toLowerCase()
                                   .trim();
        if (expectedModel.isEmpty()) return;

        LevenshteinDistance levenshtein = new LevenshteinDistance();
        int threshold = 5;

        List<MobileRepair> allRepairs = repairService.getAllRepairs();
        List<MobileRepair> filtered = allRepairs.stream()
            .filter(m -> m.getDeviceModel() != null
                      && levenshtein.apply(expectedModel, m.getDeviceModel().toLowerCase().trim()) <= threshold)
            .collect(Collectors.toList());

        repairList.getReadWriteLock().writeLock().lock();
        try {
            repairList.clear();
            repairList.addAll(filtered);
        } finally {
            repairList.getReadWriteLock().writeLock().unlock();
        }

        if (!filtered.isEmpty()) {
            cmbRepairId.setSelectedItem(filtered.get(0));
        } else {
            cmbRepairId.setSelectedItem(null);
        }
    }

    private void setPartReciept(PartReceipt pr) {
        cmbReceipt.setSelectedItem(pr);
    }

    private void setPart(PartReceipt pr) {
        cmbPart.setSelectedItem(pr.getPart());
    }

    private void setModel(PartReceipt pr) {
        cmbModel.setSelectedItem(pr.getModel());
    }

    private void setBrand(PartReceipt pr) {
        cmbBrand.setSelectedItem(pr.getModel().getBrand());
    }

    private void setSupplier(PartReceipt pr) {
        cmbSupplier.setSelectedItem(pr.getSupplier());
    }

    private void setRepairId(Long idValue) {
        // Assuming MobileRepair.toString() or equals() matches the ID value
        cmbRepairId.setSelectedItem(idValue);
    }

    // ============================================================================================
    //   Loading dropdown lists (cascading)
    // ============================================================================================

    private void loadModels() {
        Brand b = (Brand) cmbBrand.getSelectedItem();
        List<Model> mlist = partReceiptService.getModelsByBrands(b);

        cmbModel.removeAllItems();
        cmbPart.removeAllItems();
        cmbReceipt.removeAllItems();

        for (Model m : mlist) {
            cmbModel.addItem(m);
        }
        if (cmbModel.getItemCount() > 0) {
            cmbModel.setSelectedIndex(0);
        }
    }

    private void loadBrands() {
        Supplier s = (Supplier) cmbSupplier.getSelectedItem();
        List<Brand> blist = partReceiptService.getBrandsBySupplier(s);

        cmbBrand.removeAllItems();
        cmbModel.removeAllItems();
        cmbPart.removeAllItems();
        cmbReceipt.removeAllItems();

        for (Brand b : blist) {
            cmbBrand.addItem(b);
        }
        if (cmbBrand.getItemCount() > 0) {
            cmbBrand.setSelectedIndex(0);
        }
    }

    private void loadParts() {
        cmbPart.removeAllItems();
        cmbReceipt.removeAllItems();

        Model m    = (Model) cmbModel.getSelectedItem();
        Supplier s = (Supplier) cmbSupplier.getSelectedItem();
        List<Part> plist = partReceiptService.getPartsByModelsAndSupplier(s, m);

        for (Part p : plist) {
            cmbPart.addItem(p);
        }
        if (cmbPart.getItemCount() > 0) {
            cmbPart.setSelectedIndex(0);
        }
    }

    private void loadReceipts() {
        cmbReceipt.removeAllItems();

        Part part  = (Part) cmbPart.getSelectedItem();
        Model m    = (Model) cmbModel.getSelectedItem();
        Supplier s = (Supplier) cmbSupplier.getSelectedItem();

        List<PartReceipt> prList = partReceiptService.getPartReceiptsByPart(part, s, m);
        for (PartReceipt p : prList) {
            cmbReceipt.addItem(p);
        }
        if (cmbReceipt.getItemCount() > 0) {
            cmbReceipt.setSelectedIndex(0);
        }
    }

    private void loadRepairIds() {
        repairList.getReadWriteLock().writeLock().lock();
        try {
            repairList.clear();
            repairService.getAllRepairs().forEach(repairList::add);
        } finally {
            repairList.getReadWriteLock().writeLock().unlock();
        }
    }

    private void loadSuppliers() {
        cmbSupplier.removeAllItems();
        cmbBrand.removeAllItems();
        cmbModel.removeAllItems();
        cmbPart.removeAllItems();
        cmbReceipt.removeAllItems();

        supplierService.getAllSuppliers().forEach(cmbSupplier::addItem);
        if (cmbSupplier.getItemCount() > 0) {
            cmbSupplier.setSelectedIndex(0);
        }
    }

    // ============================================================================================
    //   Building the form UI
    // ============================================================================================

    private JPanel createFormPanel() {
        JPanel panel = new JPanel();
        panel.setBackground(new Color(245, 248, 250));
        panel.setBorder(BorderFactory.createTitledBorder("📦 Part Usage Details"));

        GroupLayout layout = new GroupLayout(panel);
        panel.setLayout(layout);

        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        // Create labels (all will use 20px Segoe UI)
        JLabel lblSupplier = new JLabel("Supplier:");
        JLabel lblBrand    = new JLabel("Brand:");
        JLabel lblModel    = new JLabel("Model:");
        JLabel lblPart     = new JLabel("Part:");
        JLabel lblReceipt  = new JLabel("Part Receipt:");
        JLabel lblRepairId = new JLabel("Repair ID:");
        JLabel lblQuantity = new JLabel("Quantity:");
        JLabel lblStatus   = new JLabel("Status:");

        // Fonts: 20px for both labels and inputs
        Font labelFont = new Font("Segoe UI", Font.PLAIN, 20);
        Font inputFont = new Font("Segoe UI", Font.PLAIN, 20);

        // Apply to every label
        for (JLabel lbl : new JLabel[] {
                lblSupplier, lblBrand, lblModel, lblPart,
                lblReceipt, lblRepairId, lblQuantity, lblStatus }) {
            lbl.setFont(labelFont);
        }

        // Apply to every JComboBox and JSpinner
        cmbSupplier .setFont(inputFont);
        cmbBrand    .setFont(inputFont);
        cmbModel    .setFont(inputFont);
        cmbPart     .setFont(inputFont);
        cmbReceipt  .setFont(inputFont);
        cmbRepairId .setFont(inputFont);
        cmbStatus   .setFont(inputFont);
        spnQuantity .setFont(inputFont);

        // Layout: two columns (labels on left, inputs on right)
        layout.setHorizontalGroup(
            layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                    .addComponent(lblSupplier)
                    .addComponent(lblBrand)
                    .addComponent(lblModel)
                    .addComponent(lblPart)
                    .addComponent(lblReceipt)
                    .addComponent(lblRepairId)
                    .addComponent(lblQuantity)
                    .addComponent(lblStatus))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(cmbSupplier)
                    .addComponent(cmbBrand)
                    .addComponent(cmbModel)
                    .addComponent(cmbPart)
                    .addComponent(cmbReceipt)
                    .addComponent(cmbRepairId)
                    .addComponent(spnQuantity)
                    .addComponent(cmbStatus))
        );

        layout.setVerticalGroup(
            layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSupplier)
                    .addComponent(cmbSupplier))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblBrand)
                    .addComponent(cmbBrand))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblModel)
                    .addComponent(cmbModel))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPart)
                    .addComponent(cmbPart))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblReceipt)
                    .addComponent(cmbReceipt))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblRepairId)
                    .addComponent(cmbRepairId))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblQuantity)
                    .addComponent(spnQuantity))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblStatus)
                    .addComponent(cmbStatus))
        );

        return panel;
    }

    private JPanel createButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 12));
        panel.setBackground(new Color(245, 248, 250));

        JButton btnSave   = new JButton("💾 Save");
        JButton btnCancel = new JButton("❌ Cancel");

        // Both buttons use 20px Segoe UI Bold
        Font buttonFont = new Font("Segoe UI", Font.BOLD, 20);
        btnSave  .setFont(buttonFont);
        btnCancel.setFont(buttonFont);

        btnSave  .setBackground(new Color(33, 150, 243));
        btnSave  .setForeground(Color.BLACK);
        btnSave  .setFocusPainted(false);
        btnSave  .setPreferredSize(new Dimension(120, 44)); // slightly larger

        btnCancel.setBackground(new Color(220, 53, 69));
        btnCancel.setForeground(Color.BLACK);
        btnCancel.setFocusPainted(false);
        btnCancel.setPreferredSize(new Dimension(120, 44));

        btnSave  .addActionListener(e -> saveUsedPart());
        btnCancel.addActionListener(e -> dispose());

        panel.add(btnSave);
        panel.add(btnCancel);

        return panel;
    }

    // ============================================================================================
    //   Saving logic
    // ============================================================================================
    private void saveUsedPart() {
        try {
            Supplier    supplier    = (Supplier) cmbSupplier.getSelectedItem();
            Part        part        = (Part) cmbPart.getSelectedItem();
            PartReceipt receipt     = (PartReceipt) cmbReceipt.getSelectedItem();
            MobileRepair mobileR    = (MobileRepair) cmbRepairId.getSelectedItem();
            int         qty         = (Integer) spnQuantity.getValue();
            String      status      = (String) cmbStatus.getSelectedItem();

            if (supplier == null || part == null || receipt == null || mobileR == null) {
                showError("Please complete all fields.");
                return;
            }

            RepairPartsUsed used = new RepairPartsUsed();
            used.setSupplier(supplier);
            used.setPart(part);
            used.setReceipt(receipt);
            used.setRepair(mobileR);
            used.setQuantityUsed(qty);
            used.setStatus(status);

            partsUsedService.save(used);
            JOptionPane.showMessageDialog(this, "✅ Part usage saved successfully!");

            if (parentView != null) {
                parentView.loadTable();
            }
            dispose();
        }
        catch (DataAccessException | PersistenceException e) {
            e.printStackTrace();
            ExceptionHandler.showRootCause(e);
        }

        if (partRecieptView != null && prId != null) {
            partRecieptView.loadInitialData();
        }
        dispose();
    }

    private void showError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    /**
     * Applies the given Font to all UI defaults (labels, buttons, menus, tooltips, etc.).
     * Any Swing component created after calling this method will automatically use it,
     * unless explicitly overridden.  
     */
    private static void setUIFont(Font font) {
        java.util.Enumeration<Object> keys = UIManager.getDefaults().keys();
        while (keys.hasMoreElements()) {
            Object key   = keys.nextElement();
            Object value = UIManager.get(key);
            if (value instanceof Font) {
                UIManager.put(key, font);
            }
        }
    }
}
