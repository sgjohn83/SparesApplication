package com.spares.ui;

import ca.odell.glazedlists.BasicEventList;
import ca.odell.glazedlists.EventList;
import ca.odell.glazedlists.swing.AutoCompleteSupport;
import com.spares.AppConfig;
import com.spares.model.*;
import com.spares.service.*;

import org.apache.commons.text.similarity.LevenshteinDistance;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.dao.DataAccessException;

import javax.persistence.PersistenceException;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class PartsUsedForm extends JDialog {

	private final RepairPartsUsedService partsUsedService;
	private final PartReceiptService partReceiptService;
	private final SupplierService supplierService;
	private final MobileRepairService repairService;
	private final PartsUsedView parentView;

	private final JComboBox<Supplier> cmbSupplier = new JComboBox<>();
	private final JComboBox<Brand> cmbBrand = new JComboBox<>();
	private final JComboBox<Model> cmbModel = new JComboBox<>();
	private final JComboBox<Part> cmbPart = new JComboBox<>();
	private final JComboBox<PartReceipt> cmbReceipt = new JComboBox<>();
	private final JComboBox<MobileRepair> cmbRepairId = new JComboBox<>();
	private final JComboBox<String> cmbStatus = new JComboBox<>(new String[] { "USED", "FAILED" });
	private final JSpinner spnQuantity = new JSpinner(new SpinnerNumberModel(1, 1, 999, 1));

	// Use MobileRepair entities for autocomplete list, not just IDs
	private final EventList<MobileRepair> repairList = new BasicEventList<>();
	private MobileRepairsView mobileRepair;
	private PartRecieptView partRecieptView;
	private Long prId;

	public PartsUsedForm(RepairPartsUsedService service, PartsUsedView view) {
		super((Frame) null, "Used Part Entry", true);
		this.partsUsedService = service;
		this.parentView = view;

		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
		this.supplierService = ctx.getBean(SupplierService.class);
		this.partReceiptService = ctx.getBean(PartReceiptService.class);
		this.repairService = ctx.getBean(MobileRepairService.class);

		setSize(520, 420);
		setLocationRelativeTo(null);
		setResizable(false);
		setLayout(new BorderLayout(12, 12));
		getContentPane().setBackground(new Color(245, 248, 250));

		add(createFormPanel(), BorderLayout.CENTER);
		add(createButtonPanel(), BorderLayout.SOUTH);

		// Setup autocomplete with full MobileRepair entities
		AutoCompleteSupport.install(cmbRepairId, repairList);

		// Listeners for cascading dropdown loading
		cmbSupplier.addItemListener(e -> {
			if (e.getStateChange() == ItemEvent.SELECTED)
				loadBrands();
		});

		cmbBrand.addItemListener(e -> {
			if (e.getStateChange() == ItemEvent.SELECTED)
				loadModels();
		});
		cmbModel.addItemListener(e -> {
			if (e.getStateChange() == ItemEvent.SELECTED)
				loadParts();
		});
		cmbPart.addItemListener(e -> {
			if (e.getStateChange() == ItemEvent.SELECTED)
				loadReceipts();
		});
		loadSuppliers();

		loadRepairIds();
	}

	public PartsUsedForm(Long idValue, MobileRepairsView mobileRepair) {
		super((Frame) null, "Used Part Entry", true);

		this.mobileRepair = mobileRepair;
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
		this.supplierService = ctx.getBean(SupplierService.class);
		this.partReceiptService = ctx.getBean(PartReceiptService.class);
		this.repairService = ctx.getBean(MobileRepairService.class);
		this.partsUsedService = ctx.getBean(RepairPartsUsedService.class);
		this.parentView = null;
		setSize(520, 420);
		setLocationRelativeTo(null);
		setResizable(false);
		setLayout(new BorderLayout(12, 12));
		getContentPane().setBackground(new Color(245, 248, 250));

		add(createFormPanel(), BorderLayout.CENTER);
		add(createButtonPanel(), BorderLayout.SOUTH);

		// Setup autocomplete with full MobileRepair entities
		AutoCompleteSupport.install(cmbRepairId, repairList);

		// Listeners for cascading dropdown loading
		cmbSupplier.addItemListener(e -> {
			if (e.getStateChange() == ItemEvent.SELECTED)
				loadBrands();
		});

		cmbBrand.addItemListener(e -> {
			if (e.getStateChange() == ItemEvent.SELECTED)
				loadModels();
		});
		cmbModel.addItemListener(e -> {
			if (e.getStateChange() == ItemEvent.SELECTED)
				loadParts();
		});
		cmbPart.addItemListener(e -> {
			if (e.getStateChange() == ItemEvent.SELECTED)
				loadReceipts();
		});
		loadSuppliers();

		loadRepairIds();
		setRepairId(idValue);

	}

	public PartsUsedForm(PartReceipt pr, PartRecieptView partRecieptView) {
		super((Frame) null, "Used Part Entry", true);
		this.prId = pr.getReceiptId();
		this.partRecieptView = partRecieptView;
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
		this.supplierService = ctx.getBean(SupplierService.class);
		this.partReceiptService = ctx.getBean(PartReceiptService.class);
		this.repairService = ctx.getBean(MobileRepairService.class);
		this.partsUsedService = ctx.getBean(RepairPartsUsedService.class);
		this.parentView = null;
		setSize(520, 420);
		setLocationRelativeTo(null);
		setResizable(false);
		setLayout(new BorderLayout(12, 12));
		getContentPane().setBackground(new Color(245, 248, 250));

		add(createFormPanel(), BorderLayout.CENTER);
		add(createButtonPanel(), BorderLayout.SOUTH);

		// Setup autocomplete with full MobileRepair entities
		AutoCompleteSupport.install(cmbRepairId, repairList);

		// Listeners for cascading dropdown loading
		cmbSupplier.addItemListener(e -> {
			if (e.getStateChange() == ItemEvent.SELECTED)
				loadBrands();
		});

		cmbBrand.addItemListener(e -> {
			if (e.getStateChange() == ItemEvent.SELECTED)
				loadModels();
		});
		cmbModel.addItemListener(e -> {
			if (e.getStateChange() == ItemEvent.SELECTED)
				loadParts();
		});
		cmbPart.addItemListener(e -> {
			if (e.getStateChange() == ItemEvent.SELECTED)
				loadReceipts();
		});
		loadSuppliers();

		loadRepairIds();

		setSupplier(pr);
		setBrand(pr);
		setModel(pr);
		setPart(pr);
		setPartReciept(pr);
		setServiceId(pr);

	}

	public PartsUsedForm(RepairPartsUsedService partsUsedService2, PurchaseDetails purchaseDetails) {
		parentView=null;
		supplierService=null;
		repairService=null;
		partsUsedService=null;
		partReceiptService=null;
	}

	private void setServiceId(PartReceipt pr) {
	    if (pr == null || pr.getModel() == null || pr.getModel().getBrand() == null) return;

	    String expectedModel = (pr.getModel().getBrand().getName() + " " + pr.getModel().getName()).toLowerCase().trim();
	    if (expectedModel.isEmpty()) return;

	    LevenshteinDistance levenshtein = new LevenshteinDistance();
	    int threshold = 5;

	    List<MobileRepair> allRepairs = repairService.getAllRepairs();

	    // Filter while keeping original order
	    List<MobileRepair> filtered = allRepairs.stream()
	        .filter(m -> m.getDeviceModel() != null &&
	                     levenshtein.apply(expectedModel, m.getDeviceModel().toLowerCase().trim()) <= threshold)
	        .collect(Collectors.toList());

	    // Update the EventList used by Glazed Lists
	    repairList.getReadWriteLock().writeLock().lock();
	    try {
	        repairList.clear();
	        repairList.addAll(filtered);
	    } finally {
	        repairList.getReadWriteLock().writeLock().unlock();
	    }

	    // Optionally select the first match (original order)
	    if (!filtered.isEmpty()) {
	        cmbRepairId.setSelectedItem(filtered.get(0));
	    } else {
	        cmbRepairId.setSelectedItem(null);
	    }
	}

	private void setPartReciept(PartReceipt pr) {
		cmbReceipt.setSelectedItem(pr);

	}

	private void setPart(PartReceipt pr) {
		Part p = pr.getPart();
		cmbPart.setSelectedItem(p);

	}

	private void setModel(PartReceipt pr) {
		Model m = pr.getModel();
		cmbModel.setSelectedItem(m);

	}

	private void setBrand(PartReceipt pr) {

		Brand b = pr.getModel().getBrand();
		cmbBrand.setSelectedItem(b);
	}

	private void setSupplier(PartReceipt pr) {

		Supplier s = pr.getSupplier();
		cmbSupplier.setSelectedItem(s);
	}

	private void setRepairId(Long idValue) {
		cmbRepairId.setSelectedItem(idValue);

	}

	private void loadModels() {

		Brand b = (Brand) cmbBrand.getSelectedItem();
		List<Model> mlist = partReceiptService.getModelsByBrands(b);
		cmbModel.removeAllItems();
		cmbPart.removeAllItems();
		cmbReceipt.removeAllItems();
		for (Model m : mlist) {
			cmbModel.addItem(m);
		}

	}

	private void loadBrands() {

		Supplier s = (Supplier) cmbSupplier.getSelectedItem();
		List<Brand> blist = partReceiptService.getBrandsBySupplier(s);
		cmbBrand.removeAllItems();
		cmbModel.removeAllItems();
		cmbPart.removeAllItems();
		cmbReceipt.removeAllItems();
		for (Brand b : blist) {
			cmbBrand.addItem(b);
		}

	}

	private JPanel createFormPanel() {
		JPanel panel = new JPanel();
		panel.setBackground(new Color(245, 248, 250));
		panel.setBorder(BorderFactory.createTitledBorder("📦 Part Usage Details"));

		GroupLayout layout = new GroupLayout(panel);
		panel.setLayout(layout);

		layout.setAutoCreateGaps(true);
		layout.setAutoCreateContainerGaps(true);

		JLabel lblSupplier = new JLabel("Supplier:");
		JLabel lblBrand = new JLabel("Brand:");
		JLabel lblModel = new JLabel("Model:");
		JLabel lblPart = new JLabel("Part:");
		JLabel lblReceipt = new JLabel("Part Receipt:");
		JLabel lblRepairId = new JLabel("Repair ID:");
		JLabel lblQuantity = new JLabel("Quantity:");
		JLabel lblStatus = new JLabel("Status:");

		Font labelFont = new Font("Segoe UI", Font.PLAIN, 14);
		Font inputFont = new Font("Segoe UI", Font.PLAIN, 14);
		for (JLabel lbl : new JLabel[] { lblSupplier, lblPart, lblReceipt, lblRepairId, lblQuantity, lblStatus }) {
			lbl.setFont(labelFont);
		}

		cmbSupplier.setFont(inputFont);
		cmbPart.setFont(inputFont);
		cmbReceipt.setFont(inputFont);
		cmbRepairId.setFont(inputFont);
		cmbStatus.setFont(inputFont);
		spnQuantity.setFont(inputFont);

		layout.setHorizontalGroup(layout.createSequentialGroup()
				.addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addComponent(lblSupplier)
						.addComponent(lblBrand).addComponent(lblModel).addComponent(lblPart).addComponent(lblReceipt)
						.addComponent(lblRepairId).addComponent(lblQuantity).addComponent(lblStatus))
				.addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(cmbSupplier)
						.addComponent(cmbBrand).addComponent(cmbModel).addComponent(cmbPart).addComponent(cmbReceipt)
						.addComponent(cmbRepairId).addComponent(spnQuantity).addComponent(cmbStatus)));

		layout.setVerticalGroup(layout.createSequentialGroup()
				.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(lblSupplier)
						.addComponent(cmbSupplier))
				.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(lblBrand)
						.addComponent(cmbBrand))
				.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(lblModel)
						.addComponent(cmbModel))
				.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(lblPart)
						.addComponent(cmbPart))
				.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(lblReceipt)
						.addComponent(cmbReceipt))
				.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(lblRepairId)
						.addComponent(cmbRepairId))
				.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(lblQuantity)
						.addComponent(spnQuantity))
				.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(lblStatus)
						.addComponent(cmbStatus)));

		return panel;
	}

	private JPanel createButtonPanel() {
		JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 12));
		panel.setBackground(new Color(245, 248, 250));

		JButton btnSave = new JButton("💾 Save");
		JButton btnCancel = new JButton("❌ Cancel");

		Font buttonFont = new Font("Segoe UI", Font.BOLD, 14);
		btnSave.setFont(buttonFont);
		btnCancel.setFont(buttonFont);

		btnSave.setBackground(new Color(33, 150, 243));
		btnSave.setForeground(Color.BLACK);
		btnSave.setFocusPainted(false);

		btnCancel.setBackground(new Color(220, 53, 69));
		btnCancel.setForeground(Color.BLACK);
		btnCancel.setFocusPainted(false);

		btnSave.setPreferredSize(new Dimension(100, 36));
		btnCancel.setPreferredSize(new Dimension(100, 36));

		btnSave.addActionListener(e -> saveUsedPart());
		btnCancel.addActionListener(e -> dispose());

		panel.add(btnSave);
		panel.add(btnCancel);

		return panel;
	}

	private void loadSuppliers() {
		cmbSupplier.removeAllItems();
		cmbBrand.removeAllItems();
		cmbModel.removeAllItems();
		cmbPart.removeAllItems();
		cmbReceipt.removeAllItems();
		supplierService.getAllSuppliers().forEach(cmbSupplier::addItem);
		if (cmbSupplier.getItemCount() > 0)
			cmbSupplier.setSelectedIndex(0);
	}

	private void loadParts() {
		cmbPart.removeAllItems();
		cmbReceipt.removeAllItems();
		Model m = (Model) cmbModel.getSelectedItem();
		Supplier s = (Supplier) cmbSupplier.getSelectedItem();
		List<Part> plist = partReceiptService.getPartsByModelsAndSupplier(s, m);
		for (Part p : plist) {
			cmbPart.addItem(p);
		}
		if (cmbPart.getItemCount() > 0)
			cmbPart.setSelectedIndex(0);
	}

	private void loadReceipts() {

		cmbReceipt.removeAllItems();

		Part part = (Part) cmbPart.getSelectedItem();
		Model m = (Model) cmbModel.getSelectedItem();
		Supplier s = (Supplier) cmbSupplier.getSelectedItem();

		List<PartReceipt> pr = partReceiptService.getPartReceiptsByPart(part, s, m);
		for (PartReceipt p : pr) {
			cmbReceipt.addItem(p);
		}
		if (cmbReceipt.getItemCount() > 0)
			cmbReceipt.setSelectedIndex(0);
	}

	private void loadRepairIds() {
		repairList.getReadWriteLock().writeLock().lock();
		try {
			repairList.clear();
			repairService.getAllRepairs().forEach(repairList::add);
		} finally {
			repairList.getReadWriteLock().writeLock().unlock();
		}
	}

	private void saveUsedPart() {
		try {
			Supplier supplier = (Supplier) cmbSupplier.getSelectedItem();
			Part part = (Part) cmbPart.getSelectedItem();
			PartReceipt receipt = (PartReceipt) cmbReceipt.getSelectedItem();
			MobileRepair mobileRepair = (MobileRepair) cmbRepairId.getSelectedItem();
			int qty = (Integer) spnQuantity.getValue();
			String status = (String) cmbStatus.getSelectedItem();

			if (supplier == null || part == null || receipt == null || mobileRepair == null) {
				showError("Please complete all fields.");
				return;
			}

			RepairPartsUsed used = new RepairPartsUsed();
			used.setSupplier(supplier);
			used.setPart(part);
			used.setReceipt(receipt);
			used.setRepair(mobileRepair);
			used.setQuantityUsed(qty);
			used.setStatus(status);

			partsUsedService.save(used);
			JOptionPane.showMessageDialog(this, "✅ Part usage saved successfully!");

			if (parentView != null)
				parentView.loadTable();
			dispose();

		} catch (DataAccessException | PersistenceException e) {
			e.printStackTrace();
			ExceptionHandler.showRootCause(e);

			// showError("❌ Failed to save: " + e.getMessage());

		}
		if (partRecieptView != null && prId != null) {
			partRecieptView.loadInitialData();
		}
		dispose();
	}

	private void showError(String msg) {
		JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);

	}
}
