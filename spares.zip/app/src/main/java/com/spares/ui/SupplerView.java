package com.spares.ui;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spares.AppConfig;
import com.spares.model.Supplier;
import com.spares.service.SupplierService;

public class SupplerView extends JFrame {

	private JPanel contentPane;
	private JTable supplierTable;
	private JTextField textField;
	private SupplierService supplierService;
	private DefaultTableModel model;

	public SupplerView() {
		setTitle("Supplier Management");
		//setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/icons/supplier.png"))); // Optional
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 720, 500);
		setLocationRelativeTo(null); // Center the window

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		supplierService = context.getBean(SupplierService.class);

		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
		contentPane.setLayout(null);
		setContentPane(contentPane);

		JLabel lblSearch = new JLabel("Search:");
		lblSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		lblSearch.setBounds(40, 20, 60, 30);
		contentPane.add(lblSearch);

		textField = new JTextField();
		textField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		textField.setBounds(100, 20, 200, 30);
		contentPane.add(textField);

		JButton btnSearch = new JButton("Search");
		btnSearch.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		btnSearch.setBounds(310, 20, 100, 30);
		contentPane.add(btnSearch);

		JPanel panel = new JPanel();
		panel.setBounds(30, 70, 640, 280);
		panel.setLayout(null);
		panel.setBackground(new Color(248, 248, 248));
		panel.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
		contentPane.add(panel);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 20, 600, 240);
		panel.add(scrollPane);

		supplierTable = new JTable();
		supplierTable.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		supplierTable.setRowHeight(24);
		scrollPane.setViewportView(supplierTable);

		JButton btnAdd = new JButton("Add");
		btnAdd.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		btnAdd.setBounds(80, 370, 100, 35);
		contentPane.add(btnAdd);

		JButton btnEdit = new JButton("Update");
		btnEdit.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		btnEdit.setBounds(210, 370, 100, 35);
		contentPane.add(btnEdit);

		JButton btnDelete = new JButton("Delete");
		btnDelete.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		btnDelete.setBounds(340, 370, 100, 35);
		contentPane.add(btnDelete);

		model = new DefaultTableModel() {
			@Override
			public boolean isCellEditable(int row, int column) {
				return column == 1; // Only Name column editable
			}
		};
		model.setColumnIdentifiers(new String[] { "Supplier ID", "Name" });
		JTableStyler.styleTable(supplierTable, 0);
		loadTable();

		// Button Listeners
		btnAdd.addActionListener(e -> {
			new SupplierForm(supplierService, SupplerView.this).setVisible(true);
		});

		btnEdit.addActionListener(e -> editSupplier());

		btnDelete.addActionListener(e -> deleteSupplier());

		btnSearch.addActionListener(e -> searchSuppliers());
	}

	public void loadTable() {
		model.setRowCount(0);
		List<Supplier> list = supplierService.getAllSuppliers();
		for (Supplier supplier : list) {
			model.addRow(new Object[] { supplier.getSupplierId(), supplier.getName() });
		}
		supplierTable.setModel(model);
	}

	private void editSupplier() {
		int selectedRow = supplierTable.getSelectedRow();
		if (selectedRow == -1) {
			JOptionPane.showMessageDialog(this, "Please select a supplier to edit.");
			return;
		}
		Long supplierId = (Long) model.getValueAt(selectedRow, 0);
		String currentName = (String) model.getValueAt(selectedRow, 1);

		Supplier s = new Supplier();
		s.setSupplierId(supplierId);
		s.setName(currentName);

		supplierService.update(s);
		loadTable();
	}

	private void deleteSupplier() {
		int selectedRow = supplierTable.getSelectedRow();
		if (selectedRow == -1) {
			JOptionPane.showMessageDialog(this, "Please select a supplier to delete.");
			return;
		}
		int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this supplier?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
		if (confirm == JOptionPane.YES_OPTION) {
			Long supplierId = (Long) model.getValueAt(selectedRow, 0);
			supplierService.delete(supplierId);
			loadTable();
		}
	}

	private void searchSuppliers() {
		String keyword = textField.getText().trim().toLowerCase();
		if (keyword.isEmpty()) {
			loadTable();
			return;
		}
		model.setRowCount(0);
		List<Supplier> list = supplierService.getAllSuppliers();
		for (Supplier supplier : list) {
			if (supplier.getName().toLowerCase().contains(keyword)) {
				model.addRow(new Object[] { supplier.getSupplierId(), supplier.getName() });
			}
		}
	}
}
