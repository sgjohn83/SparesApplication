package com.spares.ui;


import com.formdev.flatlaf.FlatLightLaf;
import com.spares.AppConfig;
import com.spares.model.CompletedSupplierPayment;
import com.spares.service.CompletedSupplierPaymentService;
import com.toedter.calendar.JDateChooser;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.awt.*;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class PaymentsReport extends JFrame {

    private JPanel contentPane;
    private JTable table;
    private JComboBox<String> comboBoxSupplier;
    private JDateChooser dateChooserFrom;
    private JDateChooser dateChooserTo;
    private JButton btnRefresh;
    private JLabel lblTotalCost;
    private JLabel lblTotalQuantity;
    private CompletedSupplierPaymentService paymentService;

    public PaymentsReport() {
    	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
    	paymentService = context.getBean(CompletedSupplierPaymentService.class);

        try {
            UIManager.setLookAndFeel(new FlatLightLaf());
        } catch (Exception e) {
            e.printStackTrace();
        }

        setTitle("Payments Report");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);

        JLabel lblFrom = new JLabel("From:");
        dateChooserFrom = new JDateChooser();
        dateChooserFrom.setDate(new Date(System.currentTimeMillis() - 7L * 24 * 60 * 60 * 1000));

        JLabel lblTo = new JLabel("To:");
        dateChooserTo = new JDateChooser();
        dateChooserTo.setDate(new Date());

        JLabel lblSupplier = new JLabel("Supplier:");
        comboBoxSupplier = new JComboBox<>();
        comboBoxSupplier.addItem("All");

        btnRefresh = new JButton("Refresh");
        btnRefresh.addActionListener(e -> loadTableData());

        table = new JTable();
        JScrollPane scrollPane = new JScrollPane(table);

        JPanel summaryPanel = new JPanel(new GridLayout(1, 2, 20, 0));
        lblTotalCost = new JLabel("Total Cost: ₹0.00");
        lblTotalQuantity = new JLabel("Total Quantity: 0");
        lblTotalCost.setFont(new Font("SansSerif", Font.BOLD, 14));
        lblTotalQuantity.setFont(new Font("SansSerif", Font.BOLD, 14));
        summaryPanel.add(lblTotalCost);
        summaryPanel.add(lblTotalQuantity);

        GroupLayout layout = new GroupLayout(contentPane);
        contentPane.setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(lblFrom)
                    .addComponent(dateChooserFrom, GroupLayout.PREFERRED_SIZE, 130, GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTo)
                    .addComponent(dateChooserTo, GroupLayout.PREFERRED_SIZE, 130, GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblSupplier)
                    .addComponent(comboBoxSupplier, GroupLayout.PREFERRED_SIZE, 130, GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnRefresh))
                .addComponent(scrollPane)
                .addComponent(summaryPanel)
        );

        layout.setVerticalGroup(
            layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFrom)
                    .addComponent(dateChooserFrom, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTo)
                    .addComponent(dateChooserTo, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblSupplier)
                    .addComponent(comboBoxSupplier, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnRefresh))
                .addComponent(scrollPane)
                .addComponent(summaryPanel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
        );

        loadSuppliers();
        loadTableData();
    }

    private void loadSuppliers() {
        try {
            List<CompletedSupplierPayment> all = paymentService.getAllPayments();
            for (CompletedSupplierPayment p : all) {
                if (((DefaultComboBoxModel<String>) comboBoxSupplier.getModel()).getIndexOf(p.getSupplier()) == -1) {
                    comboBoxSupplier.addItem(p.getSupplier());
                }
            }
        } catch (Exception e) {
            showError("Error loading suppliers: " + e.getMessage());
        }
    }

    private void loadTableData() {
        try {
            List<CompletedSupplierPayment> allPayments = paymentService.getAllPayments();
            String selectedSupplier = (String) comboBoxSupplier.getSelectedItem();
            Date from = dateChooserFrom.getDate();
            Date to = dateChooserTo.getDate();

            DefaultTableModel model = new DefaultTableModel() {
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };
            model.setColumnIdentifiers(new Object[] {
                "ID", "Supplier", "Brand", "Model", "Part", "Cost", "Quantity", "Payment Date"
            });

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            BigDecimal totalCost = BigDecimal.ZERO;

            int totalQty = 0;

            for (CompletedSupplierPayment p : allPayments) {
                boolean match = true;
                if (from != null && p.getPaymentDate().before(from)) match = false;
                if (to != null && p.getPaymentDate().after(to)) match = false;
                if (!"All".equals(selectedSupplier) && !p.getSupplier().equals(selectedSupplier)) match = false;

                if (match) {
                    model.addRow(new Object[] {
                        p.getId(), p.getSupplier(), p.getBrand(), p.getModel(),
                        p.getPart(), p.getCost(), p.getQuantity(), sdf.format(p.getPaymentDate())
                    });
                    totalCost = totalCost.add(p.getCost() != null ? p.getCost() : BigDecimal.ZERO);
                    totalQty += p.getQuantity();
                }
            }

            table.setModel(model);
            styleTable();

            lblTotalCost.setText(String.format("Total Cost: ₹%.2f", totalCost));
            lblTotalQuantity.setText("Total Quantity: " + totalQty);

        } catch (Exception e) {
            showError("Error loading data: " + e.getMessage());
        }
    }

    private void styleTable() {
        table.setRowHeight(24);
        table.setFont(new Font("SansSerif", Font.PLAIN, 13));
        table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 14));
        table.getTableHeader().setReorderingAllowed(false);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));

        JTableHeader header = table.getTableHeader();
        header.setBackground(new Color(230, 230, 250));
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
}
