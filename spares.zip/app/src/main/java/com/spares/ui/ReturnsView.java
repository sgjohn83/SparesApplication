package com.spares.ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spares.AppConfig;
import com.spares.model.Brand;
import com.spares.model.FailedPartReturn;
import com.spares.model.Model;
import com.spares.model.RepairPartsUsed;
import com.spares.model.Supplier;
import com.spares.service.FailedPartReturnService;
import com.spares.service.SupplierService;

public class ReturnsView extends JFrame {

    private JPanel contentPane;
    private JTextField searchField;
    private JTable returnsTable;
    private JComboBox<Supplier> supplierComboBox;
    private JButton returnButton;
    private SupplierService supplierService;
    private FailedPartReturnService failedPartReturnService;
    private List<Supplier> supplierList;
    private List<FailedPartReturn> allReturns;
    private AnnotationConfigApplicationContext context;

    public ReturnsView() {
        context = new AnnotationConfigApplicationContext(AppConfig.class);
        supplierService = context.getBean(SupplierService.class);
        failedPartReturnService = context.getBean(FailedPartReturnService.class);

        initializeUI();
        setupComponents();
        loadInitialData();
        addListenersAndCleanup();
    }

    private void initializeUI() {
        setTitle("Parts Return Management");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(800, 500);
        setLocationRelativeTo(null);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(15, 15, 15, 15));
        setContentPane(contentPane);
    }

    private void setupComponents() {
        // Supplier ComboBox
        JLabel lblSupplier = new JLabel("Supplier:");
        supplierComboBox = new JComboBox<>();
        supplierComboBox.setPreferredSize(new Dimension(180, 30));

        // Search Field
        JLabel lblSearch = new JLabel("Search:");
        searchField = new JTextField();
        searchField.setPreferredSize(new Dimension(200, 30));
        searchField.setBorder(BorderFactory.createCompoundBorder(
            searchField.getBorder(), 
            BorderFactory.createEmptyBorder(2, 6, 2, 6)
        ));

        // Return Button
        returnButton = createStyledButton("Process Return");

        // Table Setup
        JScrollPane tableScrollPane = new JScrollPane();
        returnsTable = new JTable();
        initializeTable();
        tableScrollPane.setViewportView(returnsTable);

        // Layout Setup
        GroupLayout layout = new GroupLayout(contentPane);
        contentPane.setLayout(layout);
        setupGroupLayout(layout, lblSupplier, lblSearch, tableScrollPane);
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(140, 30));
        button.setFocusPainted(false);
        button.setForeground(Color.BLACK);
        button.setBackground(new Color(66, 133, 244));
        button.setOpaque(true);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        
        button.getModel().addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                ButtonModel model = button.getModel();
                button.setBackground(model.isPressed() ? 
                    new Color(40, 100, 200) : new Color(66, 133, 244));
            }
        });
        return button;
    }

    private void setupGroupLayout(GroupLayout layout, JLabel lblSupplier, JLabel lblSearch, JScrollPane tableScrollPane) {
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(lblSupplier)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(supplierComboBox)
                .addGap(30)
                .addComponent(lblSearch)
                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(searchField)
                .addGap(30)
                .addComponent(returnButton))
            .addComponent(tableScrollPane));

        layout.setVerticalGroup(layout.createSequentialGroup()
            .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(lblSupplier)
                .addComponent(supplierComboBox)
                .addComponent(lblSearch)
                .addComponent(searchField)
                .addComponent(returnButton))
            .addGap(15)
            .addComponent(tableScrollPane, GroupLayout.PREFERRED_SIZE, 330, GroupLayout.PREFERRED_SIZE));
    }

    private void loadInitialData() {
        loadSupplierCombo();
        loadTable();
    }

    private void addListenersAndCleanup() {
        addListeners();
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                context.close();
            }
        });
    }

    private void loadSupplierCombo() {
        supplierList = supplierService.getAllSuppliers();
        DefaultComboBoxModel<Supplier> model = new DefaultComboBoxModel<>();

        Supplier allSupplier = new Supplier() {
            @Override
            public Long getSupplierId() { return 0L; }
            
            @Override
            public String toString() { return "All"; }
        };

        model.addElement(allSupplier);
        for (Supplier supplier : supplierList) {
            model.addElement(supplier);
        }
        supplierComboBox.setModel(model);
    }

    private void initializeTable() {
        DefaultTableModel model = new DefaultTableModel(
            new String[] { "ID", "Brand", "Model", "Part Name", "Cost", "Supplier", "Select" }, 0) {
            
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return columnIndex == 6 ? Boolean.class : Object.class;
            }
            
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 6;
            }
        };
        returnsTable.setModel(model);
        returnsTable.setRowHeight(25);
        returnsTable.setFillsViewportHeight(true);
        Font tableFont = new Font("Segoe UI", Font.BOLD, 18);
        returnsTable.setFont(tableFont);
    }

    private void loadTable() {
        allReturns = failedPartReturnService.getReturnItems();
        filterAndShowTable();
    }

    private void filterAndShowTable() {
        String search = searchField.getText().trim().toLowerCase();
        Supplier selectedSupplier = (Supplier) supplierComboBox.getSelectedItem();
        DefaultTableModel model = (DefaultTableModel) returnsTable.getModel();
        model.setRowCount(0);

        for (FailedPartReturn item : allReturns) {
            try {
                if (item == null) continue;

                RepairPartsUsed used = item.getRepairPartUsed();
                if (used == null) continue;

                // Null-safe data extraction
                Brand brand = null;
                Model modelName = null;
                String partName = "";
                BigDecimal unitCost = BigDecimal.ZERO;
                String supplierName = "N/A";

                if (used.getReceipt() != null) {
                    if (used.getReceipt().getModel() != null) {
                        brand = used.getReceipt().getModel().getBrand();
                        modelName = used.getReceipt().getModel();
                    }
                    unitCost = nullSafe(used.getReceipt().getUnitCost(), BigDecimal.ZERO);
                }

                Object partObj = used.getPart();
                if (partObj != null) {
                    partName = partObj.toString();
                }

                Supplier partSupplier = used.getSupplier();
                if (partSupplier != null) {
                    supplierName = nullSafe(partSupplier.getName());
                }

                // Filter logic
                boolean matchesSupplier = selectedSupplier.getSupplierId() == 0L || 
                    (partSupplier != null && 
                     selectedSupplier.getSupplierId().equals(partSupplier.getSupplierId()));

                boolean matchesSearch = search.isEmpty() || 
                    partName.toLowerCase().contains(search) ||
                    brand.toString().toLowerCase().contains(search) ||
                    modelName.toString().toLowerCase().contains(search);

                if (matchesSupplier && matchesSearch) {
                    model.addRow(new Object[] {
                        item.getReturnId(),
                        brand,
                        modelName,
                        partName,
                        unitCost,
                        supplierName,
                        Boolean.FALSE
                    });
                }
            } catch (Exception e) {
                System.err.println("Error processing row: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    private String nullSafe(String value) {
        return value != null ? value : "";
    }

    private BigDecimal nullSafe(BigDecimal value, BigDecimal defaultValue) {
        return value != null ? value : defaultValue;
    }

    private void addListeners() {
        returnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                processSelectedReturns();
            }
        });

        searchField.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { filterAndShowTable(); }
            @Override public void removeUpdate(DocumentEvent e) { filterAndShowTable(); }
            @Override public void changedUpdate(DocumentEvent e) { filterAndShowTable(); }
        });

        supplierComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                filterAndShowTable();
            }
        });
    }

    private void processSelectedReturns() {
        DefaultTableModel model = (DefaultTableModel) returnsTable.getModel();
        List<Long> selectedReturnIds = new ArrayList<>();

        for (int i = 0; i < model.getRowCount(); i++) {
            Boolean selected = (Boolean) model.getValueAt(i, 6);
            if (Boolean.TRUE.equals(selected)) {
                Long returnId = (Long) model.getValueAt(i, 0);
                selectedReturnIds.add(returnId);
            }
        }

        if (!selectedReturnIds.isEmpty()) {
            try {
                failedPartReturnService.updateDates(selectedReturnIds.toArray(new Long[0]));
                JOptionPane.showMessageDialog(this, 
                    "Processed " + selectedReturnIds.size() + " returns", 
                    "Success", JOptionPane.INFORMATION_MESSAGE);
                loadTable();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, 
                    "Error: " + e.getMessage(), 
                    "Processing Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, 
                "No returns selected", 
                "Warning", JOptionPane.WARNING_MESSAGE);
        }
    }
}