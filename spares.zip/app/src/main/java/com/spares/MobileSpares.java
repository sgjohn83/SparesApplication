package com.spares;

import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.UIManager;

import org.springframework.stereotype.Component;

import com.spares.model.RepairPartsUsed;
import com.spares.model.SupplierPaymentSummaryView;
import com.spares.ui.BrandView;
import com.spares.ui.CostReport;
import com.spares.ui.CurrentStock;
import com.spares.ui.MobileRepairsView;
import com.spares.ui.ModelView;
import com.spares.ui.PartRecieptView;
import com.spares.ui.PartsUsedView;
import com.spares.ui.PaymentsReport;
import com.spares.ui.ReturnReports;
import com.spares.ui.ReturnsView;
import com.spares.ui.SparePartsView;
import com.spares.ui.SupplerView;
import com.spares.ui.SupplierPaymentsView;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JToolBar;
import javax.swing.JButton;
import javax.swing.ImageIcon;

@Component
public class MobileSpares {

	public JFrame frame;

	public MobileSpares() {
		System.out.println("cons");
		initialize();
		// Your existing code stays here — untouched
	   
		styleUI();       // Apply system look and feel
		setFullScreen(); // Set frame to full screen
	}

	private void setFullScreen() {
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		frame.setSize(screenSize);
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximize
		frame.setTitle("Spares Application");
	}

	private void styleUI() {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			javax.swing.SwingUtilities.updateComponentTreeUI(frame); // Apply look to all components
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void initialize() {
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);

		JMenu mnSuppliers = new JMenu("Suppliers");
		menuBar.add(mnSuppliers);

		JMenuItem mntmAddSupplier = new JMenuItem("SupplierNames");
		mntmAddSupplier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new SupplerView().setVisible(true);
			}
		});
		mnSuppliers.add(mntmAddSupplier);
		
		JMenuItem mntmSupplierReturns = new JMenuItem("Supplier Returns");
		mntmSupplierReturns.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ReturnsView().setVisible(true);
			}
		});
		mnSuppliers.add(mntmSupplierReturns);
		
		JMenuItem mntmSupplierPayments = new JMenuItem("Supplier Payments");
		mntmSupplierPayments.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new SupplierPaymentsView().setVisible(true);
			}
		});
		mnSuppliers.add(mntmSupplierPayments);

		JMenu mnSparePart = new JMenu("Spare Parts");
		menuBar.add(mnSparePart);

		JMenuItem mntmAddSparePart = new JMenuItem("Spare Names");
		mntmAddSparePart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new SparePartsView().setVisible(true);
			}
		});
		
		JMenuItem mntmBrand = new JMenuItem("Brand");
		mntmBrand.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new BrandView().setVisible(true);
			}
		});
		mnSparePart.add(mntmBrand);
		
		JMenuItem mntmModels = new JMenuItem("Models");
		mntmModels.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ModelView().setVisible(true);
			}
		});
		mnSparePart.add(mntmModels);
		mnSparePart.add(mntmAddSparePart);
		
		JMenuItem mntmPurchase = new JMenuItem("Purchase");
		mntmPurchase.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new PartRecieptView().setVisible(true);
			}
		});
		mnSparePart.add(mntmPurchase);
		
		JMenu mnService = new JMenu("Service");
		menuBar.add(mnService);
		
		JMenuItem mntmNewService = new JMenuItem("New Service");
		mntmNewService.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new MobileRepairsView().setVisible(true);
			}
		});
		mnService.add(mntmNewService);
		
		JMenuItem mntmApplySpares = new JMenuItem("Apply Spares");
		mntmApplySpares.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new PartsUsedView().setVisible(true);
			}
		});
		mnService.add(mntmApplySpares);
		
		JMenu mnReports = new JMenu("Reports");
		menuBar.add(mnReports);
		
		JMenuItem mntmCounterStocks = new JMenuItem("Counter Stocks");
		mntmCounterStocks.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new CurrentStock().setVisible(true);
			}
		});
		mnReports.add(mntmCounterStocks);
		
		JMenuItem mntmDailyPayments = new JMenuItem("Daily Payments");
		mntmDailyPayments.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new PaymentsReport().setVisible(true);
			}
		});
		mnReports.add(mntmDailyPayments);
		
		JMenuItem mntmDailyReturns = new JMenuItem("Daily Returns");
		mntmDailyReturns.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ReturnReports().setVisible(true);
			}
		});
		mnReports.add(mntmDailyReturns);
		
		JMenuItem mntmCostReports = new JMenuItem("Cost Reports");
		mntmCostReports.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new CostReport().setVisible(true);
			}
		});
		mnReports.add(mntmCostReports);

		frame.getContentPane().setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 11, 1350, 687);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		JLabel lblNewLabelShadow = new JLabel("Spares Application");
		lblNewLabelShadow.setForeground(new Color(100, 100, 100)); // Shadow gray
		lblNewLabelShadow.setFont(new Font("SansSerif", Font.BOLD, 42));
		lblNewLabelShadow.setBounds(505 + 2, 150 + 2, 400, 60); // Offset for shadow
		panel.add(lblNewLabelShadow);

		JLabel lblNewLabel = new JLabel("Spares Application");
		lblNewLabel.setForeground(new Color(0, 51, 153)); // Modern dark blue
		lblNewLabel.setFont(new Font("SansSerif", Font.BOLD, 42));
		lblNewLabel.setBounds(505, 150, 400, 60); // Centered manually (screen width 1350)
		panel.add(lblNewLabel);
		
		JToolBar toolBar = new JToolBar();
		toolBar.setBounds(0, 0, 1350, 90);
		panel.add(toolBar);
		
		JButton btnNewButton = new JButton("Purchase");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new PartRecieptView().setVisible(true);
			}
		});
		btnNewButton.setIcon(new ImageIcon(MobileSpares.class.getResource("/icons/paid_64dp_EA3323_FILL0_wght400_GRAD0_opsz48.png")));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		toolBar.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Apply Service");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new PartsUsedView().setVisible(true);
			}
		});
		btnNewButton_1.setIcon(new ImageIcon(MobileSpares.class.getResource("/icons/construction_64dp_EA3323_FILL0_wght400_GRAD0_opsz48.png")));
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		toolBar.add(btnNewButton_1);
		
		JButton btnSupplierPayments = new JButton("Supplier Payments");
		btnSupplierPayments.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new SupplierPaymentsView().setVisible(true);
			}
		});
		btnSupplierPayments.setIcon(new ImageIcon(MobileSpares.class.getResource("/icons/payments_64dp_EA3323_FILL0_wght400_GRAD0_opsz48.png")));
		btnSupplierPayments.setFont(new Font("Tahoma", Font.BOLD, 13));
		toolBar.add(btnSupplierPayments);
		
		JButton btnSupplierReturns = new JButton("Supplier Returns");
		btnSupplierReturns.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new ReturnsView().setVisible(true);
			}
		});
		btnSupplierReturns.setIcon(new ImageIcon(MobileSpares.class.getResource("/icons/backspace_64dp_EA3323_FILL0_wght400_GRAD0_opsz48.png")));
		btnSupplierReturns.setFont(new Font("Tahoma", Font.BOLD, 13));
		toolBar.add(btnSupplierReturns);

	}
}
