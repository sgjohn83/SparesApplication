package com.spares.model;



import javax.persistence.*;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name = "PART_RECEIPTS", schema = "DIGITAL1")
public class PartReceipt {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "receipt_seq_gen")
    @SequenceGenerator(name = "receipt_seq_gen", sequenceName = "SEQ_RECEIPT", allocationSize = 1)
    @Column(name = "RECEIPT_ID")
    private Long receiptId;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "SUPPLIER_ID")
    private Supplier supplier;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "PART_ID")
    private Part part;

    @Column(name = "QUANTITY", nullable = false)
    private Integer quantity;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "RECEIPT_DATE", columnDefinition = "DATE DEFAULT SYSDATE")
    private Date receiptDate;

    @Column(name = "UNIT_COST", precision = 10, scale = 2)
    private BigDecimal unitCost;
   
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "MODEL_ID")
    private Model model;


    // --- Getters and Setters ---

    public Long getReceiptId() {
        return receiptId;
    }

    public void setReceiptId(Long receiptId) {
        this.receiptId = receiptId;
    }

    public Supplier getSupplier() {
        return supplier;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }

    public Part getPart() {
        return part;
    }

    public void setPart(Part part) {
        this.part = part;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Date getReceiptDate() {
        return receiptDate;
    }

    public void setReceiptDate(Date receiptDate) {
        this.receiptDate = receiptDate;
    }

    public BigDecimal getUnitCost() {
        return unitCost;
    }

    public void setUnitCost(BigDecimal unitCost) {
        this.unitCost = unitCost;
    }
    public Model getModel() {
        return model;
    }

    public void setModel(Model model) {
        this.model = model;
    }
    @Override
    public String toString()
    {
    	return supplier.getName()+"("+part.getName()+"."+unitCost+")";
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PartReceipt)) return false;
        PartReceipt that = (PartReceipt) o;
        return Objects.equals(supplier, that.supplier) &&
               Objects.equals(part, that.part) &&
               Objects.equals(model, that.model) &&
               Objects.equals(unitCost, that.unitCost) &&
               Objects.equals(receiptDate, that.receiptDate);
    }
    @Override
    public int hashCode() {
        return Objects.hash(supplier, part, model, unitCost, receiptDate);
    }
}
