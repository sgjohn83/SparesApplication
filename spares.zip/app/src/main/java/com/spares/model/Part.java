package com.spares.model;



import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Objects;

@Entity
@Table(name = "PARTS", schema = "DIGITAL1")
public class Part {

    @Id
    @SequenceGenerator(
        name = "parts_seq_gen",           // Hibernate generator name
        sequenceName = "SEQ_PART",       // the DB sequence you created
        schema = "DIGITAL1",              // your Oracle schema
        allocationSize = 1                // must match INCREMENT BY 1
    )
    @GeneratedValue(
        strategy = GenerationType.SEQUENCE,
        generator = "parts_seq_gen"
    )
    @Column(name = "PART_ID")
    private Long partId;

    @Column(name = "NAME", nullable = false, length = 100)
    private String name;

    @Column(name = "UNIT_COST", nullable = false, precision = 10, scale = 2)
    private BigDecimal unitCost;

    // --- getters & setters ---

    public Long getPartId() {
        return partId;
    }
    public void setPartId(Long partId) {
        this.partId = partId;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getUnitCost() {
        return unitCost;
    }
    public void setUnitCost(BigDecimal unitCost) {
        this.unitCost = unitCost;
    }
    @Override
    public String toString()
    {
    	return this.name;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Part)) return false;
        Part part = (Part) o;
        return Objects.equals(name, part.name) &&
               Objects.equals(unitCost, part.unitCost);
    }
    @Override
    public int hashCode() {
        return Objects.hash(name, unitCost);
    }
}

