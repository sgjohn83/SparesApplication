package com.spares.model;



import javax.persistence.*;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name = "MOBILE_REPAIRS", schema = "DIGITAL1")
public class MobileRepair {

    @Id
    @Column(name = "REPAIR_ID")
    private Long repairId;

    @Column(name = "DEVICE_MODEL")
    private String deviceModel;

    @Column(name = "CUSTOMER_NAME")
    private String customerName;

    @Column(name = "STATUS")
    private String status = "PENDING"; // Default

    @Temporal(TemporalType.DATE)
    @Column(name = "REPAIR_DATE")
    private Date repairDate;

    // Getters and Setters
    public Long getRepairId() {
        return repairId;
    }

    public void setRepairId(Long repairId) {
        this.repairId = repairId;
    }

    public String getDeviceModel() {
        return deviceModel;
    }

    public void setDeviceModel(String deviceModel) {
        this.deviceModel = deviceModel;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getRepairDate() {
        return repairDate;
    }

    public void setRepairDate(Date repairDate) {
        this.repairDate = repairDate;
    }
    @Override
    public String toString()
    {
    	return this.repairId.toString()+"("+deviceModel+")";
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof MobileRepair)) return false;
        MobileRepair that = (MobileRepair) o;
        return Objects.equals(repairId, that.repairId) &&
               Objects.equals(deviceModel, that.deviceModel) &&
               Objects.equals(customerName, that.customerName) &&
               Objects.equals(repairDate, that.repairDate);
    }
    @Override
    public int hashCode() {
        return Objects.hash(repairId, deviceModel, customerName, repairDate);
    }
  
    
}

