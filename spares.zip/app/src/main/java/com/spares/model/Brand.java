package com.spares.model;


import javax.persistence.*;



import java.io.Serializable;
import java.util.Objects;

@Entity
@Table(name = "BRAND", schema = "DIGITAL1", 
       uniqueConstraints = {@UniqueConstraint(columnNames = "NAME")})
@SequenceGenerator(
    name = "brand_seq_gen",
    sequenceName = "DIGITAL1.SEQ_BRAND",
    allocationSize = 1
)
public class Brand  {

    

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "brand_seq_gen")
    @Column(name = "BRAND_ID")
    private Long brandId;

    @Column(name = "NAME", nullable = false, unique = true, length = 100)
    private String name;

    public Brand() {
    }

    public Long getBrandId() {
        return brandId;
    }

    public void setBrandId(Long brandId) {
        this.brandId = brandId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return name;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Brand)) return false;
        Brand brand = (Brand) o;
        return Objects.equals(brandId, brand.brandId);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((brandId == null) ? 0 : brandId.hashCode());
        return result;
    }

}

