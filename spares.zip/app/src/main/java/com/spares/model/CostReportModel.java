package com.spares.model;



import javax.persistence.*;

@Entity
@Table(name = "VW_PART_RECEIPTS_SUMMARY", schema = "DIGITAL1")
public class CostReportModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Virtual ID for Hibernate; view should have a unique column or use composite key in real use

    @Column(name = "SupplierName")
    private String supplierName;

    @Column(name = "BrandName")
    private String brandName;

    @Column(name = "ModelName")
    private String modelName;

    @Column(name = "PartName")
    private String partName;

    @Column(name = "TotalQuantityPurchased")
    private Long totalQuantityPurchased;

    @Column(name = "AverageUnitCost")
    private String averageUnitCost;

    @Column(name = "MinUnitCost")
    private String minUnitCost;

    @Column(name = "MaxUnitCost")
    private String maxUnitCost;

    @Column(name = "TotalSpentOnPartFromSupplier")
    private String totalSpentOnPartFromSupplier;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getPartName() {
		return partName;
	}

	public void setPartName(String partName) {
		this.partName = partName;
	}

	public Long getTotalQuantityPurchased() {
		return totalQuantityPurchased;
	}

	public void setTotalQuantityPurchased(Long totalQuantityPurchased) {
		this.totalQuantityPurchased = totalQuantityPurchased;
	}

	public String getAverageUnitCost() {
		return averageUnitCost;
	}

	public void setAverageUnitCost(String averageUnitCost) {
		this.averageUnitCost = averageUnitCost;
	}

	public String getMinUnitCost() {
		return minUnitCost;
	}

	public void setMinUnitCost(String minUnitCost) {
		this.minUnitCost = minUnitCost;
	}

	public String getMaxUnitCost() {
		return maxUnitCost;
	}

	public void setMaxUnitCost(String maxUnitCost) {
		this.maxUnitCost = maxUnitCost;
	}

	public String getTotalSpentOnPartFromSupplier() {
		return totalSpentOnPartFromSupplier;
	}

	public void setTotalSpentOnPartFromSupplier(String totalSpentOnPartFromSupplier) {
		this.totalSpentOnPartFromSupplier = totalSpentOnPartFromSupplier;
	}

   
}
