package com.spares.model;



import javax.persistence.*;

@Entity
@Table(name = "SUPPLIERS", schema = "DIGITAL1")
public class Supplier {

	@Id
    @GeneratedValue(
        strategy = GenerationType.SEQUENCE,
        generator = "supplier_seq_gen"
    )
    @SequenceGenerator(
        name = "supplier_seq_gen",
        sequenceName = "SUPPLIER_SEQ",  // exactly the DB sequence name
        schema = "DIGITAL1",
        allocationSize = 1             // match the sequence INCREMENT BY
    )
    @Column(name = "SUPPLIER_ID")
    private Long supplierId;

    @Column(name = "NAME", nullable = false)
    private String name;

    // Getters and setters

    public Long getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(Long supplierId) {
        this.supplierId = supplierId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    @Override
    public String toString()
    {
    	return this.name;
    }
    @Override
    public int hashCode() {
        return supplierId != null ? supplierId.hashCode() : 0;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Supplier other = (Supplier) obj;
        return supplierId != null && supplierId.equals(other.supplierId);
    }
}
