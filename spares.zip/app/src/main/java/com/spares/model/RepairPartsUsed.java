package com.spares.model;


import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "REPAIR_PARTS_USED", schema = "DIGITAL1")
public class RepairPartsUsed implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "repair_part_used_seq")
	@SequenceGenerator(name = "repair_part_used_seq", sequenceName = "SEQ_REPAIR_PART_USED", allocationSize = 1)
	@Column(name = "ID")
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "REPAIR_ID")
    private MobileRepair repair;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "PART_ID")
    private Part part;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "SUPPLIER_ID")
    private Supplier supplier;

    @Column(name = "QUANTITY_USED", nullable = false)
    private Integer quantityUsed;

    @Column(name = "STATUS", length = 20)
    private String status = "USED";

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "RECEIPT_ID")
    private PartReceipt receipt;

    // Constructors
    public RepairPartsUsed() {}

    // Getters and Setters
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public MobileRepair getRepair() {
        return repair;
    }
    public void setRepair(MobileRepair repair) {
        this.repair = repair;
    }

    public Part getPart() {
        return part;
    }
    public void setPart(Part part) {
        this.part = part;
    }

    public Supplier getSupplier() {
        return supplier;
    }
    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }

    public Integer getQuantityUsed() {
        return quantityUsed;
    }
    public void setQuantityUsed(Integer quantityUsed) {
        this.quantityUsed = quantityUsed;
    }

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public PartReceipt getReceipt() {
        return receipt;
    }
    public void setReceipt(PartReceipt receipt) {
        this.receipt = receipt;
    }
   
}
