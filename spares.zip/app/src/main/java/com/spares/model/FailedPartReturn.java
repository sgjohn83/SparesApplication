package com.spares.model;



import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "FAILED_PARTS_RETURNS", schema = "DIGITAL1")
public class FailedPartReturn implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "failed_part_return_seq")
    @SequenceGenerator(name = "failed_part_return_seq", sequenceName = "SEQ_FAILED_RETURN", allocationSize = 1)
    @Column(name = "RETURN_ID")
    private Long returnId;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "REPAIR_PART_USED_ID", nullable = false)
    private RepairPartsUsed repairPartUsed;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "RETURN_DATE")
    private Date returnDate;

    // Getters and Setters

    public Long getReturnId() {
        return returnId;
    }

    public void setReturnId(Long returnId) {
        this.returnId = returnId;
    }

    public RepairPartsUsed getRepairPartUsed() {
        return repairPartUsed;
    }

    public void setRepairPartUsed(RepairPartsUsed repairPartUsed) {
        this.repairPartUsed = repairPartUsed;
    }

    public Date getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(Date returnDate) {
        this.returnDate = returnDate;
    }
}

