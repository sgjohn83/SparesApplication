package com.spares.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;


@Entity
@Table(name = "VW_SUPPLIER_BALANCES")
@Immutable // Optional Hibernate annotation to mark it as read-only
public class SupplierPaymentSummaryView {

    @Id
    @Column(name = "supplier_id")
    private Long supplierId;

    @Column(name = "supplier_name")
    private String supplierName;

    @Column(name = "total_payable")
    private BigDecimal totalPayable;

    @Column(name = "amount_paid")
    private BigDecimal amountPaid;

    @Column(name = "balance")
    private BigDecimal balance;

    // Getters only if read-only
    public Long getSupplierId() { return supplierId; }
    public String getSupplierName() { return supplierName; }
    public BigDecimal getTotalPayable() { return totalPayable; }
    public BigDecimal getAmountPaid() { return amountPaid; }
    public BigDecimal getBalance() { return balance; }
}
