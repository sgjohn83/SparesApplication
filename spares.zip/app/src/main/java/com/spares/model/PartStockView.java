package com.spares.model;

import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "VW_PARTS_IN_COUNTER_INVENTORY")
public class PartStockView {

    @Id
    @Column(name = "PART_ID")
    private Long partId;
    @Column(name = "PART_NAME")
    private String partName;
    @Column(name = "CURRENT_STOCK")
    private Long currentStock;

    public PartStockView(Long partId, String partName, Long currentStock) {
        this.partId = partId;
        this.partName = partName;
        this.currentStock = currentStock;
    }

    // Getters
    public Long getPartId() {
        return partId;
    }

    public String getPartName() {
        return partName;
    }

    public Long getCurrentStock() {
        return currentStock;
    }

}
