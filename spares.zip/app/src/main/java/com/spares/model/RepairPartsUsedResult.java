package com.spares.model;

public class RepairPartsUsedResult {
    private RepairPartsUsed partUsed;
    private String displayDateStr;

    public RepairPartsUsedResult(RepairPartsUsed partUsed, String displayDateStr) {
        this.partUsed = partUsed;
        this.displayDateStr = displayDateStr;
    }

    public RepairPartsUsed getPartUsed() {
        return partUsed;
    }

    public String getDisplayDateStr() {
        return displayDateStr;
    }
}
