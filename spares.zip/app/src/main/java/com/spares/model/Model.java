package com.spares.model;



import java.util.Objects;

import javax.persistence.*;

@Entity
@Table(name = "MODEL", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"BRAND_ID", "NAME"})
})
public class Model {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "model_seq_gen")
	@SequenceGenerator(name = "model_seq_gen", sequenceName = "SEQ_MODEL", allocationSize = 1)
	@Column(name = "MODEL_ID")
    private Long modelId;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "BRAND_ID", nullable = false)
    private Brand brand;

    @Column(name = "NAME", nullable = false, length = 100)
    private String name;

    // Constructors
    public Model() {}

    public Model(Brand brand, String name) {
        this.brand = brand;
        this.name = name;
    }

    // Getters and Setters
    public Long getModelId() {
        return modelId;
    }

    public void setModelId(Long modelId) {
        this.modelId = modelId;
    }

    public Brand getBrand() {
        return brand;
    }

    public void setBrand(Brand brand) {
        this.brand = brand;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    @Override
    public String toString()
    {
    	return name;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Model)) return false;
        Model model = (Model) o;
        return Objects.equals(name, model.name) &&
               Objects.equals(brand, model.brand);
    }
    @Override
    public int hashCode() {
        return Objects.hash(name, brand);
    }
}
