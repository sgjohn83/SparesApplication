package com.spares.model;

import java.util.Date;

public class FailedPartReturnView {

    private String supplierName;
    private String partName;
    private Integer quantityToReturn;
    private Date returnDate;

    public FailedPartReturnView(String supplierName, String partName, Integer quantityToReturn, Date returnDate) {
        this.supplierName = supplierName;
        this.partName = partName;
        this.quantityToReturn = quantityToReturn;
        this.returnDate = returnDate;
    }

    // Getters
    public String getSupplierName() {
        return supplierName;
    }

    public String getPartName() {
        return partName;
    }

    public Integer getQuantityToReturn() {
        return quantityToReturn;
    }

    public Date getReturnDate() {
        return returnDate;
    }
}
