package com.spares.model;

public class PendingPartUsageView {

    private String partName;
    private Long pendingQuantity;

    public PendingPartUsageView(String partName, Long pendingQuantity) {
        this.partName = partName;
        this.pendingQuantity = pendingQuantity;
    }

    public String getPartName() {
        return partName;
    }

    public Long getPendingQuantity() {
        return pendingQuantity;
    }
}
