package com.spares.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PART_RECEIPT_STOCK")
public class PartReceiptStock {

    @Id
    @Column(name = "STOCK_ID")
    private Long stockId;

    @OneToOne
    @JoinColumn(name = "RECEIPT_ID", referencedColumnName = "RECEIPT_ID", unique = true)
    private PartReceipt receipt;

    @Column(name = "QUANTITY_RECEIVED", nullable = false)
    private Integer quantityReceived;

    @Column(name = "QUANTITY_USED", nullable = false)
    private Integer quantityUsed = 0;

    @Column(name = "LAST_UPDATED")
    private Date lastUpdated;

	public Long getStockId() {
		return stockId;
	}

	public void setStockId(Long stockId) {
		this.stockId = stockId;
	}

	public PartReceipt getReceipt() {
		return receipt;
	}

	public void setReceipt(PartReceipt receipt) {
		this.receipt = receipt;
	}

	public Integer getQuantityReceived() {
		return quantityReceived;
	}

	public void setQuantityReceived(Integer quantityReceived) {
		this.quantityReceived = quantityReceived;
	}

	public Integer getQuantityUsed() {
		return quantityUsed;
	}

	public void setQuantityUsed(Integer quantityUsed) {
		this.quantityUsed = quantityUsed;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

    
}

